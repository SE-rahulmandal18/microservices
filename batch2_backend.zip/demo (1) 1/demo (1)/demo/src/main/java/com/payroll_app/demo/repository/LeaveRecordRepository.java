//package com.payroll_app.demo.repository;
//
//import com.payroll_app.demo.dto.LeaveTypeDistributionDTO;
//import com.payroll_app.demo.model.LeaveRecord;
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.data.jpa.repository.Query;
//import org.springframework.stereotype.Repository;
//
//import java.time.LocalDate;
//import java.util.List;
//
//@Repository
//public interface LeaveRecordRepository extends JpaRepository<LeaveRecord, Long> {
//
//    List<LeaveRecord> findByEmployeeId(Long employeeId);
//    List<LeaveRecord> findByIsPaid(boolean isPaid);
//
//    @Query("SELECT new com.payroll_app.demo.dto.LeaveTypeDistributionDTO(" +
//            "l.leaveType, COUNT(l)) " +
//            "FROM LeaveRecord l " +
//            "GROUP BY l.leaveType " +
//            "ORDER BY l.leaveType")
//    List<LeaveTypeDistributionDTO> findLeaveTypeCounts();
//
//    // 🔍 Check if an employee has overlapping leaves
//    @Query("SELECT CASE WHEN COUNT(l) > 0 THEN true ELSE false END " +
//            "FROM LeaveRecord l " +
//            "WHERE l.employee.id = :employeeId " +
//            "AND ((l.startDate <= :endDate) AND (l.endDate >= :startDate))")
//    boolean existsOverlappingLeave(Long employeeId, LocalDate startDate, LocalDate endDate);
//
//}
//
//
//
//
//


package com.payroll_app.demo.repository;

import com.payroll_app.demo.dto.LeaveTypeDistributionDTO;
import com.payroll_app.demo.model.LeaveRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface LeaveRecordRepository extends JpaRepository<LeaveRecord, Long> {

    List<LeaveRecord> findByEmployeeId(Long employeeId);
    List<LeaveRecord> findByIsPaid(boolean isPaid);


    @Query("SELECT new com.payroll_app.demo.dto.LeaveTypeDistributionDTO(" +
            "l.leaveType, COUNT(l)) " +
            "FROM LeaveRecord l " +
            "GROUP BY l.leaveType " +
            "ORDER BY l.leaveType")
    List<LeaveTypeDistributionDTO> findLeaveTypeCounts();

    // 🔍 Check if an employee has overlapping leaves
    @Query("SELECT CASE WHEN COUNT(l) > 0 THEN true ELSE false END " +
            "FROM LeaveRecord l " +
            "WHERE l.employee.id = :employeeId " +
            "AND ((l.startDate <= :endDate) AND (l.endDate >= :startDate))")
    boolean existsOverlappingLeave(Long employeeId, LocalDate startDate, LocalDate endDate);

}





