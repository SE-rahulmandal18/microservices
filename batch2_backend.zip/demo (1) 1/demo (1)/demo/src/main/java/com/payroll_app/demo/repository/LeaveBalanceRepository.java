package com.payroll_app.demo.repository;

import com.payroll_app.demo.model.Employee;
import com.payroll_app.demo.model.LeaveBalance;
import com.payroll_app.demo.model.LeaveRecord;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface LeaveBalanceRepository extends JpaRepository<LeaveBalance, Long> {
    Optional<LeaveBalance> findByEmployeeAndLeaveTypeAndYear(Employee employee, LeaveRecord.LeaveType leaveType, int year);
    List<LeaveBalance> findByEmployee(Employee employee);
}



