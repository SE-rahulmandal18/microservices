package com.payroll_app.demo.service;

import com.payroll_app.demo.dto.CreateEmployeeRequest;
import com.payroll_app.demo.dto.UpdateEmployeeRequest;
import com.payroll_app.demo.model.Employee;
import com.payroll_app.demo.model.LeaveBalance;
import com.payroll_app.demo.model.LeaveRecord;
import com.payroll_app.demo.model.User;
import com.payroll_app.demo.repository.EmployeeRepository;
import com.payroll_app.demo.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Year;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class EmployeeService {

    private final EmployeeRepository employeeRepository;
    private final UserRepository userRepository;
    private final LeaveBalanceService leaveBalanceService;

    private static final Logger logger = LoggerFactory.getLogger(EmployeeService.class);

    @Transactional
    public Employee createEmployee(CreateEmployeeRequest request) {
        logger.info("Creating employee for user ID: {}", request.getUserId());

        User user = userRepository.findById(request.getUserId())
                .orElseThrow(() -> {
                    logger.error("User not found with ID: {}", request.getUserId());
                    return new RuntimeException("User not found");
                });

        Employee employee = new Employee();
        employee.setUser(user);
        employee.setFirstName(request.getFirstName());
        employee.setLastName(request.getLastName());
        employee.setEmail(request.getEmail());
        employee.setPhone(request.getPhone());
        employee.setDepartment(request.getDepartment());
        employee.setDesignation(request.getDesignation());
        employee.setJoinDate(request.getJoinDate());
        employee.setEmploymentType(request.getEmploymentType());
        employee.setBankAccount(request.getBankAccount());
        employee.setStatus(request.getStatus() != null ? request.getStatus() : Employee.EmployeeStatus.ACTIVE);

        Employee savedEmployee = employeeRepository.save(employee);
        logger.info("Employee created with ID: {}", savedEmployee.getId());

        int currentYear = Year.now().getValue();
        for (LeaveRecord.LeaveType type : LeaveRecord.LeaveType.values()) {
            double defaultDays = getDefaultLeaveDays(type);

            LeaveBalance balance = new LeaveBalance();
            balance.setEmployee(savedEmployee);
            balance.setLeaveType(type);
            balance.setYear(currentYear);
            balance.setTotalAllowed(defaultDays);
            balance.setUsed(0);

            leaveBalanceService.saveLeaveBalance(balance);
        }

        logger.info("Leave balances initialized for employee ID: {}", savedEmployee.getId());
        return savedEmployee;
    }

    private double getDefaultLeaveDays(LeaveRecord.LeaveType type) {
        return switch (type) {
            case CASUAL -> 10;
            case SICK -> 10;
            case UNPAID -> 0;
            case ANNUAL -> 12;
            default -> 0;
        };
    }

    public List<Employee> getAllEmployees() {
        logger.info("Fetching all employees");
        return employeeRepository.findAll();
    }

    public Optional<Employee> getEmployeeById(Long id) {
        logger.info("Fetching employee by ID: {}", id);
        return employeeRepository.findById(id);
    }

    @Transactional
    public Employee updateEmployee(Long id, UpdateEmployeeRequest updateRequest) {
        logger.info("Updating employee with ID: {}", id);

        Employee employee = employeeRepository.findById(id)
                .orElseThrow(() -> {
                    logger.error("Employee not found with ID: {}", id);
                    return new RuntimeException("Employee not found");
                });

        if (updateRequest.getFirstName() != null) employee.setFirstName(updateRequest.getFirstName());
        if (updateRequest.getLastName() != null) employee.setLastName(updateRequest.getLastName());
        if (updateRequest.getEmail() != null) employee.setEmail(updateRequest.getEmail());
        if (updateRequest.getPhone() != null) employee.setPhone(updateRequest.getPhone());
        if (updateRequest.getDepartment() != null) employee.setDepartment(updateRequest.getDepartment());
        if (updateRequest.getDesignation() != null) employee.setDesignation(updateRequest.getDesignation());
        if (updateRequest.getJoinDate() != null) employee.setJoinDate(updateRequest.getJoinDate());
        if (updateRequest.getEmploymentType() != null) employee.setEmploymentType(updateRequest.getEmploymentType());
        if (updateRequest.getBankAccount() != null) employee.setBankAccount(updateRequest.getBankAccount());
        if (updateRequest.getStatus() != null) employee.setStatus(updateRequest.getStatus());

        Employee updated = employeeRepository.save(employee);
        logger.info("Employee updated with ID: {}", updated.getId());

        return updated;
    }

    public void deleteEmployee(Long id) {
        logger.info("Deleting employee with ID: {}", id);
        if (!employeeRepository.existsById(id)) {
            logger.error("Attempted to delete non-existent employee with ID: {}", id);
            throw new RuntimeException("Employee not found with ID: " + id);
        }
        employeeRepository.deleteById(id);
        logger.info("Employee deleted with ID: {}", id);
    }

    public Employee findByUser(User user) {
        logger.info("Finding employee by user ID: {}", user.getId());
        return employeeRepository.findByUser(user).orElse(null);
    }
}
