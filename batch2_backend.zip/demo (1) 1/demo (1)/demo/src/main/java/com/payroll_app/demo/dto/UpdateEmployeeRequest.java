package com.payroll_app.demo.dto;

import com.payroll_app.demo.model.Employee;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
public class UpdateEmployeeRequest {
    private String firstName;
    private String lastName;
    @Email(message = "Invalid email format")
    private String email;
    @Size(min = 10, max = 15, message = "Phone must be 10–15 characters")
    private String phone;
    private String department;
    private String designation;
    private LocalDate joinDate;
    private Employee.EmploymentType employmentType;
    private String bankAccount;
    private Employee.EmployeeStatus status;
}
