package com.payroll_app.demo.dto;

import com.payroll_app.demo.model.LeaveRecord;
import com.payroll_app.demo.model.LeaveRecord.LeaveType;
import jakarta.validation.constraints.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
public class LeaveRecordRequest {

    @NotNull(message = "Employee ID is required")
    private Long employeeId;

    @NotNull(message = "Start date is required")

    private LocalDate startDate;

    @NotNull(message = "End date is required")
    private LocalDate endDate;

    @NotNull(message = "Leave type is required")
    private LeaveType leaveType;

    @NotNull(message = "Leave paid status must be specified")
    private Boolean isPaid;

    private LeaveRecord.LeaveDuration durationPerDay;

}
