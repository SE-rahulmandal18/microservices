package com.payroll_app.demo.model;

import jakarta.persistence.*;
import lombok.*;
import com.fasterxml.jackson.annotation.JsonIgnore;
import java.time.Year;

@Entity
@Table(name = "leave_balances", uniqueConstraints = {
        @UniqueConstraint(columnNames = {"employee_id", "leave_type", "year"})
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class LeaveBalance {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "employee_id", nullable = false)
    @JsonIgnore
    private Employee employee;

    @Enumerated(EnumType.STRING)
    @Column(name = "leave_type", nullable = false)
    private LeaveRecord.LeaveType leaveType;

    @Column(nullable = false)
    private int year;

    @Column(nullable = false)
    private double totalAllowed;

    @Column(nullable = false)
    private double used;

    public double getRemaining() {
        return totalAllowed - used;
    }

    public void useLeave(double days) {
        this.used += days;
    }

    public void recreditLeave(double days) {
        this.used = Math.max(0, this.used - days);
    }
}
