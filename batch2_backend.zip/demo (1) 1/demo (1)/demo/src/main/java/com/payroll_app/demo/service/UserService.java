package com.payroll_app.demo.service;

import com.payroll_app.demo.model.PasswordResetToken;
import com.payroll_app.demo.model.User;
import com.payroll_app.demo.repository.PasswordResetTokenRepository;
import com.payroll_app.demo.repository.UserRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.time.LocalDateTime;
import java.util.Random;

@Service
@RequiredArgsConstructor
@Transactional

public class UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final PasswordResetTokenRepository passwordResetTokenRepository;
    private final EmailService emailService;

    private static final Logger logger = LoggerFactory.getLogger(UserService.class);

    public User createUser(User user) {
        user.setPasswordHash(passwordEncoder.encode(user.getPasswordHash()));
        User savedUser = userRepository.save(user);
        logger.info("Created new user with ID: {}", savedUser.getId());
        return savedUser;
    }

    public Optional<User> getUserById(Long id) {
        logger.debug("Fetching user by ID: {}", id);
        return userRepository.findById(id);
    }

    public Optional<User> getUserByUsername(String username) {
        logger.debug("Fetching user by username: {}", username);
        return userRepository.findByUsername(username);
    }

    public User findByUsername(String username) {
        return userRepository.findByUsername(username)
                .orElseThrow(() -> {
                    logger.warn("User not found with username: {}", username);
                    return new UsernameNotFoundException("User not found");
                });
    }

    public Optional<User> getUserByEmail(String email) {
        logger.debug("Fetching user by email: {}", email);
        return userRepository.findByEmail(email);
    }

    public List<User> getAllUsers() {
        logger.info("Fetching all users");
        return userRepository.findAll();
    }

    public User updateUser(Long id, User updatedUser) {
        logger.info("Updating user with ID: {}", id);
        return userRepository.findById(id)
                .map(user -> {
                    user.setUsername(updatedUser.getUsername());
                    if (updatedUser.getPasswordHash() != null && !updatedUser.getPasswordHash().isEmpty()) {
                        user.setPasswordHash(passwordEncoder.encode(updatedUser.getPasswordHash()));
                    }
                    user.setEmail(updatedUser.getEmail());
                    user.setRole(updatedUser.getRole());
                    return userRepository.save(user);
                })
                .orElseThrow(() -> {
                    logger.error("User not found with ID: {}", id);
                    return new RuntimeException("User not found with ID: " + id);
                });
    }

    public void deleteUser(Long id) {
        logger.info("Deleting user with ID: {}", id);
        if (!userRepository.existsById(id)) {
            logger.warn("Attempted to delete non-existing user with ID: {}", id);
            throw new RuntimeException("User not found with ID: " + id);
        }
        userRepository.deleteById(id);
    }

    public boolean authenticate(String username, String rawPassword) {
        logger.info("Authenticating user: {}", username);
        Optional<User> userOptional = userRepository.findByUsername(username);
        boolean authenticated = userOptional
                .map(user -> passwordEncoder.matches(rawPassword, user.getPasswordHash()))
                .orElse(false);
        if (!authenticated) {
            logger.warn("Authentication failed for username: {}", username);
        }
        return authenticated;
    }

    public boolean validateSimulatedOtp(String email, String otp) {
        PasswordResetToken token = passwordResetTokenRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Invalid token or email"));

        // Validate OTP expiration time
        if (token.getExpirationTime().isBefore(LocalDateTime.now())) {
            throw new RuntimeException("Token has expired");
        }

        // Return true if OTP matches
        return token.getToken().equals(otp);
    }

    public String sendOtp(String email) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("No user found with that email"));

        // Generate OTP
        String otp = String.valueOf(100000 + new Random().nextInt(900000)); // 6-digit OTP
        LocalDateTime expiry = LocalDateTime.now().plusMinutes(10); // OTP valid for 10 minutes

        // Save or update token
        PasswordResetToken token = passwordResetTokenRepository.findByEmail(email)
                .orElse(new PasswordResetToken());
        token.setToken(otp);
        token.setEmail(email);
        token.setExpirationTime(expiry);
        passwordResetTokenRepository.save(token);

        return otp; // Return OTP in plain text for simulation
    }

    public void resetPassword(User user, String newPassword) {
        user.setPasswordHash(passwordEncoder.encode(newPassword)); // Hash the new password
        userRepository.save(user); // Save updated user
    }

    public String hashPassword(String password) {
        return passwordEncoder.encode(password);
    }

    // Verify OTP and reset password
    public void verifyOtpAndReset(String email, String otp, String newPassword) {
        PasswordResetToken token = passwordResetTokenRepository.findByToken(otp)
                .orElseThrow(() -> new RuntimeException("Invalid token"));

        if (token.getExpirationTime().isBefore(LocalDateTime.now())) {
            throw new RuntimeException("Token has expired");
        }

        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));

        user.setPasswordHash(passwordEncoder.encode(newPassword));
        userRepository.save(user);

        // Clean up the token
        passwordResetTokenRepository.delete(token);
    }

}
