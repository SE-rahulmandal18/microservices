package com.payroll_app.demo.controller;

import com.payroll_app.demo.dto.*;
import com.payroll_app.demo.model.User;
import com.payroll_app.demo.security.JwtUtil;
import com.payroll_app.demo.service.UserService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.*;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.*;


import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AuthenticationManager authManager;
    private final JwtUtil jwtUtil;
    private final UserDetailsService userDetailsService;
    private final UserService userService;

    @PostMapping("/login")
    public LoginResponse login(@RequestBody LoginRequest request) {
        Authentication authentication = authManager.authenticate(
                new UsernamePasswordAuthenticationToken(request.getUsername(), request.getPassword()));

        UserDetails userDetails = userDetailsService.loadUserByUsername(request.getUsername());
        User user = userService.getUserByUsername(request.getUsername())
                .orElseThrow(() -> new UsernameNotFoundException("User not found"));

        String token = jwtUtil.generateToken(userDetails.getUsername(), user.getRole().name());
        return new LoginResponse(token, userDetails.getUsername(), user.getRole().name());
    }

    @PostMapping("/register")
    public ResponseEntity<String> register(@Valid @RequestBody RegisterRequest request) {
        // Check if user already exists
        if (userService.getUserByUsername(request.getUsername()).isPresent()) {
            return ResponseEntity.badRequest().body("Username already exists!");
        }

        // Create and save the user
        User newUser = new User();
        newUser.setUsername(request.getUsername());
        newUser.setEmail(request.getEmail());
        newUser.setPasswordHash(request.getPassword()); // Will be encoded inside createUser()
        newUser.setRole(User.Role.valueOf(request.getRole()));

        userService.createUser(newUser);

        return ResponseEntity.ok("User registered successfully!");
    }

    // Step 1: Send OTP to email

    @PostMapping("/forgot-password")
    public ResponseEntity<Map<String, String>> sendOtp(@Valid @RequestBody ForgotPasswordRequest request) {
        try {
            String generatedOtp = userService.sendOtp(request.getEmail()); // Generate OTP

            Map<String, String> response = new HashMap<>();
            response.put("message", "OTP generated successfully (shown on screen for simulation).");
            response.put("otp", generatedOtp);  // Include the generated OTP in the response for frontend
            return ResponseEntity.ok(response);  // Return OTP and message in the response
        } catch (RuntimeException ex) {
            Map<String, String> response = new HashMap<>();
            response.put("error", ex.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);  // Return error if any
        }
    }



    // Step 2: Verify OTP and Reset Password in one step
    @PostMapping("/verify-otp")
    public ResponseEntity<String> verifyOtp(@Valid @RequestBody VerifyOtpRequest request) {
        try {
            userService.verifyOtpAndReset(request.getEmail(), request.getOtp(), request.getNewPassword());
            return ResponseEntity.ok("Password reset successful.");
        } catch (RuntimeException ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        }
    }

    @PostMapping("/reset-password")
    public ResponseEntity<Map<String, String>> resetPassword(@Valid @RequestBody ResetPasswordRequest request) {
        User user = userService.getUserByEmail(request.getEmail())
                .orElseThrow(() -> new UsernameNotFoundException("User not found"));

        boolean isOtpValid = userService.validateSimulatedOtp(request.getEmail(), request.getOtp());
        if (!isOtpValid) {
            Map<String, String> error = new HashMap<>();
            error.put("message", "Invalid OTP.");
            return ResponseEntity.badRequest().body(error);
        }

        userService.resetPassword(user, request.getNewPassword());

        Map<String, String> response = new HashMap<>();
        response.put("message", "Password has been reset successfully!");
        return ResponseEntity.ok(response);
    }
}
