package com.payroll_app.demo.dto;

import lombok.Data;

import java.time.LocalDate;
import java.time.LocalTime;

@Data
public class UpdateAttendanceRequest {
    private LocalDate workDate;
    private LocalTime checkInTime;
    private LocalTime checkOutTime;
}
