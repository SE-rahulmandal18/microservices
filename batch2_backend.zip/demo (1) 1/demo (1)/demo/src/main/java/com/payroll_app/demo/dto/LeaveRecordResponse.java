package com.payroll_app.demo.dto;

import com.payroll_app.demo.model.LeaveRecord;
import com.payroll_app.demo.model.LeaveRecord.LeaveType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
@Builder
@AllArgsConstructor
public class LeaveRecordResponse {

    private Long id;
    private Long employeeId;
    private String employeeName;

    private LocalDate startDate;
    private LocalDate endDate;
    private LeaveType leaveType;
    private boolean isPaid;
    private LeaveRecord.LeaveDuration durationPerDay;

    private double totalLeaveDays;
    private double lopDays;

}
