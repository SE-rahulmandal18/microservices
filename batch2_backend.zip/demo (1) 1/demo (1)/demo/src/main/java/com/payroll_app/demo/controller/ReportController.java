package com.payroll_app.demo.controller;

import com.payroll_app.demo.dto.LeaveTypeDistributionDTO;
import com.payroll_app.demo.dto.OvertimeTrendDTO;
import com.payroll_app.demo.dto.PayrollTrendDTO;
import com.payroll_app.demo.service.ReportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/reports")
public class ReportController {

    @Autowired
    private ReportService reportService;

    @GetMapping("/payroll-trends")
    public List<PayrollTrendDTO> getPayrollTrends(@RequestParam int year) {
        return reportService.getPayrollTrends(year);
    }

    @GetMapping("/leave-distribution")
    public List<LeaveTypeDistributionDTO> getLeaveDistribution() {
        return reportService.getLeaveDistribution();
    }

    @GetMapping("/overtime-trends")
    public List<OvertimeTrendDTO> getOvertimeTrends() {
        return reportService.getOvertimeTrends();
    }
}




