package com.payroll_app.demo.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;

@Entity
@Table(name = "attendance")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Attendance {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "employee_id", nullable = false)
    private Employee employee;

    @Column(nullable = false)
    private LocalDate workDate;

    @Column(nullable = false)
    private LocalTime checkInTime;

    @Column(nullable = false)
    private LocalTime checkOutTime;

    @Column(nullable = false)
    private BigDecimal totalHours;

    @Column(nullable = false)
    private BigDecimal overtimeHours = BigDecimal.ZERO;

    @PrePersist
    @PreUpdate
    public void calculateTotalHours() {
        long secondsWorked = Duration.between(checkInTime, checkOutTime).getSeconds();
        this.totalHours = BigDecimal.valueOf(secondsWorked)
                .divide(BigDecimal.valueOf(3600), 2, RoundingMode.HALF_UP);

        // Define standard working hours (e.g., 8 hours)
        BigDecimal standardHours = BigDecimal.valueOf(8);

        // If totalHours > standardHours → calculate overtime
        if (this.totalHours.compareTo(standardHours) > 0) {
            this.overtimeHours = this.totalHours.subtract(standardHours);
        } else {
            this.overtimeHours = BigDecimal.ZERO;
        }
    }

}

