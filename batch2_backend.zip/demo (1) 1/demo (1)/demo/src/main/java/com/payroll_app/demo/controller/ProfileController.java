package com.payroll_app.demo.controller;

import com.payroll_app.demo.dto.ProfileDTO;
import com.payroll_app.demo.service.ProfileService;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.auth0.jwt.JWT;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.auth0.jwt.exceptions.JWTDecodeException;

@RestController
@RequestMapping("/api/users/me")
public class ProfileController {

    @Autowired
    private ProfileService profileService;

    @GetMapping
    public ProfileDTO getProfile(@RequestHeader("Authorization") String authHeader) {
        String username = extractUsernameFromAuthHeader(authHeader);
        return profileService.getProfile(username);
    }

    @PutMapping
    public String updateProfile(@RequestHeader("Authorization") String authHeader, @RequestBody ProfileDTO profileDTO) {
        String username = extractUsernameFromAuthHeader(authHeader);
        if (profileService.updateProfile(username, profileDTO)) {
            return "Profile updated successfully!";
        } else {
            return "Failed to update profile.";
        }
    }

    @PutMapping("/password")
    public String changePassword(@RequestHeader("Authorization") String authHeader, @RequestBody ChangePasswordRequest changePasswordRequest) {
        String username = extractUsernameFromAuthHeader(authHeader);
        if (profileService.changePassword(username, changePasswordRequest.getCurrentPassword(), changePasswordRequest.getNewPassword())) {
            return "Password updated successfully!";
        } else {
            return "Failed to update password.";
        }
    }

    private String extractUsernameFromAuthHeader(String authHeader) {
        // Extract the token from the Authorization header (Bearer <token>)
        String token = authHeader.replace("Bearer ", "");

        // Decode the JWT token and extract the username (sub claim)
        try {
            DecodedJWT decodedJWT = JWT.decode(token);
            return decodedJWT.getSubject();  // This will be the "sub" field from your JWT (i.e., the username)
        } catch (JWTDecodeException e) {
            throw new RuntimeException("Invalid JWT token");
        }
    }

    @Data
    public static class ChangePasswordRequest {
        private String currentPassword;
        private String newPassword;
    }
}
