package com.payroll_app.demo.service;



import com.payroll_app.demo.model.*;

import com.payroll_app.demo.repository.*;

import org.springframework.security.core.Authentication;

import org.springframework.security.core.context.SecurityContextHolder;

import org.springframework.stereotype.Service;



import java.util.*;

import java.util.stream.Collectors;



@Service

public class ChatService {



    private final EmployeeRepository employeeRepository;

    private final PayrollRepository payrollRepository;

    private final AttendanceRepository attendanceRepository;

    private final LeaveRecordRepository leaveRecordRepository;

    private final AuditLogRepository auditLogRepository;

    private final TransactionRepository transactionRepository;

    private final UserRepository userRepository;



    public ChatService(EmployeeRepository employeeRepository,

                       PayrollRepository payrollRepository,

                       AttendanceRepository attendanceRepository,

                       LeaveRecordRepository leaveRecordRepository,

                       AuditLogRepository auditLogRepository,

                       TransactionRepository transactionRepository,

                       UserRepository userRepository) {

        this.employeeRepository = employeeRepository;

        this.payrollRepository = payrollRepository;

        this.attendanceRepository = attendanceRepository;

        this.leaveRecordRepository = leaveRecordRepository;

        this.auditLogRepository = auditLogRepository;

        this.transactionRepository = transactionRepository;

        this.userRepository = userRepository;

    }



    public Map<String, String> chat(String message) {

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        String username = authentication.getName();

        User user = userRepository.findByUsername(username)

                .orElseThrow(() -> new RuntimeException("User not found"));



        String role = user.getRole().name();

        Employee employee = employeeRepository.findByUser(user).orElse(null);

        Long employeeId = employee != null ? employee.getId() : null;



        String welcomeMessage = "👋 Welcome, " + username + "! (" + role + ")\n\n";



        String lowerMessage = message.toLowerCase().trim();



        if (lowerMessage.equals("help")) {

            return Map.of("response", welcomeMessage + getRoleSpecificHelpMessage(role));

        }



        if (lowerMessage.startsWith("get ")) {

            try {

                String response = handleDataQuery(lowerMessage.substring(4), user, role, employeeId);

                return Map.of("response", welcomeMessage + response);

            } catch (SecurityException e) {

                return Map.of("error", "🚫 Access Denied: " + e.getMessage());

            } catch (Exception e) {

                return Map.of("error", "❌ Error: " + e.getMessage());

            }

        }



        return Map.of("response", welcomeMessage +

                "🤖 I can answer data queries. Type 'help' for role-specific assistance.");

    }



    private String getRoleSpecificHelpMessage(String role) {

        switch (role) {

            case "HR":

                return getHrHelpMessage();

            case "ADMIN":

                return getAdminHelpMessage();

            case "EMPLOYEE":

                return getEmployeeHelpMessage();

            default:

                return "Your role doesn't have specific help commands.";

        }

    }



    private String getHrHelpMessage() {

        return "📌 **HR Help Center** 👩‍💼\n\n" +

                "👥 Employee Data:\n" +

                "├─ 👥 Get employee count\n" +

                "├─ 📋 Get employee list\n" +

                "├─ 🏢 Get employees in [department]\n" +

                "├─ ✅ Get active employees\n" +

                "└─ ❌ Get inactive employees\n\n" +

                "💰 Payroll Data:\n" +

                "├─ 💵 Get payroll total\n" +

                "├─ 📊 Get payroll average\n" +

                "└─ 👤 Get payroll for [employee_id]\n\n" +

                "⏱️ Attendance:\n" +

                "├─ 📅 Get attendance count\n" +

                "└─ 👤 Get attendance for [employee_id]\n\n" +

                "🏖️ Leaves:\n" +

                "├─ ❌ Get unpaid leaves\n" +

                "├─ ✅ Get paid leaves\n" +

                "└─ 📋 Get all leaves";

    }



    private String getAdminHelpMessage() {

        return "🔒 **Admin Dashboard** ⚙️\n\n" +

                "📊 System Data:\n" +

                "├─ 👥 Get user count\n" +

                "├─ 📜 Get audit logs\n" +

                "└─ ⏱️ Get last 5 audit logs\n\n" +

                "💳 Financial:\n" +

                "├─ 🔢 Get total transactions\n" +

                "├─ ❌ Get failed transactions\n" +

                "├─ ⏳ Get pending transactions\n" +

                "├─ ✅ Get successful transactions\n" +

                "└─ ⏱️ Get last 5 transactions";

    }



    private String getEmployeeHelpMessage() {

        return "👤 **Employee Self-Service** 💼\n\n" +

                "📋 My Data:\n" +

                "├─ ℹ️ Get my details\n" +

                "├─ ⏱️ Get my attendance\n" +

                "└─ 🏖️ Get my leaves\n\n" +

                "💰 Payroll:\n" +

                "├─ 💵 Get my payroll\n" +

                "└─ ⏱️ Get my last payment";

    }



    private String handleDataQuery(String query, User user, String role, Long employeeId) {

        // Employee queries

        if (query.startsWith("employee count")) {

            checkRoleAccess(role, "HR");

            long count = employeeRepository.count();

            return "👥 **Employee Count**\n\n" +

                    "│ Total Employees: " + count + "\n" +

                    "│ ✅ Active: " + employeeRepository.findByStatus(Employee.EmployeeStatus.ACTIVE).size() + "\n" +

                    "│ ❌ Inactive: " + employeeRepository.findByStatus(Employee.EmployeeStatus.INACTIVE).size();

        }

        else if (query.startsWith("employee list")) {

            checkRoleAccess(role, "HR");

            return "📋 **Employee List**\n\n" + formatEmployeeList(employeeRepository.findAll());

        }

        else if (query.startsWith("employees in ")) {

            checkRoleAccess(role, "HR");

            String dept = query.substring(13);

            List<Employee> employees = employeeRepository.findByDepartment(dept);

            return "🏢 **Employees in " + dept + " Department**\n\n" +

                    formatEmployeeList(employees) + "\n\n" +

                    "│ Total: " + employees.size();

        }

        else if (query.startsWith("active employees")) {

            checkRoleAccess(role, "HR");

            return "✅ **Active Employees**\n\n" +

                    formatEmployeeList(employeeRepository.findByStatus(Employee.EmployeeStatus.ACTIVE));

        }

        else if (query.startsWith("inactive employees")) {

            checkRoleAccess(role, "HR");

            return "❌ **Inactive Employees**\n\n" +

                    formatEmployeeList(employeeRepository.findByStatus(Employee.EmployeeStatus.INACTIVE));

        }



        // Payroll queries

        else if (query.startsWith("payroll total")) {

            checkRoleAccess(role, "HR");

            double total = calculateTotalPayroll();

            double avg = calculateAverageSalary();

            return "💰 **Payroll Summary**\n\n" +

                    "│ Total Amount: $" + String.format("%.2f", total) + "\n" +

                    "│ Average Salary: $" + String.format("%.2f", avg);

        }

        else if (query.startsWith("payroll average")) {

            checkRoleAccess(role, "HR");

            return "📊 **Average Salary**\n\n" +

                    "│ $" + String.format("%.2f", calculateAverageSalary());

        }

        else if (query.startsWith("payroll for ")) {

            checkRoleAccess(role, "HR");

            Long id = Long.parseLong(query.substring(12));

            return "💵 **Payroll Details**\n\n" +

                    formatPayrollDetails(payrollRepository.findByEmployeeId(id));

        }

        else if (query.startsWith("my payroll") || query.startsWith("get my payroll")) {

            if (employeeId == null) {

                throw new SecurityException("Employee record not found for your account");

            }

            return "💵 **My Payroll Details**\n\n" +

                    formatPayrollDetails(payrollRepository.findByEmployeeId(employeeId));

        }

        else if (query.startsWith("my last payment")) {

            if (employeeId == null) {

                throw new SecurityException("Employee record not found for your account");

            }

            List<Payroll> payrolls = payrollRepository.findByEmployeeIdOrderByIdDesc(employeeId);

            if (!payrolls.isEmpty()) {

                return "⏱️ **My Last Payment**\n\n" +

                        formatPayrollDetails(Collections.singletonList(payrolls.get(0)));

            }

            return "❌ No payroll records found for you";

        }



        // Attendance queries

        else if (query.startsWith("attendance count")) {

            checkRoleAccess(role, "HR");

            return "📅 **Attendance Records**\n\n" +

                    "│ Total: " + attendanceRepository.count();

        }

        else if (query.startsWith("attendance for ")) {

            checkRoleAccess(role, "HR");

            Long id = Long.parseLong(query.substring(15));

            return "⏱️ **Attendance for Employee " + id + "**\n\n" +

                    formatAttendanceList(attendanceRepository.findByEmployeeId(id));

        }

        else if (query.startsWith("my attendance")) {

            if (employeeId == null) {

                throw new SecurityException("Employee record not found for your account");

            }

            return "⏱️ **My Attendance**\n\n" +

                    formatAttendanceList(attendanceRepository.findByEmployeeId(employeeId));

        }



        // Leave queries

        else if (query.startsWith("unpaid leaves")) {

            checkRoleAccess(role, "HR");

            List<LeaveRecord> leaves = leaveRecordRepository.findByIsPaid(false);

            return "❌ **Unpaid Leaves**\n\n" +

                    "│ Total: " + leaves.size() + "\n\n" +

                    formatLeaveList(leaves);

        }

        else if (query.startsWith("paid leaves")) {

            checkRoleAccess(role, "HR");

            List<LeaveRecord> leaves = leaveRecordRepository.findByIsPaid(true);

            return "✅ **Paid Leaves**\n\n" +

                    "│ Total: " + leaves.size() + "\n\n" +

                    formatLeaveList(leaves);

        }

        else if (query.startsWith("all leaves")) {

            checkRoleAccess(role, "HR");

            List<LeaveRecord> leaves = leaveRecordRepository.findAll();

            return "📋 **All Leaves**\n\n" +

                    "│ Total: " + leaves.size() + "\n\n" +

                    formatLeaveList(leaves);

        }

        else if (query.startsWith("my leaves")) {

            if (employeeId == null) {

                throw new SecurityException("Employee record not found for your account");

            }

            List<LeaveRecord> leaves = leaveRecordRepository.findByEmployeeId(employeeId);

            return "🏖️ **My Leaves**\n\n" +

                    "│ Total: " + leaves.size() + "\n\n" +

                    formatLeaveList(leaves);

        }



        // Admin queries

        else if (query.startsWith("user count")) {

            checkRoleAccess(role, "ADMIN");

            return "👥 **User Count**\n\n" +

                    "│ Total: " + userRepository.count();

        }

        else if (query.startsWith("audit logs")) {

            checkRoleAccess(role, "ADMIN");

            return "📜 **Audit Logs**\n\n" +

                    "│ Total: " + auditLogRepository.count();

        }

        else if (query.startsWith("last 5 audit logs")) {

            checkRoleAccess(role, "ADMIN");

            return "⏱️ **Recent Audit Logs**\n\n" +

                    formatAuditLogs(auditLogRepository.findTop5ByOrderByPerformedAtDesc());

        }

        else if (query.startsWith("total transactions")) {

            checkRoleAccess(role, "ADMIN");

            return "🔢 **Transaction Summary**\n\n" +

                    "│ Total: " + transactionRepository.count();

        }

        else if (query.startsWith("failed transactions")) {

            checkRoleAccess(role, "ADMIN");

            return "❌ **Failed Transactions**\n\n" +

                    formatTransactions(transactionRepository.findByStatus(Transaction.TransactionStatus.FAILED));

        }

        else if (query.startsWith("pending transactions")) {

            checkRoleAccess(role, "ADMIN");

            return "⏳ **Pending Transactions**\n\n" +

                    formatTransactions(transactionRepository.findByStatus(Transaction.TransactionStatus.PENDING));

        }

        else if (query.startsWith("successful transactions")) {

            checkRoleAccess(role, "ADMIN");

            return "✅ **Successful Transactions**\n\n" +

                    formatTransactions(transactionRepository.findByStatus(Transaction.TransactionStatus.SUCCESS));

        }

        else if (query.startsWith("last 5 transactions")) {

            checkRoleAccess(role, "ADMIN");

            return "⏱️ **Recent Transactions**\n\n" +

                    formatTransactions(transactionRepository.findTop5ByOrderByTransactionDateDesc());

        }



        // Employee details

        else if (query.startsWith("my details")) {

            if (employeeId == null) {

                throw new SecurityException("Employee record not found for your account");

            }

            Employee employee = employeeRepository.findById(employeeId)

                    .orElseThrow(() -> new RuntimeException("Employee not found"));

            return "👤 **My Details**\n\n" +

                    formatEmployeeDetails(employee);

        }

        else {

            return "🤔 I didn't understand your query. Type 'help' for assistance.";

        }

    }



    private void checkRoleAccess(String userRole, String requiredRole) {

        if (!userRole.equals(requiredRole)) {

            throw new SecurityException("This command is only available to " + requiredRole + " users");

        }

    }



    private String formatEmployeeList(List<Employee> employees) {

        if (employees.isEmpty()) return "│ No employees found";



        return employees.stream()

                .limit(10)

                .map(e -> "│ " + e.getId() + ": " + e.getFirstName() + " " + e.getLastName() +

                        " (" + e.getDepartment() + ", " + e.getStatus() + ")")

                .collect(Collectors.joining("\n")) +

                (employees.size() > 10 ? "\n│ ...and " + (employees.size() - 10) + " more" : "");

    }



    private String formatEmployeeDetails(Employee employee) {

        if (employee == null) return "│ Employee not found";



        return "│ ID: " + employee.getId() + "\n" +

                "│ Name: " + employee.getFirstName() + " " + employee.getLastName() + "\n" +

                "│ Email: " + employee.getEmail() + "\n" +

                "│ Phone: " + employee.getPhone() + "\n" +

                "│ Department: " + employee.getDepartment() + "\n" +

                "│ Designation: " + employee.getDesignation() + "\n" +

                "│ Status: " + employee.getStatus() + "\n" +

                "│ Join Date: " + employee.getJoinDate() + "\n" +

                "│ Bank Account: " + employee.getBankAccount();

    }



    private String formatPayrollDetails(List<Payroll> payrolls) {

        if (payrolls.isEmpty()) return "│ No payroll records found";



        return payrolls.stream()

                .map(p -> "│ Payroll ID: " + p.getId() + "\n" +

                        "│ Employee: " + p.getEmployee().getFirstName() + " " + p.getEmployee().getLastName() + "\n" +

                        "│ Basic Salary: $" + String.format("%.2f", p.getBasicSalary()) + "\n" +

                        "│ Allowances: $" + String.format("%.2f", p.getAllowances()) + "\n" +

                        "│ Bonuses: $" + String.format("%.2f", p.getBonuses()) + "\n" +

                        "│ Deductions: $" + String.format("%.2f", p.getDeductions()) + "\n" +

                        "│ Net Salary: $" + String.format("%.2f", p.getNetSalary()) + "\n" +

                        "│ Status: " + p.getPaymentStatus() + "\n" +

                        "│ Processed: " + (p.getProcessedAt() != null ? p.getProcessedAt().toString() : "Not processed"))

                .collect(Collectors.joining("\n\n"));

    }



    private String formatLeaveList(List<LeaveRecord> leaves) {

        if (leaves.isEmpty()) return "│ No leave records found";



        return leaves.stream()

                .limit(5)

                .map(l -> "│ " + l.getId() + ": " + l.getStartDate() + " to " + l.getEndDate() +

                        " (" + l.getLeaveType() + ", " + (l.isPaid() ? "✅ Paid" : "❌ Unpaid") + ")")

                .collect(Collectors.joining("\n")) +

                (leaves.size() > 5 ? "\n│ ...and " + (leaves.size() - 5) + " more" : "");

    }



    private String formatAttendanceList(List<Attendance> records) {

        if (records.isEmpty()) return "│ No attendance records found";



        return records.stream()

                .limit(5)

                .map(a -> "│ " + a.getWorkDate() + ": " + a.getCheckInTime() + " to " +

                        a.getCheckOutTime() + " (" + String.format("%.2f", a.getTotalHours().doubleValue()) + " hrs)")

                .collect(Collectors.joining("\n")) +

                (records.size() > 5 ? "\n│ ...and " + (records.size() - 5) + " more" : "");

    }



    private String formatTransactions(List<Transaction> transactions) {

        if (transactions.isEmpty()) return "│ No transactions found";



        return transactions.stream()

                .limit(5)

                .map(t -> "│ " + t.getId() + ": " + t.getEmployee().getFirstName() +

                        " - " + getStatusEmoji(t.getStatus()) + " " + t.getStatus() +

                        " ($" + String.format("%.2f", t.getAmount()) + ") on " + t.getTransactionDate())

                .collect(Collectors.joining("\n")) +

                (transactions.size() > 5 ? "\n│ ...and " + (transactions.size() - 5) + " more" : "");

    }



    private String getStatusEmoji(Transaction.TransactionStatus status) {

        return status == Transaction.TransactionStatus.SUCCESS ? "✅" :

                status == Transaction.TransactionStatus.FAILED ? "❌" : "⏳";

    }



    private String formatAuditLogs(List<AuditLog> logs) {

        if (logs.isEmpty()) return "│ No audit logs found";



        return logs.stream()

                .map(l -> "│ " + l.getAction() + ": " + l.getDetails() +

                        " by 👤" + l.getPerformedBy().getUsername() + " at " + l.getPerformedAt())

                .collect(Collectors.joining("\n"));

    }



    private double calculateTotalPayroll() {

        return payrollRepository.findAll().stream()

                .mapToDouble(p -> p.getNetSalary().doubleValue())

                .sum();

    }



    private double calculateAverageSalary() {

        return payrollRepository.findAll().stream()

                .mapToDouble(p -> p.getNetSalary().doubleValue())

                .average()

                .orElse(0);

    }



    public List<String> getCommonQuestions() {

        return List.of(

                "help",

                "get employee count",

                "get employee list",

                "get active employees",

                "get payroll total",

                "get my payroll",

                "get my last payment",

                "get attendance count",

                "get my attendance",

                "get unpaid leaves",

                "get paid leaves",

                "get my leaves",

                "get user count",

                "get audit logs",

                "get last 5 audit logs",

                "get total transactions",

                "get failed transactions",

                "get pending transactions",

                "get successful transactions",

                "get last 5 transactions",

                "get my details"

        );

    }

}