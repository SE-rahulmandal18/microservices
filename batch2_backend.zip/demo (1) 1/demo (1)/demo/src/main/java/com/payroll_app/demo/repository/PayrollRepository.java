//package com.payroll_app.demo.repository;
//
//import com.payroll_app.demo.dto.PayrollTrendDTO;
//import com.payroll_app.demo.model.Payroll;
//import org.springframework.data.jpa.repository.JpaRepository;
//import java.util.List;
//
//import org.springframework.data.jpa.repository.Query;
//import org.springframework.data.repository.query.Param;
//
//import java.time.Year;
//
//public interface PayrollRepository extends JpaRepository<Payroll, Long> {
//    List<Payroll> findByEmployeeId(Long employeeId);
//
//    @Query("SELECT new com.payroll_app.demo.dto.PayrollTrendDTO(" +
//            "YEAR(p.processedAt), MONTH(p.processedAt), SUM(p.basicSalary + p.allowances + p.bonuses)) " +
//            "FROM Payroll p " +
//            "WHERE YEAR(p.processedAt) = :year " +
//            "GROUP BY YEAR(p.processedAt), MONTH(p.processedAt) " +
//            "ORDER BY YEAR(p.processedAt), MONTH(p.processedAt)")
//    List<PayrollTrendDTO> findMonthlyPayrollSummariesByYear(@Param("year") int year);
//
//
//
//}

package com.payroll_app.demo.repository;

import com.payroll_app.demo.dto.PayrollTrendDTO;
import com.payroll_app.demo.model.Payroll;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.Year;

public interface PayrollRepository extends JpaRepository<Payroll, Long> {
    List<Payroll> findByEmployeeId(Long employeeId);
    List<Payroll> findByEmployeeIdOrderByIdDesc(Long employeeId);

    @Query("SELECT new com.payroll_app.demo.dto.PayrollTrendDTO(" +
            "YEAR(p.processedAt), MONTH(p.processedAt), SUM(p.basicSalary + p.allowances + p.bonuses)) " +
            "FROM Payroll p " +
            "WHERE YEAR(p.processedAt) = :year " +
            "GROUP BY YEAR(p.processedAt), MONTH(p.processedAt) " +
            "ORDER BY YEAR(p.processedAt), MONTH(p.processedAt)")
    List<PayrollTrendDTO> findMonthlyPayrollSummariesByYear(@Param("year") int year);



}
