package com.payroll_app.demo.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Entity
@Table(name = "leave_records")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class LeaveRecord {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional = false)
    @JoinColumn(name = "employee_id")
    private Employee employee;

    @Column(nullable = false)
    private LocalDate startDate;

    @Column(nullable = false)
    private LocalDate endDate;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private LeaveType leaveType;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private LeaveDuration durationPerDay = LeaveDuration.FULL;

    @Column(nullable = false)
    private boolean isPaid = true;

    @Column(nullable = false)
    private double lopDays = 0.0;

    public enum LeaveType {
        CASUAL, SICK, UNPAID, ANNUAL
    }

    public enum LeaveDuration {
        FULL, HALF
    }
}
