package com.payroll_app.demo.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Getter
@Setter
public class PasswordResetToken {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String token;

    private String email;

    private LocalDateTime expirationTime;

    // Default constructor
    public PasswordResetToken() {}

    // Constructor
    public PasswordResetToken(String email, String token, LocalDateTime expirationTime) {
        this.email = email;
        this.token = token;
        this.expirationTime = expirationTime;
    }
}
