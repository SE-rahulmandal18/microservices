package com.payroll_app.demo.service;

import com.payroll_app.demo.dto.LeaveRecordRequest;
import com.payroll_app.demo.model.Employee;
import com.payroll_app.demo.model.LeaveRecord;
import com.payroll_app.demo.repository.EmployeeRepository;
import com.payroll_app.demo.repository.LeaveRecordRepository;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.List;

@Service
@RequiredArgsConstructor
public class LeaveRecordService {

    private final LeaveRecordRepository leaveRecordRepository;
    private final EmployeeRepository employeeRepository;
    private final LeaveBalanceService leaveBalanceService;

    private static final Logger logger = LoggerFactory.getLogger(LeaveRecordService.class);

    private double getDurationValue(String duration) {
        return switch (duration.toUpperCase()) {
            case "FULL" -> 1.0;
            case "HALF" -> 0.5;
            default -> throw new RuntimeException("Invalid duration: " + duration);
        };
    }

    private long calculateBusinessDays(LocalDate start, LocalDate end) {
        long count = 0;
        for (LocalDate date = start; !date.isAfter(end); date = date.plusDays(1)) {
            DayOfWeek dow = date.getDayOfWeek();
            if (dow != DayOfWeek.SATURDAY && dow != DayOfWeek.SUNDAY) {
                count++;
            }
        }
        return count;
    }

    public LeaveRecord createLeave(LeaveRecordRequest request) {
        Employee employee = employeeRepository.findById(request.getEmployeeId())
                .orElseThrow(() -> new RuntimeException("Employee not found"));

        if (leaveRecordRepository.existsOverlappingLeave(employee.getId(), request.getStartDate(), request.getEndDate())) {
            throw new RuntimeException("Leave overlaps with existing records");
        }

        double leaveDays = calculateBusinessDays(request.getStartDate(), request.getEndDate()) *
                getDurationValue(request.getDurationPerDay().name());

        double paidDays = leaveBalanceService.useLeaveBalance(employee, request.getLeaveType(), leaveDays);
        double lopDays = leaveDays - paidDays;

        LeaveRecord leave = new LeaveRecord();
        leave.setEmployee(employee);
        leave.setStartDate(request.getStartDate());
        leave.setEndDate(request.getEndDate());
        leave.setLeaveType(request.getLeaveType());
        leave.setDurationPerDay(request.getDurationPerDay());
        leave.setPaid(paidDays == leaveDays);
        leave.setLopDays(lopDays);

        LeaveRecord saved = leaveRecordRepository.save(leave);
        logger.info("Created leave record: {}", saved.getId());
        return saved;
    }

    public LeaveRecord updateLeave(Long id, LeaveRecordRequest request) {
        LeaveRecord leave = getLeaveById(id);

        double oldDuration = calculateBusinessDays(leave.getStartDate(), leave.getEndDate()) *
                getDurationValue(leave.getDurationPerDay().name());
        leaveBalanceService.recreditLeaveBalance(leave.getEmployee(), leave.getLeaveType(), oldDuration);

        if (request.getStartDate() != null && request.getEndDate() != null &&
                (!request.getStartDate().equals(leave.getStartDate()) || !request.getEndDate().equals(leave.getEndDate()))) {
            if (leaveRecordRepository.existsOverlappingLeave(leave.getEmployee().getId(), request.getStartDate(), request.getEndDate())) {
                throw new RuntimeException("Updated leave overlaps with existing records");
            }
            leave.setStartDate(request.getStartDate());
            leave.setEndDate(request.getEndDate());
        }

        if (request.getLeaveType() != null) {
            leave.setLeaveType(request.getLeaveType());
        }

        if (request.getDurationPerDay() != null) {
            leave.setDurationPerDay(request.getDurationPerDay());
        }

        double newDuration = calculateBusinessDays(leave.getStartDate(), leave.getEndDate()) *
                getDurationValue(leave.getDurationPerDay().name());
        double paidDays = leaveBalanceService.useLeaveBalance(leave.getEmployee(), leave.getLeaveType(), newDuration);
        double lopDays = newDuration - paidDays;

        leave.setLopDays(lopDays);
        leave.setPaid(paidDays == newDuration);

        if (request.getIsPaid() != null) {
            leave.setPaid(request.getIsPaid());
        }

        LeaveRecord updated = leaveRecordRepository.save(leave);
        logger.info("Updated leave record: {}", updated.getId());
        return updated;
    }

    public void deleteLeave(Long id) {
        LeaveRecord leave = getLeaveById(id);
        double totalDays = calculateBusinessDays(leave.getStartDate(), leave.getEndDate()) *
                getDurationValue(leave.getDurationPerDay().name());
        leaveBalanceService.recreditLeaveBalance(leave.getEmployee(), leave.getLeaveType(), totalDays);
        leaveRecordRepository.deleteById(id);
        logger.info("Deleted leave record: {}", id);
    }

    public LeaveRecord getLeaveById(Long id) {
        return leaveRecordRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Leave not found with ID: " + id));
    }

    public List<LeaveRecord> getAllLeaves() {
        return leaveRecordRepository.findAll();
    }

    public List<LeaveRecord> getLeavesByEmployeeId(Long employeeId) {
        return leaveRecordRepository.findByEmployeeId(employeeId);
    }
}
