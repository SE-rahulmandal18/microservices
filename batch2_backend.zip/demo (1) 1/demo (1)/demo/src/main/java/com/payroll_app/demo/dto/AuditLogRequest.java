package com.payroll_app.demo.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AuditLogRequest {
    private String action;
    private Long performedById;
    private String details;
}
