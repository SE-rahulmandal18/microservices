package com.payroll_app.demo.controller;



import com.payroll_app.demo.service.ChatService;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.*;



import java.util.List;

import java.util.Map;



@RestController

@RequestMapping("/api/chat")

public class ChatController {



    private final ChatService chatService;



    @Autowired

    public ChatController(ChatService chatService) {

        this.chatService = chatService;

    }



    @PostMapping

    public Map<String, String> chat(@RequestBody Map<String, String> payload) {

        String message = payload.get("message");

        if (message == null || message.trim().isEmpty()) {

            return Map.of("error", "Message cannot be empty");

        }

        return chatService.chat(message);

    }



    @GetMapping("/questions")

    public Map<String, List<String>> getCommonQuestions() {

        return Map.of("questions", chatService.getCommonQuestions());

    }

}