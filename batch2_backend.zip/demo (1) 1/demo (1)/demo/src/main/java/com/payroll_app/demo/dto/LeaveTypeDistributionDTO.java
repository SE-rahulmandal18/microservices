package com.payroll_app.demo.dto;

import com.payroll_app.demo.model.LeaveRecord;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;

@Getter
@Setter
@NoArgsConstructor
public class LeaveTypeDistributionDTO {
    private LeaveRecord.LeaveType leaveType;
    private Long count;

    public LeaveTypeDistributionDTO(LeaveRecord.LeaveType leaveType, Long count) {
        this.leaveType = leaveType;
        this.count = count;
    }

    // getters and setters
}

