//package com.payroll_app.demo.model;
//
//import jakarta.persistence.*;
//
//import java.time.LocalDate;
//
//@Entity
//public class Bonus {
//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    private Long id;
//
//    @ManyToOne
//    @JoinColumn(name = "employee_id", nullable = false)
//    private Employee employee;
//
//    @Column(nullable = false)
//    private int performanceRating;
//
//    @Column(nullable = false)
//    private double amount;
//
//    @Column(nullable = false)
//    private LocalDate period;
//
//    @Column(nullable = false)
//    private LocalDate creditedDate;
//
//    public void setEmployee(Employee employee) {
//    }
//
//    public void setPerformanceRating(int performanceRating) {
//    }
//
//    public void setAmount(double amount) {
//    }
//
//    public void setPeriod(LocalDate period) {
//    }
//
//    public void setCreditedDate(LocalDate now) {
//    }
//
//    // Getters and setters
//}


package com.payroll_app.demo.model;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
public class Bonus {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "employee_id", nullable = false)
    private Employee employee;

    @Column(nullable = false)
    private int performanceRating;

    @Column(nullable = false)
    private double amount;

    @Column(nullable = false)
    private LocalDate period;

    @Column(nullable = false)
    private LocalDate creditedDate;

    // Getters and setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Employee getEmployee() {
        return employee;
    }

    public void setEmployee(Employee employee) {
        this.employee = employee;
    }

    public int getPerformanceRating() {
        return performanceRating;
    }

    public void setPerformanceRating(int performanceRating) {
        this.performanceRating = performanceRating;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public LocalDate getPeriod() {
        return period;
    }

    public void setPeriod(LocalDate period) {
        this.period = period;
    }

    public LocalDate getCreditedDate() {
        return creditedDate;
    }

    public void setCreditedDate(LocalDate creditedDate) {
        this.creditedDate = creditedDate;
    }
}
