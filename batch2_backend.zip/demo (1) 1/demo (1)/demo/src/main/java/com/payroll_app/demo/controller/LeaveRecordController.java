package com.payroll_app.demo.controller;

import com.payroll_app.demo.dto.LeaveRecordRequest;
import com.payroll_app.demo.model.LeaveRecord;
import com.payroll_app.demo.service.LeaveRecordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/leaves")
public class LeaveRecordController {

    @Autowired
    private LeaveRecordService leaveRecordService;

    @PostMapping
    public ResponseEntity<LeaveRecord> createLeave(@RequestBody LeaveRecordRequest request) {
        LeaveRecord leave = leaveRecordService.createLeave(request);
        return ResponseEntity.ok(leave);
    }

    @GetMapping
    public ResponseEntity<List<LeaveRecord>> getAllLeaves() {
        List<LeaveRecord> leaves = leaveRecordService.getAllLeaves();
        return ResponseEntity.ok(leaves);
    }

    @GetMapping("/{id}")
    public ResponseEntity<LeaveRecord> getLeaveById(@PathVariable Long id) {
        LeaveRecord leave = leaveRecordService.getLeaveById(id);
        return ResponseEntity.ok(leave);
    }

    @PutMapping("/{id}")
    public ResponseEntity<LeaveRecord> updateLeave(@PathVariable Long id, @RequestBody LeaveRecordRequest request) {
        LeaveRecord updatedLeave = leaveRecordService.updateLeave(id, request);
        return ResponseEntity.ok(updatedLeave);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteLeave(@PathVariable Long id) {
        leaveRecordService.deleteLeave(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/employee/{employeeId}")
    public ResponseEntity<List<LeaveRecord>> getLeavesByEmployee(@PathVariable Long employeeId) {
        return ResponseEntity.ok(leaveRecordService.getLeavesByEmployeeId(employeeId));
    }

}
