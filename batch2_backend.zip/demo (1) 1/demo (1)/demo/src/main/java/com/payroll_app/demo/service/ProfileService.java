package com.payroll_app.demo.service;

import com.payroll_app.demo.dto.ProfileDTO;
import com.payroll_app.demo.model.Employee;
import com.payroll_app.demo.model.User;
import com.payroll_app.demo.repository.EmployeeRepository;
import com.payroll_app.demo.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class ProfileService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private EmployeeRepository employeeRepository;

    private static final Logger logger = LoggerFactory.getLogger(ProfileService.class);

    public ProfileDTO getProfile(String username) {
        logger.info("Fetching profile for username: {}", username);

        Optional<User> userOptional = userRepository.findByUsername(username);
        if (userOptional.isEmpty()) {
            logger.warn("User not found for username: {}", username);
            return null;
        }

        User user = userOptional.get();

        Optional<Employee> employeeOptional = employeeRepository.findByUserId(user.getId());
        if (employeeOptional.isEmpty()) {
            logger.warn("Employee not found for user ID: {}", user.getId());
            return null;
        }

        Employee employee = employeeOptional.get();

        ProfileDTO profileDTO = new ProfileDTO();
        profileDTO.setEmployeeId(employee.getId());
        profileDTO.setUsername(user.getUsername());
        profileDTO.setEmail(user.getEmail());
        profileDTO.setFirstName(employee.getFirstName());
        profileDTO.setLastName(employee.getLastName());
        profileDTO.setPhone(employee.getPhone());
        profileDTO.setDepartment(employee.getDepartment());
        profileDTO.setDesignation(employee.getDesignation());
        profileDTO.setJoinDate(employee.getJoinDate());
        profileDTO.setBankAccount(employee.getBankAccount());
        profileDTO.setEmploymentType(employee.getEmploymentType().name());
        profileDTO.setStatus(employee.getStatus().name());
        profileDTO.setCreatedAt(user.getCreatedAt());

        logger.info("Profile fetched successfully for username: {}", username);
        return profileDTO;
    }

    public boolean updateProfile(String username, ProfileDTO profileDTO) {
        logger.info("Updating profile for username: {}", username);

        Optional<User> userOptional = userRepository.findByUsername(username);
        if (userOptional.isEmpty()) {
            logger.warn("User not found: {}", username);
            return false;
        }

        User user = userOptional.get();

        Optional<Employee> employeeOptional = employeeRepository.findById(profileDTO.getEmployeeId());
        if (employeeOptional.isEmpty()) {
            logger.warn("Employee not found for ID: {}", profileDTO.getEmployeeId());
            return false;
        }

        Employee employee = employeeOptional.get();

        user.setEmail(profileDTO.getEmail());
        user.setUsername(profileDTO.getUsername());
        userRepository.save(user);
        logger.debug("User information updated for username: {}", username);

        employee.setFirstName(profileDTO.getFirstName());
        employee.setLastName(profileDTO.getLastName());
        employee.setPhone(profileDTO.getPhone());
        employee.setDepartment(profileDTO.getDepartment());
        employee.setDesignation(profileDTO.getDesignation());
        employee.setBankAccount(profileDTO.getBankAccount());
        employee.setStatus(Employee.EmployeeStatus.valueOf(profileDTO.getStatus()));
        employeeRepository.save(employee);
        logger.debug("Employee information updated for employeeId: {}", profileDTO.getEmployeeId());

        logger.info("Profile update successful for username: {}", username);
        return true;
    }

    public boolean changePassword(String username, String currentPassword, String newPassword) {
        logger.info("Changing password for username: {}", username);

        Optional<User> userOptional = userRepository.findByUsername(username);
        if (userOptional.isEmpty()) {
            logger.warn("User not found for password change: {}", username);
            return false;
        }

        User user = userOptional.get();
        BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

        if (!passwordEncoder.matches(currentPassword, user.getPasswordHash())) {
            logger.warn("Current password mismatch for user: {}", username);
            return false;
        }

        String hashedNewPassword = passwordEncoder.encode(newPassword);
        user.setPasswordHash(hashedNewPassword);
        userRepository.save(user);

        logger.info("Password changed successfully for username: {}", username);
        return true;
    }
}
