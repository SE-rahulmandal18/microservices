//package com.payroll_app.demo.repository;
//
//import com.payroll_app.demo.model.AuditLog;
//import com.payroll_app.demo.model.User;
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.stereotype.Repository;
//
//import java.util.List;
//
//@Repository
//public interface AuditLogRepository extends JpaRepository<AuditLog, Long> {
//    List<AuditLog> findByPerformedBy(User user);
//}
//

package com.payroll_app.demo.repository;

import com.payroll_app.demo.model.AuditLog;
import com.payroll_app.demo.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AuditLogRepository extends JpaRepository<AuditLog, Long> {
    List<AuditLog> findByPerformedBy(User user);
    List<AuditLog> findTop5ByOrderByPerformedAtDesc();
}


