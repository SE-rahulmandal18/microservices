//package com.payroll_app.demo.service;
//
//import com.payroll_app.demo.model.Bonus;
//import com.payroll_app.demo.model.Employee;
//import com.payroll_app.demo.repository.BonusRepository;
//import com.payroll_app.demo.repository.EmployeeRepository;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import java.time.LocalDate;
//import java.util.List;
//
//@Service
//public class BonusService {
//    @Autowired
//    private BonusRepository bonusRepository;
//
//    @Autowired
//    private EmployeeRepository employeeRepository;
//
//    public Bonus creditBonus(Long employeeId, int performanceRating, LocalDate period) {
//        Employee employee = employeeRepository.findById(employeeId)
//                .orElseThrow(() -> new RuntimeException("Employee not found"));
//
//        if (performanceRating < 1 || performanceRating > 10) {
//            throw new IllegalArgumentException("Performance rating must be between 1-10");
//        }
//
//        double amount = calculateBonusAmount(performanceRating);
//
//        Bonus bonus = new Bonus();
//        bonus.setEmployee(employee);
//        bonus.setPerformanceRating(performanceRating);
//        bonus.setAmount(amount);
//        bonus.setPeriod(period);
//        bonus.setCreditedDate(LocalDate.now());
//
//        return bonusRepository.save(bonus);
//    }
//
//    public List<Bonus> getAllBonuses() {
//        return bonusRepository.findAll();
//    }
//
//    public List<Bonus> getBonusesByEmployee(Long employeeId) {
//        return bonusRepository.findByEmployeeId(employeeId);
//    }
//
//    public List<Bonus> getBonusesByPeriod(LocalDate period) {
//        return bonusRepository.findByPeriod(period);
//    }
//
//    private double calculateBonusAmount(int rating) {
//        if (rating >= 8 && rating <= 10) {
//            return 10000;
//        } else if (rating >= 5 && rating <= 7) {
//            return 5000;
//        }
//        return 0;
//    }
//}

package com.payroll_app.demo.service;

import com.payroll_app.demo.model.Bonus;
import com.payroll_app.demo.model.Employee;
import com.payroll_app.demo.repository.BonusRepository;
import com.payroll_app.demo.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class BonusService {
    @Autowired
    private BonusRepository bonusRepository;

    @Autowired
    private EmployeeRepository employeeRepository;

    public Bonus creditBonus(Long employeeId, int performanceRating, LocalDate period) {
        Employee employee = employeeRepository.findById(employeeId)
                .orElseThrow(() -> new RuntimeException("Employee not found"));

        if (performanceRating < 1 || performanceRating > 10) {
            throw new IllegalArgumentException("Performance rating must be between 1-10");
        }

        double amount = calculateBonusAmount(performanceRating);

        Bonus bonus = new Bonus();
        bonus.setEmployee(employee);
        bonus.setPerformanceRating(performanceRating);
        bonus.setAmount(amount);
        bonus.setPeriod(period.withDayOfMonth(1)); // Set to first of the month for consistency
        bonus.setCreditedDate(LocalDate.now());

        return bonusRepository.save(bonus);
    }

    public List<Bonus> getAllBonuses() {
        return bonusRepository.findAll();
    }

    public List<Bonus> getBonusesByEmployee(Long employeeId) {
        return bonusRepository.findByEmployeeId(employeeId);
    }

    public List<Bonus> getBonusesByPeriod(LocalDate period) {
        return bonusRepository.findByPeriod(period.withDayOfMonth(1));
    }

    private double calculateBonusAmount(int rating) {
        if (rating >= 8 && rating <= 10) {
            return 10000;
        } else if (rating >= 5 && rating <= 7) {
            return 5000;
        }
        return 0;
    }
}