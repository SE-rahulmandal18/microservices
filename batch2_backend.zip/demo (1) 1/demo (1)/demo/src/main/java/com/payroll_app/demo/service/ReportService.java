package com.payroll_app.demo.service;

import com.payroll_app.demo.dto.LeaveTypeDistributionDTO;
import com.payroll_app.demo.dto.OvertimeTrendDTO;
import com.payroll_app.demo.dto.PayrollTrendDTO;
import com.payroll_app.demo.repository.LeaveRecordRepository;
import com.payroll_app.demo.repository.AttendanceRepository;
import com.payroll_app.demo.repository.PayrollRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service

public class ReportService {

    @Autowired
    private LeaveRecordRepository leaveRecordRepository;

    @Autowired
    private AttendanceRepository attendanceRepository;

    @Autowired
    private PayrollRepository payrollRepository;

    private static final Logger logger = LoggerFactory.getLogger(ReportService.class);

    public List<LeaveTypeDistributionDTO> getLeaveDistribution() {
        logger.info("Generating Leave Type Distribution report");
        List<LeaveTypeDistributionDTO> result = leaveRecordRepository.findLeaveTypeCounts();
        logger.debug("Leave distribution report size: {}", result.size());
        return result;
    }

    public List<OvertimeTrendDTO> getOvertimeTrends() {
        logger.info("Generating Overtime Trend report");
        List<OvertimeTrendDTO> result = attendanceRepository.findMonthlyOvertimeSummaries();
        logger.debug("Overtime trend report size: {}", result.size());
        return result;
    }

    public List<PayrollTrendDTO> getPayrollTrends(int year) {
        logger.info("Generating Payroll Trend report for year: {}", year);
        List<PayrollTrendDTO> result = payrollRepository.findMonthlyPayrollSummariesByYear(year);
        logger.debug("Payroll trend report size for year {}: {}", year, result.size());
        return result;
    }
}


