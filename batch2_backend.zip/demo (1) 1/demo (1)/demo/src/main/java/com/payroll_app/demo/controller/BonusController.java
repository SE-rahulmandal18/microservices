//package com.payroll_app.demo.controller;
//
//import com.payroll_app.demo.model.Bonus;
//import com.payroll_app.demo.service.BonusService;
//import jakarta.validation.constraints.Max;
//import jakarta.validation.constraints.Min;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.format.annotation.DateTimeFormat;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.*;
//
//import java.time.LocalDate;
//import java.util.List;
//
//@RestController
//@RequestMapping("/api/bonuses")
//public class BonusController {
//    @Autowired
//    private BonusService bonusService;
//
//    @PostMapping
//    public ResponseEntity<Bonus> creditBonus(
//            @RequestParam Long employeeId,
//            @RequestParam @Min(1) @Max(10) int performanceRating,
//            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate period) {
//        Bonus bonus = bonusService.creditBonus(employeeId, performanceRating, period);
//        return ResponseEntity.ok(bonus);
//    }
//
//    @GetMapping
//    public ResponseEntity<List<Bonus>> getAllBonuses() {
//        return ResponseEntity.ok(bonusService.getAllBonuses());
//    }
//
//    @GetMapping("/employee/{employeeId}")
//    public ResponseEntity<List<Bonus>> getBonusesByEmployee(@PathVariable Long employeeId) {
//        return ResponseEntity.ok(bonusService.getBonusesByEmployee(employeeId));
//    }
//
//    @GetMapping("/period")
//    public ResponseEntity<List<Bonus>> getBonusesByPeriod(
//            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate period) {
//        return ResponseEntity.ok(bonusService.getBonusesByPeriod(period));
//    }
//}
//----------------
//package com.payroll_app.demo.controller;
//
//import com.payroll_app.demo.model.Bonus;
//import com.payroll_app.demo.service.BonusService;
//import jakarta.validation.constraints.Max;
//import jakarta.validation.constraints.Min;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.format.annotation.DateTimeFormat;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.*;
//
//import java.time.LocalDate;
//import java.util.List;
//
//@RestController
//@RequestMapping("/api/bonuses")
//public class BonusController {
//    @Autowired
//    private BonusService bonusService;
//
//    @PostMapping
//    public ResponseEntity<Bonus> creditBonus(
//            @RequestParam Long employeeId,
//            @RequestParam @Min(1) @Max(10) int performanceRating,
//            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate period) {
//        Bonus bonus = bonusService.creditBonus(employeeId, performanceRating, period);
//        return ResponseEntity.ok(bonus);
//    }
//
//    @GetMapping
//    public ResponseEntity<List<Bonus>> getAllBonuses() {
//        return ResponseEntity.ok(bonusService.getAllBonuses());
//    }
//
//    @GetMapping("/employee/{employeeId}")
//    public ResponseEntity<List<Bonus>> getBonusesByEmployee(@PathVariable Long employeeId) {
//        return ResponseEntity.ok(bonusService.getBonusesByEmployee(employeeId));
//    }
//
//    @GetMapping("/period")
//    public ResponseEntity<List<Bonus>> getBonusesByPeriod(
//            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate period) {
//        return ResponseEntity.ok(bonusService.getBonusesByPeriod(period));
//    }
//}

package com.payroll_app.demo.controller;

import com.payroll_app.demo.model.Bonus;
import com.payroll_app.demo.service.BonusService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/bonuses")
public class BonusController {
    @Autowired
    private BonusService bonusService;

    @PostMapping
    public ResponseEntity<Bonus> creditBonus(
            @RequestBody @Valid BonusRequest request) {
        Bonus bonus = bonusService.creditBonus(request.getEmployeeId(),
                request.getPerformanceRating(),
                request.getPeriod());
        return ResponseEntity.ok(bonus);
    }

    @GetMapping
    public ResponseEntity<List<Bonus>> getAllBonuses() {
        return ResponseEntity.ok(bonusService.getAllBonuses());
    }

    @GetMapping("/employee/{employeeId}")
    public ResponseEntity<List<Bonus>> getBonusesByEmployee(@PathVariable Long employeeId) {
        return ResponseEntity.ok(bonusService.getBonusesByEmployee(employeeId));
    }

    @GetMapping("/period")
    public ResponseEntity<List<Bonus>> getBonusesByPeriod(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate period) {
        return ResponseEntity.ok(bonusService.getBonusesByPeriod(period));
    }

    // Add this inner class for request body
    public static class BonusRequest {
        private Long employeeId;

        @Min(1) @Max(10)
        private int performanceRating;

        @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
        private LocalDate period;

        // Getters and setters
        public Long getEmployeeId() {
            return employeeId;
        }

        public void setEmployeeId(Long employeeId) {
            this.employeeId = employeeId;
        }

        public int getPerformanceRating() {
            return performanceRating;
        }

        public void setPerformanceRating(int performanceRating) {
            this.performanceRating = performanceRating;
        }

        public LocalDate getPeriod() {
            return period;
        }

        public void setPeriod(LocalDate period) {
            this.period = period;
        }
    }
}