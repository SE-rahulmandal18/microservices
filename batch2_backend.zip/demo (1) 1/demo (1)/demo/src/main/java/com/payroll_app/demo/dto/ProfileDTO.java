package com.payroll_app.demo.dto;

import lombok.Data;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
public class ProfileDTO {
    private Long employeeId;  // Changed from userId to employeeId
    private String username;
    private String email;
    private String firstName;
    private String lastName;
    private String phone;
    private String department;
    private String designation;
    private LocalDate joinDate;
    private String bankAccount;
    private String employmentType;
    private String status;
    private LocalDateTime createdAt;
}
