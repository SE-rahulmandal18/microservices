//package com.payroll_app.demo.repository;
//
//import com.payroll_app.demo.model.Employee;
//import com.payroll_app.demo.model.User;
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.stereotype.Repository;
//
//import java.util.Optional;
//
//@Repository
//public interface EmployeeRepository extends JpaRepository<Employee, Long> {
//    Optional<Employee> findByEmail(String email);
//    Optional<Employee> findByUser(User user);
//    Optional<Employee> findByUserId(Long userId);
//}

package com.payroll_app.demo.repository;

import com.payroll_app.demo.model.Employee;
import com.payroll_app.demo.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long> {
    Optional<Employee> findByEmail(String email);
    Optional<Employee> findByUser(User user);
    Optional<Employee> findByUserId(Long userId);
    List<Employee> findByDepartment(String department);
    List<Employee> findByStatus(Employee.EmployeeStatus status);


}