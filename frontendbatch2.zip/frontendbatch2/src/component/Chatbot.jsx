


import React, { useState, useEffect, useRef } from "react";
import { SendHorizonal, MessageCircle, Mic, MicOff } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const Chatbot = () => {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const [showExplore, setShowExplore] = useState(false);
  const [commonQuestions, setCommonQuestions] = useState([]);
  const [isListening, setIsListening] = useState(false);
  const [userRole, setUserRole] = useState(null);
  const [username, setUsername] = useState("User");
  const messagesEndRef = useRef(null);
  const menuRef = useRef(null);
  const exploreRef = useRef(null);

  // Animation variants
  const chatVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1 },
    exit: { y: 20, opacity: 0 }
  };

  // Auto-scroll to bottom of chat
  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Initialize chat with welcome message when opened
  useEffect(() => {
    if (open && messages.length === 0) {
      fetchUserDetails();
    }
  }, [open]);

  const fetchUserDetails = async () => {
    try {
      // Get username from localStorage or API
      const token = localStorage.getItem("token");
      if (token) {
        // Decode token to get username (simplified example)
        const payload = JSON.parse(atob(token.split('.')[1]));
        setUsername(payload.sub || "User");
        setUserRole(payload.role || "EMPLOYEE");
        
        // Set initial messages
        const initialMessages = [
          {
            text: `👋 Welcome, <b>${payload.sub}</b>!<br>I'm your Payroll Assistant.`,
            sender: "bot"
          },
          ...getRoleNavigationMessage(payload.role || "EMPLOYEE"),
          {
            text: `❓ Use the <b>FAQs</b> button for common questions or <b>EXPLORE</b> for navigation links.<br><br>💡 Quick tip: Type <b>help</b> for role-specific data queries.`,
            sender: "bot"
          }
        ];
        setMessages(initialMessages);
      }
    } catch (err) {
      console.error("Error fetching user details", err);
      setMessages([
        {
          text: "👋 Welcome! I'm your Payroll Assistant.",
          sender: "bot"
        },
        ...getRoleNavigationMessage("EMPLOYEE"),
        {
          text: `❓ Use the <b>FAQs</b> button for common questions or <b>EXPLORE</b> for navigation links.<br><br>💡 Quick tip: Type <b>help</b> for role-specific data queries.`,
          sender: "bot"
        }
      ]);
    }
  };

  const getRoleNavigationMessage = (role) => {
    let roleNav = [];
    let roleName = '';
    
    switch(role.toUpperCase()) {
      case 'HR':
        roleNav = navigation['HR'];
        roleName = 'HR';
        break;
      case 'ADMIN':
        roleNav = navigation['Admin'];
        roleName = 'Admin';
        break;
      default:
        roleNav = navigation['Employee'];
        roleName = 'Employee';
    }
    
    const roleNavLinks = roleNav.map(item => 
      `<a href="${item.path}" class="text-blue-600 underline" target="_blank">${item.name}</a>`
    ).join('<br>• ');
    
    const generalNavLinks = navigation['General'].map(item => 
      `<a href="${item.path}" class="text-blue-600 underline" target="_blank">${item.name}</a>`
    ).join('<br>• ');
    
    return [{
      text: `👋 Welcome ${roleName}! Here are your navigation options:<br><br>
            <b>${roleName} Links:</b><br>• ${roleNavLinks}<br><br>
            <b>General Links:</b><br>• ${generalNavLinks}`,
      sender: "bot" 
    }];
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  // FAQ data with variations
  const faq = {
    "when will i receive my salary": {
      answer: "💰 Salaries are processed on the first working day of each month.",
      variations: [
        "salary payment date",
        "when is payday",
        "when do we get paid"
      ]
    },
    "how can i view my payslip": {
      answer: "📄 You can view your payslip in the <a href='/payslips' class='text-blue-600 underline'>Payslips</a> section of your dashboard.",
      variations: [
        "where to check my salary slip",
        "how to see my payslip",
        "payslip access"
      ]
    },
    "what should i do if there's an error in my payslip": {
      answer: "⚠️ Please contact the HR department or raise a ticket through the <a href='/support' class='text-blue-600 underline'>support section</a>.",
      variations: [
        "payslip mistake what to do",
        "error in salary slip",
        "incorrect payslip"
      ]
    },
    "how are tax deductions calculated": {
      answer: "🧮 Tax deductions are based on your total salary, applicable exemptions, and current income tax laws. You can find details in your <a href='/payslips' class='text-blue-600 underline'>payslip</a>.",
      variations: [
        "how is tax calculated on salary",
        "salary tax calculation",
        "how does tax deduction work"
      ]
    },
    "can i download my payslips": {
      answer: "⬇️ Yes, you can download your payslips in PDF format from the <a href='/payslips' class='text-blue-600 underline'>Payslips section</a>.",
      variations: [
        "how to save payslip",
        "payslip download option",
        "get payslip copy"
      ]
    },
    "when are payroll corrections updated": {
      answer: "🔄 Corrections are usually reflected in the next payroll cycle. Check the <a href='/payroll' class='text-blue-600 underline'>Payroll section</a> for updates.",
      variations: [
        "salary correction timing",
        "when will payroll fixes show",
        "how long for payroll adjustments"
      ]
    },
    "what is the difference between gross pay and net pay": {
      answer: "💵 Gross pay is your total salary before deductions; net pay is what you take home after deductions. See details in your <a href='/payslips' class='text-blue-600 underline'>payslip</a>.",
      variations: [
        "gross vs net salary",
        "salary before and after tax",
        "difference in take home and total salary"
      ]
    },
    "where can i update my bank account details": {
      answer: "🏦 You can update your bank account details in the <a href='/profile' class='text-blue-600 underline'>Profile section</a>.",
      variations: [
        "how to change bank information",
        "bank details update location",
        "where to modify account number"
      ]
    },
    "are bonuses included in the payroll": {
      answer: "🎉 Yes, if applicable, bonuses are included in the payroll and shown in your <a href='/payslips' class='text-blue-600 underline'>payslip</a>.",
      variations: [
        "do bonuses come with salary",
        "is bonus part of payslip",
        "how are bonuses paid"
      ]
    },
    "how do i know if my leave impacts my salary": {
      answer: "🏖️ Check your leave balance and approval status in the <a href='/leave-management' class='text-blue-600 underline'>Leave Management</a> section. Unpaid leaves may reduce your net salary.",
      variations: [
        "does leave affect pay",
        "how leave impacts salary",
        "unpaid leave and salary deduction"
      ]
    },
    "what is seamless payroll processing": {
      answer: "⚡ Automate salary calculations, tax deductions, and payouts with ease. Ensure accurate and timely payroll processing every month in the <a href='/payroll' class='text-blue-600 underline'>Payroll section</a>.",
      variations: [
        "explain payroll processing",
        "how does payroll system work",
        "what is automated payroll"
      ]
    },
    "how is employee management handled": {
      answer: "👥 Keep track of employee records, attendance, and salary structures in one unified platform in the <a href='/employee-management' class='text-blue-600 underline'>Employee Management</a> section.",
      variations: [
        "employee record system",
        "how are staff details managed",
        "what is employee management system"
      ]
    },
    "what about tax compliance & reports": {
      answer: "📊 Stay compliant with automated tax calculations and generate reports for audits, filings, and financial insights in the <a href='/reports' class='text-blue-600 underline'>Reports section</a>.",
      variations: [
        "how are tax reports handled",
        "tax compliance system",
        "payroll tax reporting"
      ]
    },
    "is the system secure": {
      answer: "🔒 Yes, we use advanced encryption and role-based access control to ensure your payroll data is secure and reliable. Manage security in your <a href='/profile' class='text-blue-600 underline'>Profile settings</a>.",
      variations: [
        "how secure is payroll data",
        "is my salary information safe",
        "data protection in payroll"
      ]
    },
    "can i manage everything from one dashboard": {
      answer: "📱 Yes, you can maintain records, track attendance, and oversee benefits all from the <a href='/dashboard' class='text-blue-600 underline'>Dashboard</a>.",
      variations: [
        "single dashboard for all features",
        "unified payroll interface",
        "all in one payroll system"
      ]
    }
  };

  // Navigation data with variations
  const navigation = {
    "General": [
      { 
        name: "Register", 
        path: "/register",
        variations: ["sign up", "create account", "registration"]
      },
      { 
        name: "Login", 
        path: "/login",
        variations: ["sign in", "log in", "access account"]
      },
      { 
        name: "Forgot Password", 
        path: "/forget-password",
        variations: ["reset password", "password recovery", "change password"]
      },
      { 
        name: "Dashboard", 
        path: "/dashboard",
        variations: ["main screen", "home page", "control panel"]
      },
      { 
        name: "About", 
        path: "/about",
        variations: ["information", "company details", "about us"]
      }
    ],
    "Admin": [
      { 
        name: "Manage Users", 
        path: "/manage-users",
        variations: ["user administration", "handle accounts", "user control"]
      },
      { 
        name: "Reports", 
        path: "/reports",
        variations: ["analytics", "statistics", "data reports"]
      },
      { 
        name: "Transaction Status", 
        path: "/transaction-status",
        variations: ["payment status", "transaction tracking", "payment history"]
      },
      { 
        name: "Audit Logs", 
        path: "/audit-logs",
        variations: ["activity logs", "system records", "access history"]
      }
    ],
    "HR": [
      { 
        name: "Employee Management", 
        path: "/employee-management",
        variations: ["staff management", "employee records", "personnel system"]
      },
      { 
        name: "Payroll", 
        path: "/payroll",
        variations: ["salary processing", "payment system", "wages management"]
      }
    ],
    "Employee": [
      { 
        name: "Payslips", 
        path: "/payslips",
        variations: ["salary slips", "payment records", "pay statements"]
      },
      { 
        name: "Profile", 
        path: "/profile",
        variations: ["my account", "personal details", "user profile"]
      },
      { 
        name: "Leave Management", 
        path: "/leave-management",
        variations: ["vacation system", "time off", "absence tracking"]
      }
    ]
  };

  // Enhanced fuzzy matching for FAQ questions with variations
  const findMatchingQuestion = (query) => {
    const lowerQuery = query.toLowerCase().trim();
    
    // First check exact matches
    for (const question in faq) {
      if (lowerQuery === question.toLowerCase()) {
        return question;
      }
    }
    
    // Then check variations
    for (const question in faq) {
      const variations = faq[question].variations;
      for (const variation of variations) {
        if (lowerQuery.includes(variation) || variation.includes(lowerQuery)) {
          return question;
        }
      }
      
      // Also check the main question if not already matched
      if (lowerQuery.includes(question) || question.includes(lowerQuery)) {
        return question;
      }
    }
    
    return null;
  };

  // Enhanced fuzzy matching for navigation terms with variations
  const findMatchingNavigation = (query) => {
    const lowerQuery = query.toLowerCase().trim();
    
    // Check for role selection first
    if (lowerQuery === 'employee' || lowerQuery === 'staff') {
      return { role: 'employee' };
    }
    if (lowerQuery === 'hr' || lowerQuery === 'human resources') {
      return { role: 'hr' };
    }
    if (lowerQuery === 'admin' || lowerQuery === 'administrator') {
      return { role: 'admin' };
    }
    
    // Then check navigation items
    for (const category in navigation) {
      for (const item of navigation[category]) {
        // Check main name
        if (lowerQuery === item.name.toLowerCase()) {
          return item;
        }
        
        // Check variations
        for (const variation of item.variations) {
          if (lowerQuery === variation) {
            return item;
          }
        }
      }
    }
    
    return null;
  };

  // Fetch common questions when component mounts
  useEffect(() => {
    if (open) {
      fetchCommonQuestions();
    }
  }, [open]);

  const fetchCommonQuestions = async () => {
    try {
      const res = await fetch("http://localhost:8080/api/chat/questions", {
        headers: {
          "Authorization": `Bearer ${localStorage.getItem("token")}`
        }
      });
      const data = await res.json();
      setCommonQuestions(data.questions || []);
    } catch (err) {
      console.error("Failed to fetch common questions", err);
    }
  };

  const handleSend = async () => {
    if (!input.trim() || loading) return;

    // Handle greetings
    if (/^(hi|hello|hey|greetings)/i.test(input.trim())) {
      setMessages(prev => [
        ...prev,
        { text: input, sender: "user" },
        { 
          text: `👋 Hi <b>${username}</b>! I'm your Payroll Assistant. I can help you with:<br><br>
                • Employee data queries<br>
                • Payroll information<br>
                • Attendance records<br>
                • Leave management<br><br>
                Type <b>help</b> to see what I can do or use the buttons above.`,
          sender: "bot" 
        }
      ]);
      setInput("");
      return;
    }

    const userMessage = { text: input, sender: "user" };
    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setLoading(true);

    // First check if it's a role selection
    const matchedRole = findMatchingNavigation(input.toLowerCase());
    if (matchedRole && matchedRole.role) {
      const role = matchedRole.role;
      setUserRole(role);
      
      let roleNav = [];
      let roleName = '';
      
      if (role === 'employee') {
        roleNav = navigation['Employee'];
        roleName = 'Employee';
      } else if (role === 'hr') {
        roleNav = navigation['HR'];
        roleName = 'HR';
      } else if (role === 'admin') {
        roleNav = navigation['Admin'];
        roleName = 'Admin';
      }
      
      const roleNavLinks = roleNav.map(item => 
        `<a href="${item.path}" class="text-blue-600 underline" target="_blank">${item.name}</a>`
      ).join('<br>• ');
      
      const generalNavLinks = navigation['General'].map(item => 
        `<a href="${item.path}" class="text-blue-600 underline" target="_blank">${item.name}</a>`
      ).join('<br>• ');
      
      setMessages((prev) => [
        ...prev,
        { 
          text: `👋 Welcome ${roleName}! Here are your navigation options:<br><br>
                <b>${roleName} Links:</b><br>• ${roleNavLinks}<br><br>
                <b>General Links:</b><br>• ${generalNavLinks}`,
          sender: "bot" 
        }
      ]);
      setLoading(false);
      return;
    }

    // Then check if it matches any FAQ
    const matchedQuestion = findMatchingQuestion(input.toLowerCase());
    if (matchedQuestion) {
      setMessages((prev) => [
        ...prev,
        { text: faq[matchedQuestion].answer, sender: "bot" }
      ]);
      setLoading(false);
      return;
    }

    // Then check if it matches any navigation
    const matchedNav = findMatchingNavigation(input.toLowerCase());
    if (matchedNav && !matchedNav.role) {
      setMessages((prev) => [
        ...prev,
        { 
          text: `🔗 You can access <b>${matchedNav.name}</b> at: <a href="${matchedNav.path}" class="text-blue-600 underline" target="_blank">${matchedNav.path}</a>`,
          sender: "bot" 
        }
      ]);
      setLoading(false);
      return;
    }

    // Fall back to backend API for other questions
    try {
      const res = await fetch("http://localhost:8080/api/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${localStorage.getItem("token")}`
        },
        body: JSON.stringify({ message: input }),
      });

      if (!res.ok) {
        throw new Error(`HTTP error! status: ${res.status}`);
      }

      const data = await res.json();
      
      if (data.error) {
        setMessages((prev) => [
          ...prev,
          { text: data.error, sender: "bot" },
        ]);
      } else {
        const botMessage = { 
          text: data.response.replace(/\n/g, '<br>'), 
          sender: "bot" 
        };
        setMessages((prev) => [...prev, botMessage]);
      }
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        { text: "Sorry, I couldn't process your request. Please try again.", sender: "bot" },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const handleQuestionClick = (question) => {
    setMessages((prev) => [
      ...prev,
      { text: question, sender: "user" },
      { text: faq[question].answer, sender: "bot" }
    ]);
    setShowMenu(false);
    scrollToBottom();
  };

  const handleHelpClick = () => {
    setMessages((prev) => [
      ...prev,
      { text: "help", sender: "user" },
      { 
        text: "Here are some common questions you can ask:<br><br>" +
              commonQuestions.map(q => `• ${q}`).join('<br>') + 
              "<br><br>Or type your own question about employees, payroll, attendance, or leaves.",
        sender: "bot" 
      }
    ]);
    setShowMenu(false);
    scrollToBottom();
  };

  const handleMenuClick = () => {
    setShowMenu(!showMenu);
    setShowExplore(false);
  };

  const handleExploreClick = () => {
    setShowExplore(!showExplore);
    setShowMenu(false);
  };

  const toggleVoiceInput = () => {
    if ('webkitSpeechRecognition' in window) {
      setIsListening(!isListening);
      
      if (!isListening) {
        const recognition = new window.webkitSpeechRecognition();
        recognition.continuous = false;
        recognition.interimResults = false;
        
        recognition.onstart = () => {
          console.log("Voice recognition started");
        };
        
        recognition.onresult = (event) => {
          const transcript = event.results[0][0].transcript;
          setInput(transcript);
          recognition.stop();
          setIsListening(false);
        };
        
        recognition.onerror = (event) => {
          console.error("Voice recognition error", event.error);
          setIsListening(false);
        };
        
        recognition.onend = () => {
          setIsListening(false);
        };
        
        recognition.start();
      }
    } else {
      setMessages((prev) => [
        ...prev,
        { text: "Voice recognition is not supported in your browser.", sender: "bot" },
      ]);
    }
  };

  return (
    <div className="fixed bottom-4 right-4 z-50">
      {open ? (
        <motion.div 
          className="bg-white shadow-xl rounded-2xl w-96 h-[600px] flex flex-col"
          initial="hidden"
          animate="visible"
          exit="exit"
          variants={chatVariants}
          transition={{ duration: 0.2 }}
        >
          <div className="p-3 border-b font-semibold flex justify-between items-center text-sm">
            <span>Payroll Assistant</span>
            <div className="flex items-center gap-2">
              <button 
                onClick={handleMenuClick} 
                className="text-gray-500 hover:text-gray-700 text-xs font-medium"
                title="FAQs"
              >
                FAQs
              </button>
              <button 
                onClick={handleExploreClick} 
                className="text-gray-500 hover:text-gray-700 text-xs font-medium"
                title="Explore"
              >
                EXPLORE
              </button>
              <button 
                onClick={() => setOpen(false)} 
                className="text-gray-500 hover:text-gray-700"
                aria-label="Close chat"
              >
                ✖
              </button>
            </div>
          </div>

          <AnimatePresence>
            {showMenu && (
              <motion.div 
                ref={menuRef}
                className="bg-gray-50 border-t border-b max-h-72 overflow-y-auto text-xs p-2 space-y-1"
                style={{ flex: '0 0 auto' }}
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.2 }}
              >
                <button
                  onClick={handleHelpClick}
                  className="block w-full text-left hover:bg-blue-50 p-1 rounded font-medium"
                >
                  💡 Help - See what I can answer
                </button>
                {Object.keys(faq).map((question, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleQuestionClick(question)}
                    className="block w-full text-left hover:bg-blue-50 p-1 rounded"
                  >
                    {question}
                  </button>
                ))}
              </motion.div>
            )}
          </AnimatePresence>

          <AnimatePresence>
            {showExplore && (
              <motion.div 
                ref={exploreRef}
                className="bg-gray-50 border-t border-b max-h-72 overflow-y-auto text-xs p-2"
                style={{ flex: '0 0 auto' }}
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.2 }}
              >
                {Object.entries(navigation).map(([category, items]) => (
                  <div key={category} className="mb-2">
                    <div className="font-medium text-gray-700 mb-1">{category}</div>
                    {items.map((item, idx) => (
                      <a
                        key={idx}
                        href={item.path}
                        className="block w-full text-left hover:bg-blue-50 p-1 rounded text-blue-600"
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        {item.name}
                      </a>
                    ))}
                  </div>
                ))}
              </motion.div>
            )}
          </AnimatePresence>

          <div className="flex-1 overflow-y-auto p-3 space-y-2 text-sm flex flex-col">
            <AnimatePresence>
              {messages.map((msg, idx) => (
                <motion.div
                  key={idx}
                  className={`p-2 rounded-md ${
                    msg.sender === "bot"
                      ? "bg-gray-100 text-black self-start"
                      : "bg-blue-600 text-white self-end"
                  } max-w-[75%]`}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.2 }}
                  dangerouslySetInnerHTML={{ __html: msg.text }}
                />
              ))}
            </AnimatePresence>
            {loading && (
              <motion.div 
                className="p-2 rounded-md bg-gray-100 text-black self-start max-w-[75%]"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
              >
                Thinking...
              </motion.div>
            )}
            <div ref={messagesEndRef} />
          </div>
          <div className="p-2 border-t flex items-center gap-2">
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSend()}
              placeholder="Type your question..."
              className="flex-1 px-3 py-1 border rounded text-sm"
              disabled={loading}
              aria-label="Type your message"
            />
            <button 
              onClick={toggleVoiceInput} 
              className={`p-1 rounded-full ${isListening ? 'bg-red-100 text-red-600' : 'text-gray-600'}`}
              aria-label={isListening ? "Stop listening" : "Start voice input"}
            >
              {isListening ? <MicOff size={18} /> : <Mic size={18} />}
            </button>
            <button 
              onClick={handleSend} 
              className="text-blue-600 disabled:text-gray-400"
              disabled={loading}
              aria-label="Send message"
            >
              <SendHorizonal size={20} />
            </button>
          </div>
        </motion.div>
      ) : (
        <motion.button
          onClick={() => setOpen(true)}
          className="
bg-gradient-to-br from-[#1f3b57] via-[#476b8c] to-[#1c2e44] p-3 rounded-full text-white shadow-lg hover:bg-blue-700 transition-colors"
          aria-label="Open chat"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          <MessageCircle />
        </motion.button>
      )}
    </div>
  );
};

export default Chatbot;


