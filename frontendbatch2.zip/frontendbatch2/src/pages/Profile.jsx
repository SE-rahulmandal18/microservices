import React, { useState, useEffect } from "react";
import axios from "axios";
import Footer from "../component/Footer";
import HeaderNavbar from "../component/HeaderNavbar";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const Profile = () => {
  const [profile, setProfile] = useState({
    employeeId: "",
    username: "",
    email: "",
    firstName: "",
    lastName: "",
    phone: "",
    department: "",
    designation: "",
    joinDate: "",
    bankAccount: "",
    employmentType: "",
    status: "",
    createdAt: "",
  });

  const [editMode, setEditMode] = useState(false);
  const [validationErrors, setValidationErrors] = useState({});
  const token = localStorage.getItem("token");

  useEffect(() => {
    fetchProfile();
  }, []);

  const fetchProfile = async () => {
    try {
      const res = await axios.get("http://localhost:8080/api/users/me", {
        headers: { Authorization: `Bearer ${token}` },
      });
      setProfile(res.data);
    } catch (err) {
      toast.error("Failed to load profile.", {
        position: "top-center",
        autoClose: 3000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        theme: "colored",
      });
    }
  };

  const handleChange = (e) => {
    setProfile({ ...profile, [e.target.name]: e.target.value });
    setValidationErrors({ ...validationErrors, [e.target.name]: "" });
  };

  const validateProfile = () => {
    const errors = {};
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const phoneRegex = /^[0-9]{10}$/;
    const nameRegex = /^[A-Za-z]+$/;
    const noQuotesRegex = /^[^'"]*$/;

    if (!profile.firstName.trim()) {
      errors.firstName = "First name is required.";
    } else if (!nameRegex.test(profile.firstName)) {
      errors.firstName = "First name must contain only letters.";
    } else if (!noQuotesRegex.test(profile.firstName)) {
      errors.firstName = "Quotes are not allowed in first name.";
    }

    if (!profile.lastName.trim()) {
      errors.lastName = "Last name is required.";
    } else if (!nameRegex.test(profile.lastName)) {
      errors.lastName = "Last name must contain only letters.";
    } else if (!noQuotesRegex.test(profile.lastName)) {
      errors.lastName = "Quotes are not allowed in last name.";
    }

    if (!profile.email.trim()) {
      errors.email = "Email is required.";
    } else if (!emailRegex.test(profile.email)) {
      errors.email = "Invalid email address.";
    } else if (!noQuotesRegex.test(profile.email)) {
      errors.email = "Quotes are not allowed in email.";
    }

    if (!profile.phone.trim()) {
      errors.phone = "Phone number is required.";
    } else if (!phoneRegex.test(profile.phone)) {
      errors.phone = "Phone number must be exactly 10 digits.";
    }

    const stringFields = ["department", "designation", "bankAccount", "status"];
    stringFields.forEach((field) => {
      if (!profile[field].trim()) {
        errors[field] = `${field} is required.`;
      } else if (!noQuotesRegex.test(profile[field])) {
        errors[field] = "Quotes are not allowed.";
      }
    });

    return errors;
  };

  const handleUpdate = async () => {
    const errors = validateProfile();
    if (Object.keys(errors).length > 0) {
      setValidationErrors(errors);
      toast.error("Please fix the validation errors!", {
        position: "top-center",
        autoClose: 3000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        theme: "colored",
      });
      return;
    }

    try {
      await axios.put("http://localhost:8080/api/users/me", profile, {
        headers: { Authorization: `Bearer ${token}` },
      });

      toast.success("Profile updated successfully!", {
        position: "top-center",
        autoClose: 3000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        theme: "colored",
      });

      setValidationErrors({});
      setEditMode(false);
    } catch (err) {
      toast.error("Failed to update profile!", {
        position: "top-center",
        autoClose: 3000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        theme: "colored",
      });
    }
  };

  // return (
  //   <>
  //     <HeaderNavbar />
  //     <div className="max-w-5xl mx-auto px-6 py-8">
  //       <h2 className="text-3xl font-semibold text-gray-800 mb-6">
  //         Employee Profile
  //       </h2>

  //       <div className="bg-gradient-to-br from-blue-100 to-blue-200 shadow rounded-lg p-6">
  //         <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
  //           {Object.entries(profile).map(([key, value]) => (
  //             <div key={key}>
  //               <label className="block font-medium text-gray-700 capitalize text-sm">
  //                 {key.replace(/([A-Z])/g, " $1")}
  //               </label>
  //               <input
  //                 type={key.toLowerCase().includes("date") ? "date" : "text"}
  //                 name={key}
  //                 value={
  //                   key.includes("Date") ? value?.split("T")[0] : value || ""
  //                 }
  //                 onChange={handleChange}
  //                 className={`w-full border text-sm px-3 py-1.5 rounded-md mt-1 bg-white ${
  //                   validationErrors[key] ? "border-red-500" : ""
  //                 }`}
  //                 disabled={
  //                   !editMode ||
  //                   key === "employeeId" ||
  //                   key === "createdAt" ||
  //                   key === "employmentType" ||
  //                   key === "username" ||
  //                   key === "joinDate"
  //                 }
  //               />
  //               {validationErrors[key] && (
  //                 <p className="text-red-600 text-xs mt-1">
  //                   {validationErrors[key]}
  //                 </p>
  //               )}
  //             </div>
  //           ))}
  //         </div>

  //         <div className="flex justify-end gap-4 mt-6">
  //           {editMode ? (
  //             <>
  //               <button
  //                 onClick={handleUpdate}
  //                 className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700 text-sm"
  //               >
  //                 Save Changes
  //               </button>
  //               <button
  //                 onClick={() => {
  //                   setEditMode(false);
  //                   setValidationErrors({});
  //                 }}
  //                 className="bg-gray-400 text-white px-4 py-2 rounded hover:bg-gray-500 text-sm"
  //               >
  //                 Cancel
  //               </button>
  //             </>
  //           ) : (
  //             <button
  //               onClick={() => setEditMode(true)}
  //               className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 text-sm"
  //             >
  //               Edit Profile
  //             </button>
  //           )}
  //         </div>
  //       </div>
  //     </div>
  //     <Footer />
  //     <ToastContainer />
  //   </>
//   // );
//   return (
//   <div className="min-h-screen flex flex-col bg-[#eaeaea]">
//     <HeaderNavbar />

//     <main className="flex-grow max-w-5xl mx-auto px-6 py-8">
//       <h2 className="text-3xl font-semibold text-gray-800 mb-6">
//         Employee Profile
//       </h2>

//       <div className="bg-gradient-to-r from-[#1f3b57] via-[#476b8c] to-[#1c2e44] shadow-lg rounded-lg p-6 text-white">
//         <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
//           {Object.entries(profile).map(([key, value]) => (
//             <div key={key}>
//               <label className="block font-medium capitalize text-sm mb-1">
//                 {key.replace(/([A-Z])/g, " $1")}
//               </label>
//               <input
//                 type={key.toLowerCase().includes("date") ? "date" : "text"}
//                 name={key}
//                 value={
//                   key.includes("Date") ? value?.split("T")[0] : value || ""
//                 }
//                 onChange={handleChange}
//                 className={`w-full border text-sm px-3 py-1.5 rounded-md mt-1 bg-white text-black ${
//                   validationErrors[key] ? "border-red-500" : ""
//                 }`}
//                 disabled={
//                   !editMode ||
//                   key === "employeeId" ||
//                   key === "createdAt" ||
//                   key === "employmentType" ||
//                   key === "username" ||
//                   key === "joinDate"
//                 }
//               />
//               {validationErrors[key] && (
//                 <p className="text-red-200 text-xs mt-1">
//                   {validationErrors[key]}
//                 </p>
//               )}
//             </div>
//           ))}
//         </div>

//         <div className="flex justify-end gap-4 mt-6">
//           {editMode ? (
//             <>
//               <button
//                 onClick={handleUpdate}
//                 className="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600 text-sm"
//               >
//                 Save Changes
//               </button>
//               <button
//                 onClick={() => {
//                   setEditMode(false);
//                   setValidationErrors({});
//                 }}
//                 className="bg-gray-400 text-white px-4 py-2 rounded hover:bg-gray-500 text-sm"
//               >
//                 Cancel
//               </button>
//             </>
//           ) : (
//             <button
//               onClick={() => setEditMode(true)}
//               className="bg-white text-[#1f3b57] px-4 py-2 rounded hover:bg-gray-100 text-sm font-semibold"
//             >
//               Edit Profile
//             </button>
//           )}
//         </div>
//       </div>
//     </main>

//     <Footer />
//     <ToastContainer />
//   </div>
// );
return (
  <div className="min-h-screen flex flex-col bg-[#eaeaea]">
    <HeaderNavbar />

    <main className="flex-grow max-w-5xl mx-auto px-6 py-8">
      <h2 className="text-3xl font-semibold text-gray-800 mb-8 border-b pb-2">
        Employee Profile
      </h2>

      <div className="bg-gradient-to-r from-[#1f3b57] via-[#476b8c] to-[#1c2e44] shadow-xl rounded-xl p-8 text-white">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-10 gap-y-6">
          {Object.entries(profile).map(([key, value]) => (
            <div key={key} className="flex flex-col">
              <label className="block font-semibold capitalize text-sm mb-2 tracking-wide text-gray-200">
                {key.replace(/([A-Z])/g, " $1")}
              </label>
              <input
                type={key.toLowerCase().includes("date") ? "date" : "text"}
                name={key}
                value={key.includes("Date") ? value?.split("T")[0] : value || ""}
                onChange={handleChange}
                className={`w-full border text-sm px-4 py-2 rounded-lg bg-white text-black focus:outline-none focus:ring-2 focus:ring-blue-400 ${
                  validationErrors[key] ? "border-red-500" : "border-gray-300"
                }`}
                disabled={
                  !editMode ||
                  key === "employeeId" ||
                  key === "createdAt" ||
                  key === "employmentType" ||
                  key === "username" ||
                  key === "joinDate"
                }
              />
              {validationErrors[key] && (
                <p className="text-red-200 text-xs mt-1">
                  {validationErrors[key]}
                </p>
              )}
            </div>
          ))}
        </div>

        <div className="flex justify-end gap-4 mt-8">
          {editMode ? (
            <>
              <button
                onClick={handleUpdate}
                className="bg-green-500 text-white px-5 py-2.5 rounded-lg hover:bg-green-600 text-sm font-medium shadow"
              >
                Save Changes
              </button>
              <button
                onClick={() => {
                  setEditMode(false);
                  setValidationErrors({});
                }}
                className="bg-gray-400 text-white px-5 py-2.5 rounded-lg hover:bg-gray-500 text-sm font-medium shadow"
              >
                Cancel
              </button>
            </>
          ) : (
            <button
              onClick={() => setEditMode(true)}
              className="bg-white text-[#1f3b57] px-5 py-2.5 rounded-lg hover:bg-gray-100 text-sm font-semibold shadow"
            >
              Edit Profile
            </button>
          )}
        </div>
      </div>
    </main>

    <Footer />
    <ToastContainer />
  </div>
);

};

export default Profile;
