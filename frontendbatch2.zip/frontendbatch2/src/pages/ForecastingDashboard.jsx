// import React, { useEffect, useState } from 'react';
// import axios from 'axios';
// import { useNavigate } from 'react-router-dom';
// import HeaderNavbar from '../component/HeaderNavbar';
// import Footer from '../component/Footer';
// import { motion } from 'framer-motion';
// import { Bar, Line, Pie } from 'react-chartjs-2';
// import { Chart, registerables } from 'chart.js';
// Chart.register(...registerables);

// const ForecastingDashboard = () => {
//   const [employee, setEmployee] = useState(null);
//   const [attendance, setAttendance] = useState([]);
//   const [leaves, setLeaves] = useState([]);
//   const [payrolls, setPayrolls] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState(null);
//   const navigate = useNavigate();

//   useEffect(() => {
//     const fetchEmployeeData = async () => {
//       try {
//         const token = localStorage.getItem('token');
//         if (!token) {
//           navigate('/login');
//           return;
//         }

//         const config = {
//           headers: { Authorization: `Bearer ${token}` }
//         };

//         // Fetch employee details
//         const employeeRes = await axios.get('http://localhost:8080/api/employees/me', config);
//         const employeeData = employeeRes.data;
//         setEmployee(employeeData);

//         // Fetch all data in parallel
//         const [attendanceRes, leavesRes, payrollsRes] = await Promise.all([
//           axios.get('http://localhost:8080/api/attendance', config),
//           axios.get('http://localhost:8080/api/leaves/employee/' + employeeData.id, config),
//           axios.get('http://localhost:8080/api/payrolls', config)
//         ]);

//         // Filter data for current employee
//         const filteredAttendance = attendanceRes.data.filter(
//           a => a.employee && a.employee.id === employeeData.id
//         );
//         setAttendance(filteredAttendance);

//         setLeaves(leavesRes.data);

//         const filteredPayrolls = payrollsRes.data.filter(
//           p => p.employeeId === employeeData.id
//         );
//         setPayrolls(filteredPayrolls);

//       } catch (err) {
//         setError(err.response?.data?.message || 'Failed to fetch data');
//         console.error('Error fetching data:', err);
//       } finally {
//         setLoading(false);
//       }
//     };

//     fetchEmployeeData();
//   }, [navigate]);

//   // Process data for forecasting
//   const processForecastData = () => {
//     if (!employee) return {};

//     // Current date and month calculations
//     const currentDate = new Date();
//     const currentMonth = currentDate.getMonth();
//     const currentYear = currentDate.getFullYear();
//     const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

//     // 1. Salary Forecast
//     const processedPayrolls = payrolls.filter(p => p.paymentStatus === 'PROCESSED');
    
//     // Group payrolls by month and calculate averages
//     const monthlyPayrolls = {};
//     processedPayrolls.forEach(payroll => {
//       const payrollDate = new Date(payroll.processedAt);
//       const monthYear = `${payrollDate.getFullYear()}-${payrollDate.getMonth()}`;
      
//       if (!monthlyPayrolls[monthYear]) {
//         monthlyPayrolls[monthYear] = {
//           total: 0,
//           count: 0,
//           month: payrollDate.getMonth(),
//           year: payrollDate.getFullYear()
//         };
//       }
      
//       monthlyPayrolls[monthYear].total += payroll.netSalary;
//       monthlyPayrolls[monthYear].count++;
//     });

//     // Calculate monthly averages and prepare for forecasting
//     const payrollHistory = Object.values(monthlyPayrolls)
//       .map(item => ({
//         month: item.month,
//         year: item.year,
//         average: item.total / item.count,
//         monthName: months[item.month]
//       }))
//       .sort((a, b) => a.year - b.year || a.month - b.month);

//     // Simple linear regression for salary forecast
//     let salaryForecast = null;
//     if (payrollHistory.length >= 3) {
//       const n = payrollHistory.length;
//       let sumX = 0, sumY = 0, sumXY = 0, sumXX = 0;
      
//       payrollHistory.forEach((item, index) => {
//         sumX += index;
//         sumY += item.average;
//         sumXY += index * item.average;
//         sumXX += index * index;
//       });
      
//       const slope = (n * sumXY - sumX * sumY) / (n * sumXX - sumX * sumX);
//       const intercept = (sumY - slope * sumX) / n;
      
//       salaryForecast = intercept + slope * n;
//     }

//     // 2. Attendance Forecast
//     const monthlyAttendance = Array(12).fill(0);
//     const attendanceByDayOfWeek = Array(7).fill(0);
    
//     attendance.forEach(record => {
//       const date = new Date(record.workDate);
//       if (date.getFullYear() === currentYear) {
//         monthlyAttendance[date.getMonth()]++;
//         attendanceByDayOfWeek[date.getDay()]++;
//       }
//     });

//     // Calculate average attendance per month
//     const avgAttendancePerMonth = monthlyAttendance.reduce((sum, val) => sum + val, 0) / 
//       (monthlyAttendance.filter(val => val > 0).length || 1);

//     // 3. Leave Forecast
//     const leaveTypes = {
//       CASUAL: 0,
//       SICK: 0,
//       ANNUAL: 0,
//       UNPAID: 0
//     };
    
//     leaves.forEach(leave => {
//       leaveTypes[leave.leaveType]++;
//       if (!leave.isPaid) leaveTypes.UNPAID++;
//     });

//     // Calculate leave usage rate
//     const totalLeavesTaken = leaves.length;
//     const employmentDurationMonths = Math.max(1, 
//       (currentYear - new Date(employee.joinDate).getFullYear()) * 12 + 
//       (currentMonth - new Date(employee.joinDate).getMonth())
//     );
    
//     const leavesPerMonth = totalLeavesTaken / employmentDurationMonths;

//     // 4. Overtime Forecast
//     const totalOvertime = attendance.reduce((sum, a) => sum + (a.overtimeHours || 0), 0);
//     const avgOvertimePerMonth = totalOvertime / (monthlyAttendance.filter(val => val > 0).length || 1);


//     // 5. Year-end Projections
//     const monthsRemaining = 12 - currentMonth - 1;
//     const projectedLeaves = Math.round(leavesPerMonth * monthsRemaining);
//     const projectedOvertime = Math.round(avgOvertimePerMonth * monthsRemaining);
//     const projectedWorkDays = Math.round(avgAttendancePerMonth * monthsRemaining);

//     return {
//       payrollHistory,
//       salaryForecast,
//       monthlyAttendance,
//       attendanceByDayOfWeek,
//       avgAttendancePerMonth,
//       leaveTypes,
//       leavesPerMonth,
//       totalOvertime,
//       avgOvertimePerMonth,
//       projectedLeaves,
//       projectedOvertime,
//       projectedWorkDays,
//       monthsRemaining,
//       employmentDurationMonths,
//       months
//     };
//   };

//   const forecastData = processForecastData();

//   // Format currency
//   const formatCurrency = (amount) => {
//     return new Intl.NumberFormat('en-IN', {
//       style: 'currency',
//       currency: 'INR',
//       minimumFractionDigits: 0,
//       maximumFractionDigits: 0
//     }).format(amount || 0);
//   };

//   // Format date
//   const formatDate = (dateString) => {
//     if (!dateString) return 'N/A';
//     const options = { year: 'numeric', month: 'short', day: 'numeric' };
//     return new Date(dateString).toLocaleDateString(undefined, options);
//   };

//   // Chart data
//   const salaryTrendData = {
//     labels: forecastData.payrollHistory?.map(p => `${p.monthName} ${p.year}`) || [],
//     datasets: [
//       {
//         label: 'Average Monthly Salary',
//         data: forecastData.payrollHistory?.map(p => p.average) || [],
//         borderColor: 'rgba(54, 162, 235, 1)',
//         backgroundColor: 'rgba(54, 162, 235, 0.2)',
//         tension: 0.3,
//         fill: true
//       },
//       ...(forecastData.salaryForecast ? [{
//         label: 'Projected Next Salary',
//         data: [
//           ...forecastData.payrollHistory?.map(() => null),
//           forecastData.salaryForecast
//         ],
//         borderColor: 'rgba(75, 192, 192, 1)',
//         backgroundColor: 'rgba(75, 192, 192, 0.2)',
//         borderDash: [5, 5],
//         pointBackgroundColor: 'rgba(75, 192, 192, 1)'
//       }] : [])
//     ]
//   };

//   const attendancePatternData = {
//     labels: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
//     datasets: [{
//       label: 'Attendance by Day of Week',
//       data: forecastData.attendanceByDayOfWeek,
//       backgroundColor: 'rgba(255, 99, 132, 0.5)',
//       borderColor: 'rgba(255, 99, 132, 1)',
//       borderWidth: 1
//     }]
//   };

//   const leaveForecastData = {
//     labels: ['Casual', 'Sick', 'Annual', 'Unpaid'],
//     datasets: [{
//       label: 'Leaves Taken',
//       data: [
//         forecastData.leaveTypes?.CASUAL || 0,
//         forecastData.leaveTypes?.SICK || 0,
//         forecastData.leaveTypes?.ANNUAL || 0,
//         forecastData.leaveTypes?.UNPAID || 0
//       ],
//       backgroundColor: [
//         'rgba(54, 162, 235, 0.5)',
//         'rgba(75, 192, 192, 0.5)',
//         'rgba(153, 102, 255, 0.5)',
//         'rgba(255, 99, 132, 0.5)'
//       ],
//       borderColor: [
//         'rgba(54, 162, 235, 1)',
//         'rgba(75, 192, 192, 1)',
//         'rgba(153, 102, 255, 1)',
//         'rgba(255, 99, 132, 1)'
//       ],
//       borderWidth: 1
//     }]
//   };

//   if (loading) {
//     return (
//       <div className="min-h-screen flex items-center justify-center">
//         <div className="text-xl">Loading forecasting dashboard...</div>
//       </div>
//     );
//   }

//   if (error) {
//     return (
//       <div className="min-h-screen flex items-center justify-center">
//         <div className="text-red-500 text-xl">{error}</div>
//       </div>
//     );
//   }

//   if (!employee) {
//     return (
//       <div className="min-h-screen flex items-center justify-center">
//         <div className="text-xl">No employee data found</div>
//       </div>
//     );
//   }

//   return (
//     <>
//       <HeaderNavbar />
//       <div className="min-h-[calc(100vh-64px)] bg-gray-50 p-4 md:p-6">
//         <div className="max-w-7xl mx-auto">
//           {/* Header */}
//           <motion.div
//             initial={{ opacity: 0, y: -20 }}
//             animate={{ opacity: 1, y: 0 }}
//             transition={{ duration: 0.5 }}
//             className="bg-white rounded-xl shadow-sm p-6 mb-6 border border-gray-100"
//           >
//             <div className="flex flex-col md:flex-row items-start md:items-center justify-between">
//               <div className="flex items-center space-x-4">
//                 <div className="bg-indigo-100 p-3 rounded-full">
//                   <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
//                     <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
//                   </svg>
//                 </div>
//                 <div>
//                   <h1 className="text-2xl font-bold text-gray-800">
//                     Forecasting Insights for {employee.firstName} {employee.lastName}
//                   </h1>
//                   <p className="text-gray-600">
//                     Predictive analytics based on your historical data
//                   </p>
//                 </div>
//               </div>
//               <div className="mt-4 md:mt-0 grid grid-cols-2 gap-4 text-sm">
//                 <div>
//                   <p className="text-gray-500">Employment Duration</p>
//                   <p className="font-medium">{forecastData.employmentDurationMonths} months</p>
//                 </div>
//                 <div>
//                   <p className="text-gray-500">Data Points</p>
//                   <p className="font-medium">
//                     {payrolls.length} payrolls • {attendance.length} attendance • {leaves.length} leaves
//                   </p>
//                 </div>
//               </div>
//             </div>
//           </motion.div>

//           {/* Key Forecasts */}
//           <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
//             {/* Salary Forecast */}
//             <motion.div
//               initial={{ opacity: 0, y: 20 }}
//               animate={{ opacity: 1, y: 0 }}
//               transition={{ duration: 0.3, delay: 0.1 }}
//               className="bg-white rounded-xl shadow-sm p-6 border border-gray-100"
//             >
//               <div className="flex items-center justify-between">
//                 <div>
//                   <p className="text-sm font-medium text-gray-500">Salary Forecast</p>
//                   <p className="text-2xl font-bold text-gray-800 mt-1">
//                     {forecastData.salaryForecast ? formatCurrency(forecastData.salaryForecast) : 'N/A'}
//                   </p>
//                 </div>
//                 <div className="bg-blue-100 p-3 rounded-lg">
//                   <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
//                     <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
//                   </svg>
//                 </div>
//               </div>
//               <div className="mt-4 pt-4 border-t border-gray-100">
//                 {/* <p className="text-xs text-gray-500">
//                   Based on {forecastData.payrollHistory?.length || 0} months of data
//                   {forecastData.salaryForecast && (
//                     <span> • Projected increase: {(
//                       ((forecastData.salaryForecast - (forecastData.payrollHistory[forecastData.payrollHistory.length - 1]?.average || 0)) / 
//                       (forecastData.payrollHistory[forecastData.payrollHistory.length - 1]?.average || 1) * 100
//                     ).toFixed(1)}%</span>
//                   )}
//                 </p> */}
//                 <p className="text-xs text-gray-500">
//                 Based on {forecastData.payrollHistory?.length || 0} months of data
//                 {forecastData.salaryForecast && (
//                   <span>
//                     • Projected increase:{' '}
//                     {(
//                       ((forecastData.salaryForecast - (forecastData.payrollHistory[forecastData.payrollHistory.length - 1]?.average || 0)) /
//                         (forecastData.payrollHistory[forecastData.payrollHistory.length - 1]?.average || 1)) * 100
//                     ).toFixed(1)}%
//                   </span>
//                 )}
//               </p>
//               </div>
//             </motion.div>

//             {/* Work Days Forecast */}
//             <motion.div
//               initial={{ opacity: 0, y: 20 }}
//               animate={{ opacity: 1, y: 0 }}
//               transition={{ duration: 0.3, delay: 0.2 }}
//               className="bg-white rounded-xl shadow-sm p-6 border border-gray-100"
//             >
//               <div className="flex items-center justify-between">
//                 <div>
//                   <p className="text-sm font-medium text-gray-500">Projected Work Days</p>
//                   <p className="text-2xl font-bold text-gray-800 mt-1">
//                     {Math.round(forecastData.projectedWorkDays)} days
//                   </p>
//                 </div>
//                 <div className="bg-green-100 p-3 rounded-lg">
//                   <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
//                     <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
//                   </svg>
//                 </div>
//               </div>
//               <div className="mt-4 pt-4 border-t border-gray-100">
//                 <p className="text-xs text-gray-500">
//                   Avg. {forecastData.avgAttendancePerMonth.toFixed(1)} days/month • {forecastData.monthsRemaining} months remaining
//                 </p>
//               </div>
//             </motion.div>

//             {/* Leaves Forecast */}
//             <motion.div
//               initial={{ opacity: 0, y: 20 }}
//               animate={{ opacity: 1, y: 0 }}
//               transition={{ duration: 0.3, delay: 0.3 }}
//               className="bg-white rounded-xl shadow-sm p-6 border border-gray-100"
//             >
//               <div className="flex items-center justify-between">
//                 <div>
//                   <p className="text-sm font-medium text-gray-500">Projected Leaves</p>
//                   <p className="text-2xl font-bold text-gray-800 mt-1">
//                     {forecastData.projectedLeaves} days
//                   </p>
//                 </div>
//                 <div className="bg-yellow-100 p-3 rounded-lg">
//                   <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-yellow-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
//                     <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
//                   </svg>
//                 </div>
//               </div>
//               <div className="mt-4 pt-4 border-t border-gray-100">
//                 <p className="text-xs text-gray-500">
//                   Current rate: {forecastData.leavesPerMonth.toFixed(1)} leaves/month
//                 </p>
//               </div>
//             </motion.div>

//             {/* Overtime Forecast */}
//             <motion.div
//               initial={{ opacity: 0, y: 20 }}
//               animate={{ opacity: 1, y: 0 }}
//               transition={{ duration: 0.3, delay: 0.4 }}
//               className="bg-white rounded-xl shadow-sm p-6 border border-gray-100"
//             >
//               <div className="flex items-center justify-between">
//                 <div>
//                   <p className="text-sm font-medium text-gray-500">Projected Overtime</p>
//                   <p className="text-2xl font-bold text-gray-800 mt-1">
//                     {forecastData.projectedOvertime.toFixed(1)} hours
//                   </p>
//                 </div>
//                 <div className="bg-red-100 p-3 rounded-lg">
//                   <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
//                     <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
//                   </svg>
//                 </div>
//               </div>
//               <div className="mt-4 pt-4 border-t border-gray-100">
//                 <p className="text-xs text-gray-500">
//                   Avg. {forecastData.avgOvertimePerMonth.toFixed(1)} hours/month
//                 </p>
//               </div>
//             </motion.div>
//           </div>

//           {/* Charts Section */}
//           <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
//             {/* Salary Trend */}
//             <motion.div
//               initial={{ opacity: 0, y: 20 }}
//               animate={{ opacity: 1, y: 0 }}
//               transition={{ duration: 0.5, delay: 0.5 }}
//               className="bg-white rounded-xl shadow-sm p-6 border border-gray-100"
//             >
//               <h3 className="text-lg font-semibold text-gray-800 mb-4">Salary Trend & Forecast</h3>
//               <div className="h-64">
//                 <Line 
//                   data={salaryTrendData}
//                   options={{
//                     responsive: true,
//                     maintainAspectRatio: false,
//                     scales: {
//                       y: {
//                         beginAtZero: false,
//                         ticks: {
//                           callback: function(value) {
//                             return formatCurrency(value);
//                           }
//                         }
//                       }
//                     },
//                     plugins: {
//                       tooltip: {
//                         callbacks: {
//                           label: function(context) {
//                             return formatCurrency(context.raw);
//                           }
//                         }
//                       },
//                       legend: {
//                         position: 'bottom'
//                       }
//                     }
//                   }}
//                 />
//               </div>
//               <p className="text-xs text-gray-500 mt-2">
//                 {forecastData.salaryForecast ? 
//                   "Projection based on linear regression of your historical salary data" :
//                   "Insufficient data (need at least 3 months) for reliable salary projection"}
//               </p>
//             </motion.div>

//             {/* Attendance Patterns */}
//             <motion.div
//               initial={{ opacity: 0, y: 20 }}
//               animate={{ opacity: 1, y: 0 }}
//               transition={{ duration: 0.5, delay: 0.7 }}
//               className="bg-white rounded-xl shadow-sm p-6 border border-gray-100"
//             >
//               <h3 className="text-lg font-semibold text-gray-800 mb-4">Weekly Attendance Pattern</h3>
//               <div className="h-64">
//                 <Bar 
//                   data={attendancePatternData}
//                   options={{
//                     responsive: true,
//                     maintainAspectRatio: false,
//                     scales: {
//                       y: {
//                         beginAtZero: true,
//                         ticks: {
//                           precision: 0
//                         }
//                       }
//                     },
//                     plugins: {
//                       legend: {
//                         display: false
//                       }
//                     }
//                   }}
//                 />
//               </div>
//               <p className="text-xs text-gray-500 mt-2">
//                 Shows your typical attendance pattern by day of week (higher bars indicate more frequent attendance)
//               </p>
//             </motion.div>
//           </div>

//           {/* Detailed Insights */}
//           <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
//             {/* Leave Forecast */}
//             <motion.div
//               initial={{ opacity: 0, y: 20 }}
//               animate={{ opacity: 1, y: 0 }}
//               transition={{ duration: 0.5, delay: 0.9 }}
//               className="bg-white rounded-xl shadow-sm p-6 border border-gray-100"
//             >
//               <h3 className="text-lg font-semibold text-gray-800 mb-4">Leave Usage Analysis</h3>
//               <div className="h-64">
//                 <Pie 
//                   data={leaveForecastData}
//                   options={{
//                     responsive: true,
//                     maintainAspectRatio: false,
//                     plugins: {
//                       legend: {
//                         position: 'right'
//                       }
//                     }
//                   }}
//                 />
//               </div>
//               <div className="mt-4 pt-4 border-t border-gray-100">
//                 <h4 className="text-sm font-medium text-gray-800 mb-2">Leave Projections</h4>
//                 <div className="grid grid-cols-2 gap-4 text-sm">
//                   <div>
//                     <p className="text-gray-500">Casual Leaves Taken</p>
//                     <p className="font-medium">{forecastData.leaveTypes?.CASUAL || 0}/10</p>
//                   </div>
//                   <div>
//                     <p className="text-gray-500">Sick Leaves Taken</p>
//                     <p className="font-medium">{forecastData.leaveTypes?.SICK || 0}/10</p>
//                   </div>
//                   <div>
//                     <p className="text-gray-500">Annual Leaves Taken</p>
//                     <p className="font-medium">{forecastData.leaveTypes?.ANNUAL || 0}/12</p>
//                   </div>
//                   <div>
//                     <p className="text-gray-500">Projected Additional Leaves</p>
//                     <p className="font-medium">{forecastData.projectedLeaves}</p>
//                   </div>
//                 </div>
//               </div>
//             </motion.div>

//             {/* Year-End Projections */}
//             <motion.div
//               initial={{ opacity: 0, y: 20 }}
//               animate={{ opacity: 1, y: 0 }}
//               transition={{ duration: 0.5, delay: 1.1 }}
//               className="bg-white rounded-xl shadow-sm p-6 border border-gray-100"
//             >
//               <h3 className="text-lg font-semibold text-gray-800 mb-4">Year-End Projections</h3>
//               <div className="space-y-4">
//                 <div className="p-4 bg-blue-50 rounded-lg">
//                   <div className="flex items-center">
//                     <div className="bg-blue-100 p-2 rounded-lg mr-4">
//                       <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
//                         <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
//                       </svg>
//                     </div>
//                     <div>
//                       <h4 className="font-medium text-gray-800">Estimated Annual Earnings</h4>
//                       <p className="text-sm text-gray-600 mt-1">
//                         {formatCurrency(
//                           (forecastData.payrollHistory.reduce((sum, p) => sum + p.average, 0) / 
//                           forecastData.payrollHistory.length) * 12
//                         )}
//                       </p>
//                     </div>
//                   </div>
//                 </div>

//                 <div className="p-4 bg-green-50 rounded-lg">
//                   <div className="flex items-center">
//                     <div className="bg-green-100 p-2 rounded-lg mr-4">
//                       <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
//                         <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
//                       </svg>
//                     </div>
//                     <div>
//                       <h4 className="font-medium text-gray-800">Projected Total Work Days</h4>
//                       <p className="text-sm text-gray-600 mt-1">
//                         {Math.round(forecastData.avgAttendancePerMonth * 12)} days
//                       </p>
//                     </div>
//                   </div>
//                 </div>

//                 <div className="p-4 bg-yellow-50 rounded-lg">
//                   <div className="flex items-center">
//                     <div className="bg-yellow-100 p-2 rounded-lg mr-4">
//                       <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-yellow-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
//                         <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
//                       </svg>
//                     </div>
//                     <div>
//                       <h4 className="font-medium text-gray-800">Projected Total Leaves</h4>
//                       <p className="text-sm text-gray-600 mt-1">
//                         {Math.round(forecastData.leavesPerMonth * 12)} days
//                       </p>
//                     </div>
//                   </div>
//                 </div>

//                 <div className="p-4 bg-purple-50 rounded-lg">
//                   <div className="flex items-center">
//                     <div className="bg-purple-100 p-2 rounded-lg mr-4">
//                       <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-purple-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
//                         <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
//                       </svg>
//                     </div>
//                     <div>
//                       <h4 className="font-medium text-gray-800">Projected Total Overtime</h4>
//                       <p className="text-sm text-gray-600 mt-1">
//                         {Math.round(forecastData.avgOvertimePerMonth * 12)} hours
//                       </p>
//                     </div>
//                   </div>
//                 </div>
//               </div>
//             </motion.div>
//           </div>

//           {/* Data Quality Note */}
//           <motion.div
//             initial={{ opacity: 0, y: 20 }}
//             animate={{ opacity: 1, y: 0 }}
//             transition={{ duration: 0.5, delay: 1.3 }}
//             className="bg-white rounded-xl shadow-sm p-6 border border-gray-100 mb-6"
//           >
//             <div className="flex items-start">
//               <div className="bg-gray-100 p-2 rounded-lg mr-4">
//                 <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
//                   <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
//                 </svg>
//               </div>
//               <div>
//                 <h4 className="font-medium text-gray-800">About These Forecasts</h4>
//                 <div className="text-sm text-gray-600 mt-1 space-y-2">
//                   <p>
//                     These projections are based on your historical data patterns. Forecasts become more accurate as more data becomes available.
//                   </p>
//                   <p>
//                     <span className="font-medium">Salary Forecast:</span> {forecastData.payrollHistory?.length >= 3 ? 
//                       "Calculated using linear regression on your past salary data" : 
//                       "Insufficient data (need at least 3 processed payrolls)"}
//                   </p>
//                   <p>
//                     <span className="font-medium">Work Days/Leaves/Overtime:</span> Projected based on your average monthly patterns.
//                   </p>
//                 </div>
//               </div>
//             </div>
//           </motion.div>
//         </div>
//       </div>
//       <Footer />
//     </>
//   );
// };

// export default ForecastingDashboard;
// import React, { useEffect, useState } from 'react';
// import axios from 'axios';
// import { useNavigate } from 'react-router-dom';
// import HeaderNavbar from '../component/HeaderNavbar';
// import Footer from '../component/Footer';
// import { motion } from 'framer-motion';
// import { Bar, Line, Pie } from 'react-chartjs-2';
// import { Chart, registerables } from 'chart.js';
// Chart.register(...registerables);

// const ForecastingDashboard = () => {
//   const [employee, setEmployee] = useState(null);
//   const [attendance, setAttendance] = useState([]);
//   const [leaves, setLeaves] = useState([]);
//   const [payrolls, setPayrolls] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState(null);
//   const navigate = useNavigate();

//   useEffect(() => {
//     const fetchEmployeeData = async () => {
//       try {
//         const token = localStorage.getItem('token');
//         if (!token) {
//           navigate('/login');
//           return;
//         }

//         const config = {
//           headers: { Authorization: `Bearer ${token}` }
//         };

//         // Fetch employee details
//         const employeeRes = await axios.get('http://localhost:8080/api/employees/me', config);
//         const employeeData = employeeRes.data;
//         setEmployee(employeeData);

//         // Fetch all data in parallel
//         const [attendanceRes, leavesRes, payrollsRes] = await Promise.all([
//           axios.get('http://localhost:8080/api/attendance', config),
//           axios.get('http://localhost:8080/api/leaves/employee/' + employeeData.id, config),
//           axios.get('http://localhost:8080/api/payrolls', config)
//         ]);

//         // Filter data for current employee
//         const filteredAttendance = attendanceRes.data.filter(
//           a => a.employee && a.employee.id === employeeData.id
//         );
//         setAttendance(filteredAttendance);

//         setLeaves(leavesRes.data);

//         const filteredPayrolls = payrollsRes.data.filter(
//           p => p.employeeId === employeeData.id
//         ).sort((a, b) => new Date(a.processedAt) - new Date(b.processedAt));
//         setPayrolls(filteredPayrolls);

//       } catch (err) {
//         setError(err.response?.data?.message || 'Failed to fetch data');
//         console.error('Error fetching data:', err);
//       } finally {
//         setLoading(false);
//       }
//     };

//     fetchEmployeeData();
//   }, [navigate]);

//   // Process data for forecasting
//   const processForecastData = () => {
//     if (!employee || payrolls.length === 0) return {};

//     // Current date and month calculations
//     const currentDate = new Date();
//     const currentMonth = currentDate.getMonth();
//     const currentYear = currentDate.getFullYear();
//     const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

//     // Process payroll data - we'll use processedAt date for timeline
//     const processedPayrolls = payrolls.filter(p => p.paymentStatus === 'PROCESSED');
    
//     // Group payrolls by month-year and calculate averages
//     const monthlyPayrollData = {};
//     processedPayrolls.forEach(payroll => {
//       const payrollDate = new Date(payroll.processedAt);
//       const monthYear = `${payrollDate.getFullYear()}-${payrollDate.getMonth()}`;
      
//       if (!monthlyPayrollData[monthYear]) {
//         monthlyPayrollData[monthYear] = {
//           totalNetSalary: 0,
//           count: 0,
//           month: payrollDate.getMonth(),
//           year: payrollDate.getFullYear(),
//           monthName: months[payrollDate.getMonth()]
//         };
//       }
      
//       monthlyPayrollData[monthYear].totalNetSalary += payroll.netSalary;
//       monthlyPayrollData[monthYear].count++;
//     });

//     // Convert to array and calculate averages
//     const payrollHistory = Object.values(monthlyPayrollData)
//       .map(item => ({
//         ...item,
//         averageNetSalary: item.totalNetSalary / item.count
//       }))
//       .sort((a, b) => a.year - b.year || a.month - b.month);

//     // Calculate salary forecast using linear regression if we have enough data
//     let salaryForecast = null;
//     if (payrollHistory.length >= 3) {
//       const n = payrollHistory.length;
//       let sumX = 0, sumY = 0, sumXY = 0, sumXX = 0;
      
//       payrollHistory.forEach((item, index) => {
//         sumX += index;
//         sumY += item.averageNetSalary;
//         sumXY += index * item.averageNetSalary;
//         sumXX += index * index;
//       });
      
//       const slope = (n * sumXY - sumX * sumY) / (n * sumXX - sumX * sumX);
//       const intercept = (sumY - slope * sumX) / n;
      
//       salaryForecast = intercept + slope * n;
//     }

//     // Calculate employment duration in months
//     const joinDate = new Date(employee.joinDate);
//     const employmentDurationMonths = Math.max(1, 
//       (currentYear - joinDate.getFullYear()) * 12 + 
//       (currentMonth - joinDate.getMonth())
//     );

//     // Attendance analysis
//     const monthlyAttendance = Array(12).fill(0);
//     const attendanceByDayOfWeek = Array(7).fill(0);
//     let totalOvertime = 0;
    
//     attendance.forEach(record => {
//       const date = new Date(record.workDate);
//       if (date.getFullYear() === currentYear) {
//         monthlyAttendance[date.getMonth()]++;
//         attendanceByDayOfWeek[date.getDay()]++;
//       }
//       totalOvertime += record.overtimeHours || 0;
//     });

//     const avgAttendancePerMonth = monthlyAttendance.reduce((sum, val) => sum + val, 0) / 
//       Math.max(1, monthlyAttendance.filter(val => val > 0).length);
//     const avgOvertimePerMonth = totalOvertime / Math.max(1, monthlyAttendance.filter(val => val > 0).length);

//     // Leave analysis
//     const leaveTypes = {
//       CASUAL: 0,
//       SICK: 0,
//       ANNUAL: 0,
//       UNPAID: 0
//     };
    
//     leaves.forEach(leave => {
//       leaveTypes[leave.leaveType]++;
//       if (!leave.isPaid) leaveTypes.UNPAID++;
//     });

//     const leavesPerMonth = leaves.length / employmentDurationMonths;
//     const monthsRemaining = 12 - currentMonth - 1;

//     return {
//       payrollHistory,
//       salaryForecast,
//       monthlyAttendance,
//       attendanceByDayOfWeek,
//       avgAttendancePerMonth,
//       leaveTypes,
//       leavesPerMonth,
//       totalOvertime,
//       avgOvertimePerMonth,
//       projectedLeaves: Math.round(leavesPerMonth * monthsRemaining),
//       projectedOvertime: Math.round(avgOvertimePerMonth * monthsRemaining),
//       projectedWorkDays: Math.round(avgAttendancePerMonth * monthsRemaining),
//       monthsRemaining,
//       employmentDurationMonths,
//       months,
//       processedPayrollsCount: processedPayrolls.length
//     };
//   };

//   const forecastData = processForecastData();

//   // Format currency
//   const formatCurrency = (amount) => {
//     return new Intl.NumberFormat('en-IN', {
//       style: 'currency',
//       currency: 'INR',
//       minimumFractionDigits: 0,
//       maximumFractionDigits: 0
//     }).format(amount || 0);
//   };

//   // Chart data for salary trend
//   const salaryTrendData = {
//     labels: forecastData.payrollHistory?.map(p => `${p.monthName} ${p.year}`) || [],
//     datasets: [
//       {
//         label: 'Average Net Salary',
//         data: forecastData.payrollHistory?.map(p => p.averageNetSalary) || [],
//         borderColor: 'rgba(54, 162, 235, 1)',
//         backgroundColor: 'rgba(54, 162, 235, 0.2)',
//         tension: 0.3,
//         fill: true
//       },
//       ...(forecastData.salaryForecast ? [{
//         label: 'Projected Salary',
//         data: [
//           ...forecastData.payrollHistory?.map(() => null),
//           forecastData.salaryForecast
//         ],
//         borderColor: 'rgba(75, 192, 192, 1)',
//         backgroundColor: 'rgba(75, 192, 192, 0.2)',
//         borderDash: [5, 5],
//         pointBackgroundColor: 'rgba(75, 192, 192, 1)'
//       }] : [])
//     ]
//   };

//   // Chart data for attendance patterns
//   const attendancePatternData = {
//     labels: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
//     datasets: [{
//       label: 'Attendance by Day of Week',
//       data: forecastData.attendanceByDayOfWeek,
//       backgroundColor: 'rgba(255, 99, 132, 0.5)',
//       borderColor: 'rgba(255, 99, 132, 1)',
//       borderWidth: 1
//     }]
//   };

//   // Chart data for leave distribution
//   const leaveForecastData = {
//     labels: ['Casual', 'Sick', 'Annual', 'Unpaid'],
//     datasets: [{
//       label: 'Leaves Taken',
//       data: [
//         forecastData.leaveTypes?.CASUAL || 0,
//         forecastData.leaveTypes?.SICK || 0,
//         forecastData.leaveTypes?.ANNUAL || 0,
//         forecastData.leaveTypes?.UNPAID || 0
//       ],
//       backgroundColor: [
//         'rgba(54, 162, 235, 0.5)',
//         'rgba(75, 192, 192, 0.5)',
//         'rgba(153, 102, 255, 0.5)',
//         'rgba(255, 99, 132, 0.5)'
//       ],
//       borderColor: [
//         'rgba(54, 162, 235, 1)',
//         'rgba(75, 192, 192, 1)',
//         'rgba(153, 102, 255, 1)',
//         'rgba(255, 99, 132, 1)'
//       ],
//       borderWidth: 1
//     }]
//   };

//   if (loading) {
//     return (
//       <div className="min-h-screen flex items-center justify-center">
//         <div className="text-xl">Loading forecasting dashboard...</div>
//       </div>
//     );
//   }

//   if (error) {
//     return (
//       <div className="min-h-screen flex items-center justify-center">
//         <div className="text-red-500 text-xl">{error}</div>
//       </div>
//     );
//   }

//   if (!employee) {
//     return (
//       <div className="min-h-screen flex items-center justify-center">
//         <div className="text-xl">No employee data found</div>
//       </div>
//     );
//   }

//   return (
//     <>
//       <HeaderNavbar />
//       <div className="min-h-[calc(100vh-64px)] bg-[#eaeaea] p-4 md:p-6">
//         <div className="max-w-7xl mx-auto">
//           {/* Header */}
//           <motion.div
//             initial={{ opacity: 0, y: -20 }}
//             animate={{ opacity: 1, y: 0 }}
//             transition={{ duration: 0.5 }}
//             className="bg-white rounded-xl shadow-sm p-6 mb-6 border border-gray-100"
//           >
//             <div className="flex flex-col md:flex-row items-start md:items-center justify-between">
//               <div className="flex items-center space-x-4">
//                 <div className="bg-indigo-100 p-3 rounded-full">
//                   <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
//                     <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
//                   </svg>
//                 </div>
//                 <div>
//                   <h1 className="text-2xl font-bold text-gray-800">
//                     Forecasting Insights for {employee.firstName} {employee.lastName}
//                   </h1>
//                   <p className="text-gray-600">
//                     Predictive analytics based on your historical payroll, attendance, and leave data
//                   </p>
//                 </div>
//               </div>
//               <div className="mt-4 md:mt-0 grid grid-cols-2 gap-4 text-sm">
//                 <div>
//                   <p className="text-gray-500">Employment Duration</p>
//                   <p className="font-medium">{forecastData.employmentDurationMonths} months</p>
//                 </div>
//                 <div>
//                   <p className="text-gray-500">Data Points</p>
//                   <p className="font-medium">
//                     {payrolls.length} payrolls • {attendance.length} attendance • {leaves.length} leaves
//                   </p>
//                 </div>
//               </div>
//             </div>
//           </motion.div>

//           {/* Key Forecast Metrics */}
//           <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
//             {/* Salary Forecast Card */}
//             <motion.div
//               initial={{ opacity: 0, y: 20 }}
//               animate={{ opacity: 1, y: 0 }}
//               transition={{ duration: 0.3, delay: 0.1 }}
//               className="bg-white rounded-xl shadow-sm p-6 border border-gray-100"
//             >
//               <div className="flex items-center justify-between">
//                 <div>
//                   <p className="text-sm font-medium text-gray-500">Projected Next Salary</p>
//                   <p className="text-2xl font-bold text-gray-800 mt-1">
//                     {forecastData.salaryForecast ? formatCurrency(forecastData.salaryForecast) : 'Insufficient Data'}
//                   </p>
//                 </div>
//                 <div className="bg-blue-100 p-3 rounded-lg">
//                   <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
//                     <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
//                   </svg>
//                 </div>
//               </div>
//               <div className="mt-4 pt-4 border-t border-gray-100">
//                 <p className="text-xs text-gray-500">
//                   {forecastData.salaryForecast ? (
//                     <>
//                       Based on {forecastData.processedPayrollsCount} payrolls across {forecastData.payrollHistory?.length} months
//                       {forecastData.payrollHistory?.length > 0 && (
//                         <span> • Last: {formatCurrency(forecastData.payrollHistory[forecastData.payrollHistory.length - 1].averageNetSalary)}</span>
//                       )}
//                     </>
//                   ) : (
//                     "Need at least 3 months of payroll data for projection"
//                   )}
//                 </p>
//               </div>
//             </motion.div>

//             {/* Work Days Forecast Card */}
//             <motion.div
//               initial={{ opacity: 0, y: 20 }}
//               animate={{ opacity: 1, y: 0 }}
//               transition={{ duration: 0.3, delay: 0.2 }}
//               className="bg-white rounded-xl shadow-sm p-6 border border-gray-100"
//             >
//               <div className="flex items-center justify-between">
//                 <div>
//                   <p className="text-sm font-medium text-gray-500">Projected Work Days</p>
//                   <p className="text-2xl font-bold text-gray-800 mt-1">
//                     {Math.round(forecastData.projectedWorkDays)} days
//                   </p>
//                 </div>
//                 <div className="bg-green-100 p-3 rounded-lg">
//                   <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
//                     <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
//                   </svg>
//                 </div>
//               </div>
//               <div className="mt-4 pt-4 border-t border-gray-100">
//                 <p className="text-xs text-gray-500">
//                   Avg. {forecastData.avgAttendancePerMonth.toFixed(1)} days/month • {forecastData.monthsRemaining} months remaining
//                 </p>
//               </div>
//             </motion.div>

//             {/* Leaves Forecast Card */}
//             <motion.div
//               initial={{ opacity: 0, y: 20 }}
//               animate={{ opacity: 1, y: 0 }}
//               transition={{ duration: 0.3, delay: 0.3 }}
//               className="bg-white rounded-xl shadow-sm p-6 border border-gray-100"
//             >
//               <div className="flex items-center justify-between">
//                 <div>
//                   <p className="text-sm font-medium text-gray-500">Projected Leaves</p>
//                   <p className="text-2xl font-bold text-gray-800 mt-1">
//                     {forecastData.projectedLeaves} days
//                   </p>
//                 </div>
//                 <div className="bg-yellow-100 p-3 rounded-lg">
//                   <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-yellow-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
//                     <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
//                   </svg>
//                 </div>
//               </div>
//               <div className="mt-4 pt-4 border-t border-gray-100">
//                 <p className="text-xs text-gray-500">
//                   Current rate: {forecastData.leavesPerMonth.toFixed(1)} leaves/month • {forecastData.leaveTypes?.CASUAL || 0}/10 casual leaves used
//                 </p>
//               </div>
//             </motion.div>
//           </div>

//           {/* Salary Trend Section */}
//           <motion.div
//             initial={{ opacity: 0, y: 20 }}
//             animate={{ opacity: 1, y: 0 }}
//             transition={{ duration: 0.5, delay: 0.5 }}
//             className="bg-white rounded-xl shadow-sm p-6 border border-gray-100 mb-6"
//           >
//             <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-4">
//               <h3 className="text-lg font-semibold text-gray-800">Salary Trend Analysis</h3>
//               {forecastData.salaryForecast && (
//                 <div className="mt-2 md:mt-0 bg-blue-50 px-3 py-1 rounded-full text-sm text-blue-700">
//                   Projected Next Salary: {formatCurrency(forecastData.salaryForecast)}
//                 </div>
//               )}
//             </div>
            
//             <div className="h-80">
//               <Line 
//                 data={salaryTrendData}
//                 options={{
//                   responsive: true,
//                   maintainAspectRatio: false,
//                   scales: {
//                     y: {
//                       beginAtZero: false,
//                       ticks: {
//                         callback: function(value) {
//                           return formatCurrency(value);
//                         }
//                       }
//                     }
//                   },
//                   plugins: {
//                     tooltip: {
//                       callbacks: {
//                         label: function(context) {
//                           return `${context.dataset.label}: ${formatCurrency(context.raw)}`;
//                         }
//                       }
//                     },
//                     legend: {
//                       position: 'bottom',
//                       labels: {
//                         boxWidth: 12
//                       }
//                     }
//                   }
//                 }}
//               />
//             </div>
            
//             <div className="mt-4 pt-4 border-t border-gray-100">
//               <h4 className="text-sm font-medium text-gray-800 mb-2">How This Forecast Works</h4>
//               <p className="text-xs text-gray-600">
//                 {forecastData.salaryForecast ? (
//                   <>
//                     The salary projection uses linear regression on your historical net salary data. 
//                     We analyze the trend in your past {forecastData.payrollHistory?.length} months of payroll data to predict the next likely salary amount.
//                     The dashed line shows the projected value based on this trend analysis.
//                   </>
//                 ) : (
//                   "Salary forecasting requires at least 3 months of processed payroll data to establish a reliable trend. Currently you have data for {forecastData.payrollHistory?.length} months."
//                 )}
//               </p>
//             </div>
//           </motion.div>

//           {/* Work Patterns Section */}
//           <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
//             {/* Attendance Patterns */}
//             <motion.div
//               initial={{ opacity: 0, y: 20 }}
//               animate={{ opacity: 1, y: 0 }}
//               transition={{ duration: 0.5, delay: 0.7 }}
//               className="bg-white rounded-xl shadow-sm p-6 border border-gray-100"
//             >
//               <h3 className="text-lg font-semibold text-gray-800 mb-4">Weekly Work Pattern</h3>
//               <div className="h-64">
//                 <Bar 
//                   data={attendancePatternData}
//                   options={{
//                     responsive: true,
//                     maintainAspectRatio: false,
//                     scales: {
//                       y: {
//                         beginAtZero: true,
//                         ticks: {
//                           precision: 0
//                         }
//                       }
//                     },
//                     plugins: {
//                       legend: {
//                         display: false
//                       },
//                       tooltip: {
//                         callbacks: {
//                           label: function(context) {
//                             return `${context.parsed.y} attendance records`;
//                           }
//                         }
//                       }
//                     }
//                   }}
//                 />
//               </div>
//               <p className="text-xs text-gray-500 mt-2">
//                 Shows your typical work days pattern. Higher bars indicate days you're more likely to work.
//               </p>
//             </motion.div>

//             {/* Leave Distribution */}
//             <motion.div
//               initial={{ opacity: 0, y: 20 }}
//               animate={{ opacity: 1, y: 0 }}
//               transition={{ duration: 0.5, delay: 0.9 }}
//               className="bg-white rounded-xl shadow-sm p-6 border border-gray-100"
//             >
//               <h3 className="text-lg font-semibold text-gray-800 mb-4">Leave Usage Breakdown</h3>
//               <div className="h-64">
//                 <Pie 
//                   data={leaveForecastData}
//                   options={{
//                     responsive: true,
//                     maintainAspectRatio: false,
//                     plugins: {
//                       legend: {
//                         position: 'right'
//                       },
//                       tooltip: {
//                         callbacks: {
//                           label: function(context) {
//                             return `${context.label}: ${context.raw} days`;
//                           }
//                         }
//                       }
//                     }
//                   }}
//                 />
//               </div>
//               <div className="mt-4 pt-4 border-t border-gray-100">
//                 <h4 className="text-sm font-medium text-gray-800 mb-2">Leave Balances</h4>
//                 <div className="grid grid-cols-2 gap-4 text-sm">
//                   <div>
//                     <p className="text-gray-500">Casual Leaves</p>
//                     <p className="font-medium">
//                       {10 - (forecastData.leaveTypes?.CASUAL || 0)} remaining (of 10)
//                     </p>
//                   </div>
//                   <div>
//                     <p className="text-gray-500">Sick Leaves</p>
//                     <p className="font-medium">
//                       {10 - (forecastData.leaveTypes?.SICK || 0)} remaining (of 10)
//                     </p>
//                   </div>
//                   <div>
//                     <p className="text-gray-500">Annual Leaves</p>
//                     <p className="font-medium">
//                       {12 - (forecastData.leaveTypes?.ANNUAL || 0)} remaining (of 12)
//                     </p>
//                   </div>
//                   <div>
//                     <p className="text-gray-500">Projected Additional</p>
//                     <p className="font-medium">
//                       {forecastData.projectedLeaves} days
//                     </p>
//                   </div>
//                 </div>
//               </div>
//             </motion.div>
//           </div>

//           {/* Year-End Projections */}
//           <motion.div
//             initial={{ opacity: 0, y: 20 }}
//             animate={{ opacity: 1, y: 0 }}
//             transition={{ duration: 0.5, delay: 1.1 }}
//             className="bg-white rounded-xl shadow-sm p-6 border border-gray-100 mb-6"
//           >
//             <h3 className="text-lg font-semibold text-gray-800 mb-4">Year-End Projections</h3>
//             <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
//               <div className="bg-blue-50 p-4 rounded-lg">
//                 <div className="flex items-center">
//                   <div className="bg-blue-100 p-2 rounded-lg mr-4">
//                     <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
//                       <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
//                     </svg>
//                   </div>
//                   <div>
//                     <h4 className="font-medium text-gray-800">Total Earnings</h4>
//                     <p className="text-sm text-gray-600 mt-1">
//                       {formatCurrency(
//                         forecastData.payrollHistory.reduce((sum, p) => sum + p.averageNetSalary, 0) / 
//                         Math.max(1, forecastData.payrollHistory.length) * 12
//                       )}
//                     </p>
//                   </div>
//                 </div>
//               </div>

//               <div className="bg-green-50 p-4 rounded-lg">
//                 <div className="flex items-center">
//                   <div className="bg-green-100 p-2 rounded-lg mr-4">
//                     <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
//                       <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
//                     </svg>
//                   </div>
//                   <div>
//                     <h4 className="font-medium text-gray-800">Total Work Days</h4>
//                     <p className="text-sm text-gray-600 mt-1">
//                       {Math.round(forecastData.avgAttendancePerMonth * 12)} days
//                     </p>
//                   </div>
//                 </div>
//               </div>

//               <div className="bg-purple-50 p-4 rounded-lg">
//                 <div className="flex items-center">
//                   <div className="bg-purple-100 p-2 rounded-lg mr-4">
//                     <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-purple-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
//                       <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
//                     </svg>
//                   </div>
//                   <div>
//                     <h4 className="font-medium text-gray-800">Total Overtime</h4>
//                     <p className="text-sm text-gray-600 mt-1">
//                       {Math.round(forecastData.avgOvertimePerMonth * 12)} hours
//                     </p>
//                   </div>
//                 </div>
//               </div>
//             </div>
//           </motion.div>

//           {/* Data Quality Note */}
//           <motion.div
//             initial={{ opacity: 0, y: 20 }}
//             animate={{ opacity: 1, y: 0 }}
//             transition={{ duration: 0.5, delay: 1.3 }}
//             className="bg-white rounded-xl shadow-sm p-6 border border-gray-100 mb-6"
//           >
//             <div className="flex items-start">
//               <div className="bg-gray-100 p-2 rounded-lg mr-4">
//                 <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
//                   <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
//                 </svg>
//               </div>
//               <div>
//                 <h4 className="font-medium text-gray-800">About These Forecasts</h4>
//                 <div className="text-sm text-gray-600 mt-1 space-y-2">
//                   <p>
//                     All projections are based on your historical data patterns. Forecasts become more accurate as more data becomes available.
//                   </p>
//                   <ul className="list-disc pl-5 space-y-1">
//                     <li>
//                       <span className="font-medium">Salary Forecast:</span> Uses linear regression on your net salary history (requires ≥3 months data)
//                     </li>
//                     <li>
//                       <span className="font-medium">Work Days:</span> Based on your average monthly attendance
//                     </li>
//                     <li>
//                       <span className="font-medium">Leaves:</span> Projected using your current leave usage rate
//                     </li>
//                     <li>
//                       <span className="font-medium">Overtime:</span> Calculated from your average overtime hours
//                     </li>
//                   </ul>
//                 </div>
//               </div>
//             </div>
//           </motion.div>
//         </div>
//       </div>
//       <Footer />
//     </>
//   );
// };

// export default ForecastingDashboard;




import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import HeaderNavbar from '../component/HeaderNavbar';
import Footer from '../component/Footer';
import { motion } from 'framer-motion';
import { Bar, Line, Pie, Scatter } from 'react-chartjs-2';
import { Chart, registerables } from 'chart.js';
import { LinearScale, PointElement, Tooltip, Legend } from 'chart.js';
import regression from 'regression';
Chart.register(...registerables, LinearScale, PointElement, Tooltip, Legend);

const ForecastingDashboard = () => {
  const [employee, setEmployee] = useState(null);
  const [attendance, setAttendance] = useState([]);
  const [leaves, setLeaves] = useState([]);
  const [payrolls, setPayrolls] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchEmployeeData = async () => {
      try {
        const token = localStorage.getItem('token');
        if (!token) {
          navigate('/login');
          return;
        }

        const config = {
          headers: { Authorization: `Bearer ${token}` }
        };

        // Fetch employee details
        const employeeRes = await axios.get('http://localhost:8080/api/employees/me', config);
        const employeeData = employeeRes.data;
        setEmployee(employeeData);

        // Fetch all data in parallel
        const [attendanceRes, leavesRes, payrollsRes] = await Promise.all([
          axios.get('http://localhost:8080/api/attendance', config),
          axios.get('http://localhost:8080/api/leaves/employee/' + employeeData.id, config),
          axios.get('http://localhost:8080/api/payrolls', config)
        ]);

        // Filter data for current employee
        const filteredAttendance = attendanceRes.data.filter(
          a => a.employee && a.employee.id === employeeData.id
        );
        setAttendance(filteredAttendance);

        setLeaves(leavesRes.data);

        const filteredPayrolls = payrollsRes.data.filter(
          p => p.employeeId === employeeData.id
        ).sort((a, b) => new Date(a.processedAt) - new Date(b.processedAt));
        setPayrolls(filteredPayrolls);

      } catch (err) {
        setError(err.response?.data?.message || 'Failed to fetch data');
        console.error('Error fetching data:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchEmployeeData();
  }, [navigate]);

  // Enhanced forecasting calculations with multiple parameters
  const calculateForecasts = () => {
    if (!employee || payrolls.length === 0) return {};

    // Current date and month calculations
    const currentDate = new Date();
    const currentMonth = currentDate.getMonth();
    const currentYear = currentDate.getFullYear();
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

    // Process payroll data - we'll use processedAt date for timeline
    const processedPayrolls = payrolls.filter(p => p.paymentStatus === 'PROCESSED');
    
    // Group payrolls by month-year and calculate averages
    const monthlyPayrollData = {};
    processedPayrolls.forEach(payroll => {
      const payrollDate = new Date(payroll.processedAt);
      const monthYear = `${payrollDate.getFullYear()}-${payrollDate.getMonth()}`;
      
      if (!monthlyPayrollData[monthYear]) {
        monthlyPayrollData[monthYear] = {
          totalNetSalary: 0,
          totalBasic: 0,
          totalAllowances: 0,
          totalDeductions: 0,
          totalOvertimePay: 0,
          count: 0,
          month: payrollDate.getMonth(),
          year: payrollDate.getFullYear(),
          monthName: months[payrollDate.getMonth()]
        };
      }
      
      monthlyPayrollData[monthYear].totalNetSalary += payroll.netSalary;
      monthlyPayrollData[monthYear].totalBasic += payroll.basicSalary;
      monthlyPayrollData[monthYear].totalAllowances += payroll.allowances;
      monthlyPayrollData[monthYear].totalDeductions += payroll.deductions;
      monthlyPayrollData[monthYear].totalOvertimePay += payroll.overtime;
      monthlyPayrollData[monthYear].count++;
    });

    // Convert to array and calculate averages
    const payrollHistory = Object.values(monthlyPayrollData)
      .map(item => ({
        ...item,
        averageNetSalary: item.totalNetSalary / item.count,
        averageBasic: item.totalBasic / item.count,
        averageAllowances: item.totalAllowances / item.count,
        averageDeductions: item.totalDeductions / item.count,
        averageOvertimePay: item.totalOvertimePay / item.count,
        sequence: (item.year - currentYear) * 12 + item.month - currentMonth
      }))
      .sort((a, b) => a.year - b.year || a.month - b.month);

    // Calculate salary forecast using linear regression if we have enough data
    let salaryForecast = null;
    let salaryTrend = null;
    let forecastConfidence = 0;
    if (payrollHistory.length >= 3) {
      const regressionData = payrollHistory.map((item, index) => [index, item.averageNetSalary]);
      const result = regression.linear(regressionData);
      salaryTrend = result;
      salaryForecast = result.predict(payrollHistory.length)[1];
      forecastConfidence = Math.min(100, Math.max(0, Math.round(result.r2 * 100)));
    }

    // Calculate employment duration in months
    const joinDate = new Date(employee.joinDate);
    const employmentDurationMonths = Math.max(1, 
      (currentYear - joinDate.getFullYear()) * 12 + 
      (currentMonth - joinDate.getMonth())
    );

    // Attendance analysis
    const monthlyAttendance = Array(12).fill(0);
    let totalOvertime = 0;
    let totalWorkHours = 0;
    
    attendance.forEach(record => {
      const date = new Date(record.workDate);
      if (date.getFullYear() === currentYear) {
        monthlyAttendance[date.getMonth()]++;
      }
      totalOvertime += record.overtimeHours || 0;
      totalWorkHours += record.totalHours || 0;
    });

    const avgAttendancePerMonth = monthlyAttendance.reduce((sum, val) => sum + val, 0) / 
      Math.max(1, monthlyAttendance.filter(val => val > 0).length);
    const avgOvertimePerMonth = totalOvertime / Math.max(1, monthlyAttendance.filter(val => val > 0).length);
    const avgWorkHoursPerDay = totalWorkHours / Math.max(1, attendance.length);

    // Leave analysis
    const leaveTypes = {
      CASUAL: 0,
      SICK: 0,
      ANNUAL: 0,
      UNPAID: 0
    };
    
    leaves.forEach(leave => {
      leaveTypes[leave.leaveType]++;
      if (!leave.isPaid) leaveTypes.UNPAID++;
    });

    const leavesPerMonth = leaves.length / employmentDurationMonths;
    const monthsRemaining = 12 - currentMonth;

    // Calculate salary components correlation
    let componentsCorrelation = [];
    if (payrollHistory.length >= 3) {
      componentsCorrelation = [
        {
          component: 'Basic Salary',
          correlation: Math.round(salaryTrend ? 
            regression.linear(payrollHistory.map((item, index) => [index, item.averageBasic])).r2 * 100 : 0
          )
        },
        {
          component: 'Allowances',
          correlation: Math.round(salaryTrend ? 
            regression.linear(payrollHistory.map((item, index) => [index, item.averageAllowances])).r2 * 100 : 0
          )
        },
        {
          component: 'Deductions',
          correlation: Math.round(salaryTrend ? 
            regression.linear(payrollHistory.map((item, index) => [index, item.averageDeductions])).r2 * 100 : 0
          )
        },
        {
          component: 'Overtime Pay',
          correlation: Math.round(salaryTrend ? 
            regression.linear(payrollHistory.map((item, index) => [index, item.averageOvertimePay])).r2 * 100 : 0
          )
        }
      ].sort((a, b) => b.correlation - a.correlation);
    }

    return {
      payrollHistory,
      salaryForecast,
      salaryTrend,
      forecastConfidence,
      monthlyAttendance,
      avgAttendancePerMonth,
      leaveTypes,
      leavesPerMonth,
      totalOvertime,
      avgOvertimePerMonth,
      avgWorkHoursPerDay,
      projectedLeaves: Math.round(leavesPerMonth * monthsRemaining),
      projectedOvertime: Math.round(avgOvertimePerMonth * monthsRemaining),
      projectedWorkDays: Math.round(avgAttendancePerMonth * monthsRemaining),
      monthsRemaining,
      employmentDurationMonths,
      months,
      processedPayrollsCount: processedPayrolls.length,
      componentsCorrelation,
      currentMonth,
      currentYear,
      avgBasic: payrollHistory.length > 0 ? 
        payrollHistory[payrollHistory.length - 1].averageBasic : 0,
      avgAllowances: payrollHistory.length > 0 ? 
        payrollHistory[payrollHistory.length - 1].averageAllowances : 0,
      avgDeductions: payrollHistory.length > 0 ? 
        payrollHistory[payrollHistory.length - 1].averageDeductions : 0,
      avgOvertimePay: payrollHistory.length > 0 ? 
        payrollHistory[payrollHistory.length - 1].averageOvertimePay : 0
    };
  };

  const forecastData = calculateForecasts();

  // Format currency
  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount || 0);
  };

  // Format percentage
  const formatPercentage = (value) => {
    return `${Math.round(value)}%`;
  };

  // Chart data for salary trend with forecast
  const salaryTrendData = {
    labels: [
      ...forecastData.payrollHistory?.map(p => `${p.monthName} ${p.year}`) || [],
      ...(forecastData.salaryForecast ? [`${forecastData.months[forecastData.currentMonth]} ${forecastData.currentYear + (forecastData.currentMonth === 11 ? 1 : 0)} (Projected)`] : [])
    ],
    datasets: [
      {
        label: 'Actual Net Salary',
        data: [
          ...forecastData.payrollHistory?.map(p => p.averageNetSalary) || [],
          ...(forecastData.salaryForecast ? [null] : [])
        ],
        borderColor: 'rgba(54, 162, 235, 1)',
        backgroundColor: 'rgba(54, 162, 235, 0.2)',
        tension: 0.3,
        fill: false,
        pointRadius: 5,
        pointHoverRadius: 7
      },
      ...(forecastData.salaryTrend ? [{
        label: 'Salary Trend Line',
        data: [
          ...forecastData.payrollHistory?.map((_, i) => 
            forecastData.salaryTrend.predict(i)[1]
          ) || [],
          ...(forecastData.salaryForecast ? [forecastData.salaryForecast] : [])
        ],
        borderColor: 'rgba(75, 192, 192, 1)',
        backgroundColor: 'rgba(75, 192, 192, 0.2)',
        borderWidth: 2,
        borderDash: [5, 5],
        pointRadius: 0,
        fill: false
      }] : []),
      ...(forecastData.salaryForecast ? [{
        label: 'Projected Salary',
        data: [
          ...forecastData.payrollHistory?.map(() => null) || [],
          forecastData.salaryForecast
        ],
        borderColor: 'rgba(255, 99, 132, 1)',
        backgroundColor: 'rgba(255, 99, 132, 0.2)',
        pointRadius: 6,
        pointHoverRadius: 8,
        pointStyle: 'rectRot',
        borderWidth: 2
      }] : [])
    ]
  };

  // Chart data for salary components breakdown
  const salaryComponentsData = {
    labels: ['Basic', 'Allowances', 'Deductions', 'Overtime'],
    datasets: [{
      label: 'Salary Components',
      data: [
        forecastData.avgBasic,
        forecastData.avgAllowances,
        forecastData.avgDeductions,
        forecastData.avgOvertimePay
      ],
      backgroundColor: [
        'rgba(54, 162, 235, 0.7)',
        'rgba(75, 192, 192, 0.7)',
        'rgba(255, 99, 132, 0.7)',
        'rgba(255, 159, 64, 0.7)'
      ],
      borderColor: [
        'rgba(54, 162, 235, 1)',
        'rgba(75, 192, 192, 1)',
        'rgba(255, 99, 132, 1)',
        'rgba(255, 159, 64, 1)'
      ],
      borderWidth: 1
    }]
  };

  // Chart data for salary components correlation
  const componentsCorrelationData = {
    labels: forecastData.componentsCorrelation?.map(c => c.component) || [],
    datasets: [{
      label: 'Impact on Salary Trend',
      data: forecastData.componentsCorrelation?.map(c => c.correlation) || [],
      backgroundColor: 'rgba(153, 102, 255, 0.7)',
      borderColor: 'rgba(153, 102, 255, 1)',
      borderWidth: 1
    }]
  };

  // Chart data for work patterns
  const workPatternData = {
    labels: ['Work Days', 'Overtime Hours', 'Leaves'],
    datasets: [{
      label: 'Monthly Averages',
      data: [
        forecastData.avgAttendancePerMonth,
        forecastData.avgOvertimePerMonth,
        forecastData.leavesPerMonth
      ],
      backgroundColor: [
        'rgba(54, 162, 235, 0.7)',
        'rgba(255, 206, 86, 0.7)',
        'rgba(255, 99, 132, 0.7)'
      ],
      borderColor: [
        'rgba(54, 162, 235, 1)',
        'rgba(255, 206, 86, 1)',
        'rgba(255, 99, 132, 1)'
      ],
      borderWidth: 1
    }]
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-xl">Loading forecasting dashboard...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-red-500 text-xl">{error}</div>
      </div>
    );
  }

  if (!employee) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-xl">No employee data found</div>
      </div>
    );
  }

  return (
    <>
      <HeaderNavbar />
      <div className="min-h-[calc(100vh-64px)] bg-[#eaeaea] p-4 md:p-6">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="bg-white rounded-xl shadow-sm p-6 mb-6 border border-gray-100"
          >
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="bg-indigo-100 p-3 rounded-full">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                  </svg>
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-gray-800">
                    Salary Forecasting Dashboard for {employee.firstName} {employee.lastName}
                  </h1>
                  <p className="text-gray-600">
                    Predictive analytics based on your historical payroll data and work patterns
                  </p>
                </div>
              </div>
              <div className="mt-4 md:mt-0 grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-gray-500">Employment Duration</p>
                  <p className="font-medium">{forecastData.employmentDurationMonths} months</p>
                </div>
                <div>
                  <p className="text-gray-500">Payroll Data Points</p>
                  <p className="font-medium">
                    {forecastData.processedPayrollsCount} processed payrolls
                  </p>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Salary Forecast Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="bg-white rounded-xl shadow-sm p-6 border border-gray-100 mb-6"
          >
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-4">
              <h3 className="text-lg font-semibold text-gray-800">Salary Trend & Forecast</h3>
              {forecastData.salaryForecast && (
                <div className="mt-2 md:mt-0 flex items-center">
                  <div className="bg-blue-50 px-3 py-1 rounded-full text-sm text-blue-700 mr-3">
                    Projected Next Salary: {formatCurrency(forecastData.salaryForecast)}
                  </div>
                  <div className="bg-green-50 px-3 py-1 rounded-full text-sm text-green-700">
                    Confidence: {formatPercentage(forecastData.forecastConfidence)}
                  </div>
                </div>
              )}
            </div>
            
            <div className="h-96">
              <Line 
                data={salaryTrendData}
                options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  scales: {
                    y: {
                      beginAtZero: false,
                      ticks: {
                        callback: function(value) {
                          return formatCurrency(value);
                        }
                      }
                    }
                  },
                  plugins: {
                    tooltip: {
                      callbacks: {
                        label: function(context) {
                          return `${context.dataset.label}: ${formatCurrency(context.raw)}`;
                        }
                      }
                    },
                    legend: {
                      position: 'bottom',
                      labels: {
                        boxWidth: 12
                      }
                    },
                    annotation: forecastData.salaryForecast ? {
                      annotations: {
                        line1: {
                          type: 'line',
                          yMin: forecastData.salaryForecast,
                          yMax: forecastData.salaryForecast,
                          borderColor: 'rgba(255, 99, 132, 0.5)',
                          borderWidth: 2,
                          borderDash: [6, 6],
                          label: {
                            content: `Projected: ${formatCurrency(forecastData.salaryForecast)}`,
                            enabled: true,
                            position: 'right'
                          }
                        }
                      }
                    } : {}
                  }
                }}
              />
            </div>
            
            <div className="mt-4 pt-4 border-t border-gray-100">
              <h4 className="text-sm font-medium text-gray-800 mb-2">Forecasting Methodology</h4>
              <p className="text-xs text-gray-600">
                {forecastData.salaryForecast ? (
                  <>
                    The salary projection uses linear regression on your historical net salary data. 
                    We analyze the trend in your past {forecastData.payrollHistory?.length} months of payroll data to predict the next likely salary amount.
                    The trend line shows the mathematical best fit, while the projected point represents the forecasted value for the next period.
                    The confidence score ({formatPercentage(forecastData.forecastConfidence)}) indicates how well the trend line fits your historical data.
                  </>
                ) : (
                  "Salary forecasting requires at least 3 months of processed payroll data to establish a reliable trend. Currently you have data for {forecastData.payrollHistory?.length} months."
                )}
              </p>
            </div>
          </motion.div>

          {/* Salary Components Section */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
            {/* Salary Components Breakdown */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.5 }}
              className="bg-white rounded-xl shadow-sm p-6 border border-gray-100"
            >
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Salary Composition</h3>
              <div className="h-64">
                <Pie 
                  data={salaryComponentsData}
                  options={{
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                      legend: {
                        position: 'right'
                      },
                      tooltip: {
                        callbacks: {
                          label: function(context) {
                            return `${context.label}: ${formatCurrency(context.raw)}`;
                          }
                        }
                      }
                    }
                  }}
                />
              </div>
              <div className="mt-4 pt-4 border-t border-gray-100">
                <h4 className="text-sm font-medium text-gray-800 mb-2">Current Composition</h4>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-gray-500">Basic Salary</p>
                    <p className="font-medium">{formatCurrency(forecastData.avgBasic)}</p>
                  </div>
                  <div>
                    <p className="text-gray-500">Allowances</p>
                    <p className="font-medium">{formatCurrency(forecastData.avgAllowances)}</p>
                  </div>
                  <div>
                    <p className="text-gray-500">Deductions</p>
                    <p className="font-medium">{formatCurrency(forecastData.avgDeductions)}</p>
                  </div>
                  <div>
                    <p className="text-gray-500">Overtime Pay</p>
                    <p className="font-medium">{formatCurrency(forecastData.avgOvertimePay)}</p>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Components Impact on Salary Trend */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.7 }}
              className="bg-white rounded-xl shadow-sm p-6 border border-gray-100"
            >
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Components Impact on Salary Trend</h3>
              <div className="h-64">
                <Bar 
                  data={componentsCorrelationData}
                  options={{
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                      y: {
                        beginAtZero: true,
                        max: 100,
                        ticks: {
                          callback: function(value) {
                            return `${value}%`;
                          }
                        }
                      }
                    },
                    plugins: {
                      legend: {
                        display: false
                      },
                      tooltip: {
                        callbacks: {
                          label: function(context) {
                            return `${context.parsed.y}% correlation`;
                          }
                        }
                      }
                    }
                  }}
                />
              </div>
              <div className="mt-4 pt-4 border-t border-gray-100">
                <h4 className="text-sm font-medium text-gray-800 mb-2">Interpretation</h4>
                <p className="text-xs text-gray-600">
                  This shows how much each salary component contributes to the overall salary trend.
                  Higher percentages indicate components that have been changing in a way that strongly
                  affects your net salary trend. Components with low correlation have remained stable.
                </p>
              </div>
            </motion.div>
          </div>

          {/* Work Patterns Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.9 }}
            className="bg-white rounded-xl shadow-sm p-6 border border-gray-100 mb-6"
          >
            <h3 className="text-lg font-semibold text-gray-800 mb-4">Work Patterns Analysis</h3>
            <div className="h-64">
              <Bar 
                data={workPatternData}
                options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  scales: {
                    y: {
                      beginAtZero: true
                    }
                  },
                  plugins: {
                    legend: {
                      display: false
                    },
                    tooltip: {
                      callbacks: {
                        label: function(context) {
                          return context.dataset.label === 'Monthly Averages' ? 
                            `${context.label}: ${context.parsed.y.toFixed(1)}` : 
                            `${context.label}: ${context.parsed.y}`;
                        }
                      }
                    }
                  }
                }}
              />
            </div>
            <div className="mt-4 pt-4 border-t border-gray-100">
              <h4 className="text-sm font-medium text-gray-800 mb-2">Key Metrics</h4>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-blue-50 p-3 rounded-lg">
                  <p className="text-sm font-medium text-blue-800">Avg. Work Days/Month</p>
                  <p className="text-xl font-bold">{forecastData.avgAttendancePerMonth.toFixed(1)}</p>
                </div>
                <div className="bg-yellow-50 p-3 rounded-lg">
                  <p className="text-sm font-medium text-yellow-800">Avg. Overtime/Month</p>
                  <p className="text-xl font-bold">{forecastData.avgOvertimePerMonth.toFixed(1)} hours</p>
                </div>
                <div className="bg-red-50 p-3 rounded-lg">
                  <p className="text-sm font-medium text-red-800">Avg. Leaves/Month</p>
                  <p className="text-xl font-bold">{forecastData.leavesPerMonth.toFixed(1)}</p>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Forecasting Parameters Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 1.1 }}
            className="bg-white rounded-xl shadow-sm p-6 border border-gray-100 mb-6"
          >
            <h3 className="text-lg font-semibold text-gray-800 mb-4">Forecasting Parameters</h3>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Parameter</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Value</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Impact on Salary</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Projection</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  <tr>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">Basic Salary</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{formatCurrency(forecastData.avgBasic)}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {forecastData.componentsCorrelation?.find(c => c.component === 'Basic Salary')?.correlation || 0}%
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {forecastData.componentsCorrelation?.find(c => c.component === 'Basic Salary')?.correlation > 70 ? 
                        'High impact - likely to continue' : 'Stable - minimal expected change'}
                    </td>
                  </tr>
                  <tr>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">Allowances</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{formatCurrency(forecastData.avgAllowances)}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {forecastData.componentsCorrelation?.find(c => c.component === 'Allowances')?.correlation || 0}%
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {forecastData.componentsCorrelation?.find(c => c.component === 'Allowances')?.correlation > 70 ? 
                        'High impact - likely to continue' : 'Stable - minimal expected change'}
                    </td>
                  </tr>
                  <tr>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">Deductions</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{formatCurrency(forecastData.avgDeductions)}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {forecastData.componentsCorrelation?.find(c => c.component === 'Deductions')?.correlation || 0}%
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {forecastData.componentsCorrelation?.find(c => c.component === 'Deductions')?.correlation > 70 ? 
                        'High impact - likely to continue' : 'Stable - minimal expected change'}
                    </td>
                  </tr>
                  <tr>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">Overtime Pay</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{formatCurrency(forecastData.avgOvertimePay)}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {forecastData.componentsCorrelation?.find(c => c.component === 'Overtime Pay')?.correlation || 0}%
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {forecastData.componentsCorrelation?.find(c => c.component === 'Overtime Pay')?.correlation > 70 ? 
                        'High impact - likely to continue' : 'Stable - minimal expected change'}
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </motion.div>

          {/* Data Quality Note */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 1.3 }}
            className="bg-white rounded-xl shadow-sm p-6 border border-gray-100 mb-6"
          >
            <div className="flex items-start">
              <div className="bg-gray-100 p-2 rounded-lg mr-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <div>
                <h4 className="font-medium text-gray-800">Forecasting Methodology & Limitations</h4>
                <div className="text-sm text-gray-600 mt-1 space-y-2">
                  <p>
                    This dashboard uses statistical methods to analyze your payroll history and predict future trends.
                    All projections are based solely on your historical data patterns.
                  </p>
                  <ul className="list-disc pl-5 space-y-1">
                    <li>
                      <span className="font-medium">Linear Regression:</span> Used for salary forecasting, this method finds the best-fit line through your historical salary data points
                    </li>
                    <li>
                      <span className="font-medium">R² (R-squared):</span> Measures how well the trend line fits your data (0-100%). Higher values mean more reliable forecasts
                    </li>
                    <li>
                      <span className="font-medium">Component Analysis:</span> Examines how each salary part (basic, allowances, etc.) contributes to overall trends
                    </li>
                    <li>
                      <span className="font-medium">Limitations:</span> Forecasts assume current trends continue. They don't account for raises, policy changes, or irregular events
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
      <Footer />
    </>
  );
};

export default ForecastingDashboard;
