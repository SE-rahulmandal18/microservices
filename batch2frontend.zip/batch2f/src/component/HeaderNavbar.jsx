// import React, { useState } from "react";
// import { Link, useLocation, useNavigate } from "react-router-dom";
// import { IoIosMenu } from "react-icons/io";
// import { RxCross2 } from "react-icons/rx";

// const HeaderNavbar = () => {
//   const role = localStorage.getItem("role");
//   const username = localStorage.getItem("username");
//   const navigate = useNavigate();
//   const path = useLocation().pathname;
//   const [menuOpen, setMenuOpen] = useState(false);

//   const handleLogout = () => {
//     localStorage.clear();
//     navigate("/login");
//   };

//   const toggleMenu = () => setMenuOpen(!menuOpen);

//   const renderLinks = () => {
//     if (!role) {
//       return (
//         <>
//           <li><Link to="/login" onClick={toggleMenu} className="hover:text-gray-300">Login</Link></li>
//           <li><Link to="/about" onClick={toggleMenu} className="hover:text-gray-300">About</Link></li>
//           <li><Link to="/register" onClick={toggleMenu} className="hover:text-gray-300">Sign Up</Link></li>
//         </>
//       );
//     }

//     switch (role) {
//       case "ADMIN":
//         return (
//           <>
//             <li><Link to="/employee-management" onClick={toggleMenu}>Employees</Link></li>
//             <li><Link to="/transaction-status" onClick={toggleMenu}>Transactions</Link></li>
//             <li><Link to="/reports" onClick={toggleMenu}>Reports</Link></li>
//             <li><Link to="/audit-logs" onClick={toggleMenu}>Logs</Link></li>
//           </>
//         );
//       case "HR":
//         return (
//           <>
//             <li><Link to="/employee-management" onClick={toggleMenu}>Employees</Link></li>
//             <li><Link to="/payroll" onClick={toggleMenu}>Payroll</Link></li>
//             <li><Link to="/payslips" onClick={toggleMenu}>Payslips</Link></li>
//             <li><Link to="/reports" onClick={toggleMenu}>Reports</Link></li>
//             <li><Link to="/leave-records" onClick={toggleMenu}>Leave Records</Link></li>
//           </>
//         );
//       case "EMPLOYEE":
//         return (
//           <>
//             <li><Link to="/payslips" onClick={toggleMenu}>My Payslips</Link></li>
//             <li><Link to="/attendance-management" onClick={toggleMenu}>My Attendance</Link></li>
//             <li><Link to="/leave-management" onClick={toggleMenu}>My Leaves</Link></li>
//             <li><Link to="/profile" onClick={toggleMenu}>My Profile</Link></li>
//           </>
//         );
//       default:
//         return null;
//     }
//   };

//   return (
//     <header className="fixed top-0 left-0 w-full bg-indigo-600 text-white z-50 shadow">
//       <div className="flex justify-between items-center px-4 py-3">
//         <Link to="/" className="text-xl font-bold italic">
//           Payroll Management System
//         </Link>
//         <button onClick={toggleMenu} className="text-3xl focus:outline-none">
//           {menuOpen ? <RxCross2 /> : <IoIosMenu />}
//         </button>
//       </div>

//       {/* Dropdown aligned to top right corner */}
//       {menuOpen && (
//         <div className="absolute right-4 top-16 w-72 bg-indigo-700 rounded-md shadow-lg px-6 py-4">
//           <ul className="flex flex-col space-y-3 text-white font-medium">
//             {renderLinks()}
//           </ul>

//           {role && (
//             <div className="mt-4 border-t border-indigo-500 pt-3 flex flex-col space-y-2">
//               <span className="text-sm">
//                 Logged in as: <strong>{username}</strong> ({role})
//               </span>
//               <button
//                 onClick={() => {
//                   handleLogout();
//                   toggleMenu();
//                 }}
//                 className="bg-red-500 hover:bg-red-600 text-white px-4 py-1 rounded"
//               >
//                 Logout
//               </button>
//             </div>
//           )}
//         </div>
//       )}
//     </header>
//   );
// };

// export default HeaderNavbar;


// import React, { useState } from "react";
// import { Link, useLocation, useNavigate } from "react-router-dom";
// import { IoIosMenu } from "react-icons/io";
// import { RxCross2 } from "react-icons/rx";

// const HeaderNavbar = () => {
//   const role = localStorage.getItem("role");
//   const username = localStorage.getItem("username");
//   const navigate = useNavigate();
//   const path = useLocation().pathname;
//   const [menuOpen, setMenuOpen] = useState(false);

//   const handleLogout = () => {
//     localStorage.clear();
//     navigate("/login");
//   };

//   const toggleMenu = () => setMenuOpen(!menuOpen);

//   const renderLinks = () => {
//     if (!role) {
//       return (
//         <>
//           <li><Link to="/login" onClick={toggleMenu} className="hover:text-gray-300">Login</Link></li>
//           <li><Link to="/about" onClick={toggleMenu} className="hover:text-gray-300">About</Link></li>
//           <li><Link to="/register" onClick={toggleMenu} className="hover:text-gray-300">Sign Up</Link></li>
//         </>
//       );
//     }

//     switch (role) {
//       case "ADMIN":
//         return (
//           <>
//             <li><Link to="/employee-management" onClick={toggleMenu}>Employees</Link></li>
//             <li><Link to="/transaction-status" onClick={toggleMenu}>Transactions</Link></li>
//             {/* <li><Link to="/reports" onClick={toggleMenu}>Reports</Link></li> */}
//             <li><Link to="/audit-logs" onClick={toggleMenu}>Logs</Link></li>
//             <li><Link to="/employee-analytics" onClick={toggleMenu}>My Dashboard</Link></li>
//             <li><Link to="/admin-dashboard" onClick={toggleMenu}>Admin Dashboard</Link></li>


//           </>
//         );
//       case "HR":
//         return (
//           <>
//             <li><Link to="/employee-management" onClick={toggleMenu}>Employees</Link></li>
//             <li><Link to="/payroll" onClick={toggleMenu}>Payroll</Link></li>
//             <li><Link to="/payslips" onClick={toggleMenu}>Payslips</Link></li>
//             {/* <li><Link to="/reports" onClick={toggleMenu}>Reports</Link></li> */}
//             <li><Link to="/leave-records" onClick={toggleMenu}>Leave Records</Link></li>
//             <li><Link to="/employee-analytics" onClick={toggleMenu}>My Dashboard</Link></li>
//             <li><Link to="/hr-dashboard" onClick={toggleMenu}>HR Dashboard</Link></li>
//           </>
//         );
//       case "EMPLOYEE":
//         return (
//           <>
//             <li><Link to="/payslips" onClick={toggleMenu}>My Payslips</Link></li>
//             <li><Link to="/attendance-management" onClick={toggleMenu}>My Attendance</Link></li>
//             <li><Link to="/leave-management" onClick={toggleMenu}>My Leaves</Link></li>
//             <li><Link to="/profile" onClick={toggleMenu}>My Profile</Link></li>
//             <li><Link to="/employee-analytics" onClick={toggleMenu}>My Dashboard</Link></li>
//             <li><Link to="/forecast" onClick={toggleMenu}>My Forecast Hub</Link></li>



//           </>
//         );
//       default:
//         return null;
//     }
//   };

//   return (
//     <header className="fixed top-0 left-0 w-full bg-indigo-600 text-white z-50 shadow">
//       <div className="flex justify-between items-center px-4 py-3">
//         <Link to="/" className="text-xl font-bold italic">
//           Payroll Management System
//         </Link>
//         <button onClick={toggleMenu} className="text-3xl focus:outline-none">
//           {menuOpen ? <RxCross2 /> : <IoIosMenu />}
//         </button>
//       </div>

//       {/* Dropdown aligned to top right corner */}
//       {menuOpen && (
//         <div className="absolute right-4 top-16 w-72 bg-indigo-700 rounded-md shadow-lg px-6 py-4">
//           <ul className="flex flex-col space-y-3 text-white font-medium">
//             {renderLinks()}
//           </ul>

//           {role && (
//             <div className="mt-4 border-t border-indigo-500 pt-3 flex flex-col space-y-2">
//               <span className="text-sm">
//                 Logged in as: <strong>{username}</strong> ({role})
//               </span>
//               <button
//                 onClick={() => {
//                   handleLogout();
//                   toggleMenu();
//                 }}
//                 className="bg-red-500 hover:bg-red-600 text-white px-4 py-1 rounded"
//               >
//                 Logout
//               </button>
//             </div>
//           )}
//         </div>
//       )}
//     </header>
//   );
// };

// export default HeaderNavbar;


import React, { useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { IoIosMenu } from "react-icons/io";
import { RxCross2 } from "react-icons/rx";

const HeaderNavbar = () => {
  const role = localStorage.getItem("role");
  const username = localStorage.getItem("username");
  const navigate = useNavigate();
  const path = useLocation().pathname;
  const [menuOpen, setMenuOpen] = useState(false);

  const handleLogout = () => {
    localStorage.clear();
    navigate("/login");
  };

  const toggleMenu = () => setMenuOpen(!menuOpen);

  const renderLinks = () => {
    if (!role) {
      return (
        <>
          <li><Link to="/login" onClick={toggleMenu} className="hover:text-[#d1dbe4]">Login</Link></li>
          <li><Link to="/about" onClick={toggleMenu} className="hover:text-[#d1dbe4]">About</Link></li>
          <li><Link to="/register" onClick={toggleMenu} className="hover:text-[#d1dbe4]">Sign Up</Link></li>
        </>
      );
    }

    switch (role) {
      case "ADMIN":
        return (
          <>
            <li><Link to="/employee-management" onClick={toggleMenu}>Employees</Link></li>
            <li><Link to="/transaction-status" onClick={toggleMenu}>Transactions</Link></li>
            {/* <li><Link to="/reports" onClick={toggleMenu}>Reports</Link></li> */}
            
            <li><Link to="/audit-logs" onClick={toggleMenu}>Logs</Link></li>
            <li><Link to="/admin-dashboard" onClick={toggleMenu}>Admin Dashboard</Link></li>
          </>
        );
      case "HR":
        return (
          <>
            <li><Link to="/employee-management" onClick={toggleMenu}>Employees</Link></li>
            <li><Link to="/payroll" onClick={toggleMenu}>Payroll</Link></li>
            <li><Link to="/payslips" onClick={toggleMenu}>Payslips</Link></li>
            {/* <li><Link to="/reports" onClick={toggleMenu}>Reports</Link></li> */}
            {/* <li><Link to="/leave-records" onClick={toggleMenu}>Leave Records</Link></li> */}
            <li><Link to="/hr-dashboard" onClick={toggleMenu}>HR Dashboard</Link></li>
            <li><Link to="/bonus-management" onClick={toggleMenu}>Appraisal</Link></li>
            {/* <li><Link to="/payroll-calendar" onClick={toggleMenu}>Payroll Calendar</Link></li> */}
          </>
        );
      case "EMPLOYEE":
        return (
          <>
            <li><Link to="/payslips" onClick={toggleMenu}>My Payslips</Link></li>
            <li><Link to="/attendance-management" onClick={toggleMenu}>My Attendance</Link></li>
            <li><Link to="/leave-management" onClick={toggleMenu}>My Leaves</Link></li>
            <li><Link to="/profile" onClick={toggleMenu}>My Profile</Link></li>
            <li><Link to="/employee-analytics" onClick={toggleMenu}>My Dashboard</Link></li>
            <li><Link to="/forecast" onClick={toggleMenu}>My Forecast Hub</Link></li>
          </>
        );
      default:
        return null;
    }
  };

  return (

    <header className="fixed top-0 left-0 w-full bg-gradient-to-r from-[#1f3b57] via-[#476b8c] to-[#1c2e44] text-white z-50 shadow-md">

      <div className="flex justify-between items-center px-6 py-4">
        {/* <Link to="/" className="flex flex-col leading-tight items-start justify-center">
  <span className="text-3xl font-extrabold font-serif tracking-wide">Trust</span>
  <span className="text-xl font-light font-mono tracking-widest text-[#d1dbe4]">PAY</span>
</Link> */}
<Link to="/" className="flex items-center space-x-3">
  {/* Image Logo */}
  <img src="/logo.jpg" alt="Logo" className="w-10 h-10 object-contain rounded-full" />

  {/* Trust Pay Text */}
  <div className="flex flex-col leading-tight items-start justify-center">
    <span className="text-3xl font-extrabold font-serif tracking-wide">Paynexis</span>
    {/* <span className="text-xl font-light font-mono tracking-widest text-[#d1dbe4]">Pay</span> */}
  </div>
</Link>


        <button onClick={toggleMenu} className="text-3xl focus:outline-none hover:text-[#d1dbe4]">
          {menuOpen ? <RxCross2 /> : <IoIosMenu />}
        </button>
      </div>

      {menuOpen && (
        <div className="absolute right-4 top-20 w-72 bg-[#476f95] rounded-xl shadow-xl px-6 py-4 border border-[#7593af]">
          <ul className="flex flex-col space-y-4 text-white font-medium">
            {renderLinks()}
          </ul>

          {role && (
            <div className="mt-6 border-t border-[#7593af] pt-3 text-sm text-[#d1dbe4]">
              <p className="mb-2">
                Logged in as: <strong className="text-white">{username}</strong> ({role})
              </p>
              <button
                onClick={() => {
                  handleLogout();
                  toggleMenu();
                }}
                className="bg-gradient-to-r from-[#c9b49a] via-[#d7c4a3] to-[#f0e1cd] hover:bg-red-600 text-white px-4 py-2 rounded-md transition"
              >
                Logout
              </button>
            </div>
          )}
        </div>
      )}
    </header>
  );
};

export default HeaderNavbar;
