import React from "react";
import { FaFacebook, FaTwitter, FaInstagram, FaLinkedin } from "react-icons/fa";

const Footer = () => {
  return (
    <footer className="w-full bg-gray-200 text-gray-800 py-4">
      <div className="container mx-auto flex flex-col items-center justify-between gap-4 px-6 lg:px-14 lg:flex-row">
        <div className="text-center lg:text-left">
          <h2 className="mb-2 text-2xl font-bold">360° Payroll</h2>
          <p className="text-sm">
            A payroll system that does more than just processing salaries.
          </p>
        </div>

        <p className="mt-4 lg:mt-0 text-sm">
          &copy; 2025 Payroll. All rights reserved.
        </p>

        <div className="flex space-x-6 mt-4 lg:mt-0">
          <a href="#" className="hover:text-blue-600">
            <FaFacebook size={20} />
          </a>
          <a href="#" className="hover:text-blue-400">
            <FaTwitter size={20} />
          </a>
          <a href="#" className="hover:text-pink-500">
            <FaInstagram size={20} />
          </a>
          <a href="#" className="hover:text-blue-700">
            <FaLinkedin size={20} />
          </a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
