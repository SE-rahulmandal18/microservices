// import React from "react";
// import { FaLink, FaShareAlt, FaEdit, FaChartLine } from "react-icons/fa";
// import { motion } from "framer-motion";
// import HeaderNavbar from "../component/HeaderNavbar";
// import Footer from "../component/Footer";

// const AboutPage = () => {
//     return (
//         <div className="lg:px-14 sm:px-8 px-5 min-h-[calc(100vh-64px)] pt-6">
//             <HeaderNavbar />

//             <div className="lg:px-14 sm:px-8 px-5 py-6 flex-grow">
//                 <div className="w-full py-8 bg-white sm:py-10">
//                     <motion.h1
//                         className="mb-3 text-3xl italic font-bold sm:text-4xl text-slate-800"
//                         initial={{ opacity: 0 }}
//                         animate={{ opacity: 1 }}
//                         transition={{ duration: 1 }}
//                     >
//                         About Payroll
//                     </motion.h1>

//                     <motion.p
//                         className="text-gray-700 text-sm mb-8 xl:w-[60%] lg:w-[70%] sm:w-[80%] w-full"
//                         initial={{ opacity: 0 }}
//                         animate={{ opacity: 1 }}
//                         transition={{ duration: 1, delay: 0.2 }}
//                     >
//                         Payroll is a comprehensive payroll management solution that simplifies salary processing, tax calculations, and employee management. It ensures compliance with regulations while automating tedious payroll tasks. Businesses can efficiently manage salaries, deductions, benefits, and reports in one unified platform.
//                     </motion.p>

//                     <div className="space-y-5 xl:w-[60%] lg:w-[70%] sm:w-[80%] w-full">
//                         <motion.div
//                             className="flex items-start"
//                             initial={{ opacity: 0, x: -50 }}
//                             animate={{ opacity: 1, x: 0 }}
//                             transition={{ duration: 0.75 }}
//                         >
//                             <FaLink className="mr-4 text-3xl text-blue-500" />
//                             <div>
//                                 <h2 className="font-bold sm:text-2xl text-slate-800">
//                                     Seamless Payroll Processing
//                                 </h2>
//                                 <p className="text-gray-600">
//                                     Automate payroll calculations, tax deductions, and direct deposits with precision. Reduce manual errors and ensure employees are paid accurately and on time.
//                                 </p>
//                             </div>
//                         </motion.div>

//                         <motion.div
//                             className="flex items-start"
//                             initial={{ opacity: 0, x: -50 }}
//                             animate={{ opacity: 1, x: 0 }}
//                             transition={{ duration: 0.75, delay: 0.2 }}
//                         >
//                             <FaShareAlt className="mr-4 text-3xl text-green-500" />
//                             <div>
//                                 <h2 className="font-bold sm:text-2xl text-slate-800">
//                                     Comprehensive Employee Management
//                                 </h2>
//                                 <p className="text-gray-600">
//                                     Maintain employee records, track attendance, manage salary structures, and oversee benefits—all from a centralized dashboard for hassle-free HR operations.
//                                 </p>
//                             </div>
//                         </motion.div>

//                         <motion.div
//                             className="flex items-start"
//                             initial={{ opacity: 0, x: -50 }}
//                             animate={{ opacity: 1, x: 0 }}
//                             transition={{ duration: 0.75, delay: 0.4 }}
//                         >
//                             <FaEdit className="mr-4 text-3xl text-purple-500" />
//                             <div>
//                                 <h2 className="font-bold sm:text-2xl text-slate-800">
//                                     Tax Compliance & Financial Insights
//                                 </h2>
//                                 <p className="text-gray-600">
//                                     Stay compliant with automated tax calculations and generate payroll reports with ease. Simplify audits, tax filings, and financial planning for your organization.
//                                 </p>
//                             </div>
//                         </motion.div>

//                         <motion.div
//                             className="flex items-start"
//                             initial={{ opacity: 0, x: -50 }}
//                             animate={{ opacity: 1, x: 0 }}
//                             transition={{ duration: 0.75, delay: 0.6 }}
//                         >
//                             <FaChartLine className="mr-4 text-3xl text-red-500" />
//                             <div>
//                                 <h2 className="font-bold sm:text-2xl text-slate-800">
//                                     Secure & Reliable System
//                                 </h2>
//                                 <p className="text-gray-600">
//                                     Protect sensitive payroll data with advanced encryption and role-based access control. Our platform ensures your payroll information is secure, reliable, and always available.
//                                 </p>
//                             </div>
//                         </motion.div>
//                     </div>
//                 </div>
//             </div>

//             <Footer className="mt-auto" />
//         </div>
//     );
// };

// export default AboutPage;



import React from "react";
import { FaLink, FaShareAlt, FaEdit, FaChartLine } from "react-icons/fa";
import { motion } from "framer-motion";
import HeaderNavbar from "../component/HeaderNavbar";
import Footer from "../component/Footer";

const AboutPage = () => {
    return (
        <div className="flex flex-col min-h-screen bg-[#eaeaea] text-white">
            <HeaderNavbar />

            <div className="px-5 sm:px-8 lg:px-14 py-6 flex-grow">
                <div className="w-full py-8 sm:py-10 flex flex-col items-center text-center">
                    <motion.h1
                        className="font-bold text-3xl sm:text-4xl drop-shadow-sm bg-gradient-to-br from-[#1f3b57] via-[#476b8c] to-[#1c2e44] bg-clip-text text-transparent"
                        initial={{ opacity: 0, y: -20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 1 }}
                    >
                        About Payroll
                    </motion.h1>

                    <motion.p
                        className="mt-4 text-gray-700 text-lg max-w-3xl"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ duration: 1, delay: 0.2 }}
                    >
                        Payroll is a comprehensive payroll management solution that simplifies salary processing, tax calculations, and employee management. It ensures compliance with regulations while automating tedious payroll tasks. Businesses can efficiently manage salaries, deductions, benefits, and reports in one unified platform.
                    </motion.p>
                </div>

                {/* Feature cards, now centered with even padding on left and right */}
                <div className="space-y-10 max-w-4xl mx-auto">
                    {[
                        {
                            icon: <FaLink className="mr-4 text-4xl text-amber-300 drop-shadow-lg" />,
                            title: "Effortless Payroll Processing",
                            description: "Automate payroll calculations, tax deductions, and direct deposits with precision. Reduce manual errors and ensure employees are paid accurately and on time."
                        },
                        {
                            icon: <FaShareAlt className="mr-4 text-4xl text-cyan-300 drop-shadow-lg" />,
                            title: "Personalize Salary Components",
                            description: "Accommodate diverse salary structures that suit each employee and your organization hierarchy with custom earnings, and deductions."
                        },
                        {
                            icon: <FaEdit className="mr-4 text-4xl text-rose-300 drop-shadow-lg" />,
                            title: "Secure Payroll with Multi-Level Approvals",
                            description: "Ensure every pay run passes through the right hands with multi-level approvals, keeping your process completely reliable."
                        },
                        {
                            icon: <FaChartLine className="mr-4 text-4xl text-emerald-300 drop-shadow-lg" />,
                            title: "Effortless Scalability",
                            description: "From budding start-ups to established large businesses, we help simplify your payroll."
                        },
                        {
                            icon: <FaChartLine className="mr-4 text-4xl text-indigo-300 drop-shadow-lg" />,
                            title: "Payroll Made Easy, Scalable, and Compliant",
                            description: "Stay compliant with automated tax calculations and generate payroll reports with ease. Simplify audits, tax filings, and financial planning for your organization."
                        }
                    ].map((item, index) => (
                        <motion.div
                            key={index}
                            className="flex items-start bg-gradient-to-r from-[#1f3b57] via-[#476b8c] to-[#1c2e44] border border-[#476f95] p-5 rounded-xl shadow-lg hover:from-[#243c5f] hover:via-[#5272a2] hover:to-[#243551] transition-colors duration-300"
                            initial={{ opacity: 0, x: -50 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ duration: 0.75, delay: index * 0.2 }}
                        >
                            {item.icon}
                            <div>
                                <h2 className="font-bold sm:text-2xl text-white mb-1 drop-shadow-sm">
                                    {item.title}
                                </h2>
                                <p className="text-[#d1dbe4]">
                                    {item.description}
                                </p>
                            </div>
                        </motion.div>
                    ))}
                </div>
            </div>

            <div className="w-full mt-auto">
                <Footer />
            </div>
        </div>
    );
};

export default AboutPage;
