import React, { useEffect, useState } from "react";
import axios from "axios";
import { confirmAlert } from 'react-confirm-alert';
import 'react-confirm-alert/src/react-confirm-alert.css';
import { toast } from 'react-toastify';
import HeaderNavbar from "../component/HeaderNavbar";

const PayrollProcessing = () => {
  const [payrolls, setPayrolls] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [currentPayroll, setCurrentPayroll] = useState({
    employeeId: "",
    basicSalary: "",
    allowances: "",
    overtime: "",
    bonuses: "",
    deductions: "",
    lopDays: "",
    netSalary: "",
    paymentStatus: "PENDING",
  });

  const token = localStorage.getItem("token");

  const fetchPayrolls = async () => {
    const res = await axios.get("http://localhost:8080/api/payrolls", {
      headers: { Authorization: `Bearer ${token}` },
    });
    setPayrolls(res.data);
  };

  const fetchEmployees = async () => {
    const res = await axios.get("http://localhost:8080/api/employees", {
      headers: { Authorization: `Bearer ${token}` },
    });
    setEmployees(res.data);
  };

  useEffect(() => {
    fetchPayrolls();
    fetchEmployees();
  }, []);

  const handleShowModal = (payroll = null) => {
    setEditMode(!!payroll);
    if (payroll) {
      setCurrentPayroll({ ...payroll, employeeId: payroll.employeeId });
    } else {
      setCurrentPayroll({
        employeeId: "",
        basicSalary: "",
        allowances: "",
        overtime: "",
        bonuses: "",
        deductions: "",
        lopDays: "",
        netSalary: "",
        paymentStatus: "PENDING",
      });
    }
    setShowModal(true);
  };

  const handleCloseModal = () => setShowModal(false);

  const handleChange = (e) => {
    setCurrentPayroll({ ...currentPayroll, [e.target.name]: e.target.value });
  };

  const handleSubmit = async () => {
    try {
      const config = { headers: { Authorization: `Bearer ${token}` } };

      if (editMode) {
        await axios.patch(
          `http://localhost:8080/api/payrolls/${currentPayroll.id}`,
          currentPayroll,
          config
        );
      } else {
        await axios.post(
          "http://localhost:8080/api/payrolls",
          currentPayroll,
          config
        );
      }
      toast.success("Payroll saved successfully!", {
        position: "top-center",
        autoClose: 3000,      // 3 seconds
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        theme: "colored",     // colored | dark | light
      });
      fetchPayrolls();
      handleCloseModal();
    }  catch (err) {
      const errorMessage =
        err.response?.data?.message || "Failed to save payroll. Please try again.";
        toast.error(errorMessage, {
          position: "top-center",
          autoClose: 5000,       // 5 seconds
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          theme: "colored",
        });
    }
  };

  const handleDelete = async (id) => {
    confirmAlert({
          title: 'Confirm Deletion',
          message: 'Are you sure you want to delete this payroll?',
          buttons: [
            {
              label: 'Yes',
              onClick: async () => {
                try {
                  const token = localStorage.getItem("token");
                  await axios.delete(`http://localhost:8080/api/payrolls/${id}`, {
                    headers: { Authorization: `Bearer ${token}` },
                  });
                  fetchPayrolls();
                  toast.success("Payroll deleted successfully.", { position: "top-center" });
                  } catch (error) {
                    console.error("Failed to delete payroll:", error);
                    toast.error("Error deleting payroll.", { position: "top-center" });
                  }
                }
              },
            {
              label: 'No'
            }
          ]
      });
    };

  // return (
  //   <>
  //   <HeaderNavbar />
  //   <div className="p-6 max-w-7xl mx-auto">
  //     <h2 className="text-2xl font-bold mb-4">Payroll Processing</h2>
  //     <button
  //       onClick={() => handleShowModal()}
  //       className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 mb-4"
  //     >
  //       ➕ Add Payroll
  //     </button>

  //     <div className="overflow-auto">
  //     <table className="w-full border-collapse border border-gray-300">
  //       <thead className="bg-gray-100 text-sm text-left">
  //         <tr>
  //           <th className="p-2 border">#</th>
  //           <th className="p-2 border">Employee Name</th>
  //           <th className="p-2 border">Employee ID</th>
  //           <th className="p-2 border">Basic Salary</th>
  //           <th className="p-2 border">Allowances</th>
  //           <th className="p-2 border">Overtime</th>
  //           <th className="p-2 border">Bonuses</th>
  //           <th className="p-2 border">Deductions</th>
  //           <th className="p-2 border">LOP Days</th>
  //           <th className="p-2 border">LOP Deduction</th>
  //           <th className="p-2 border">Net Salary</th>
  //           <th className="p-2 border">Status</th>
  //           <th className="p-2 border">Processed At</th>
  //           <th className="p-2 border">Actions</th>
  //         </tr>
  //       </thead>
  //       <tbody>
  //         {payrolls.map((p) => (
  //           <tr key={p.id} className="text-center border-t">
  //             <td className="p-2 border">{p.id}</td>
  //             <td className="p-2 border">{p.employeeName}</td>
  //             <td className="p-2 border">{p.employeeId}</td>
  //             <td className="p-2 border">${p.basicSalary}</td>
  //             <td className="p-2 border">${p.allowances}</td>
  //             <td className="p-2 border">{p.overtime}</td>
  //             <td className="p-2 border">${p.bonuses}</td>
  //             <td className="p-2 border">${p.deductions}</td>
  //             <td className="p-2 border">{p.lopDays}</td>
  //             <td className="p-2 border">{p.lopDeduction}</td>
  //             <td className="p-2 font-semibold border">${p.netSalary}</td>
  //             <td className="p-2 border">
  //               <span
  //                 className={`px-2 py-1 rounded text-sm ${
  //                   p.paymentStatus === "PROCESSED"
  //                     ? "bg-green-200 text-green-700"
  //                     : p.paymentStatus === "FAILED"
  //                     ? "bg-red-200 text-red-700"
  //                     : "bg-yellow-200 text-yellow-700"
  //                 }`}
  //               >
  //                 {p.paymentStatus}
  //               </span>
  //             </td>
  //             <td className="p-2 border">
  //               {p.processedAt ? new Date(p.processedAt).toLocaleString() : "-"}
  //             </td>
  //             <td className="p-2 border">
  //           <div className="flex justify-center gap-2">
  //             <button
  //               className="px-3 py-1 rounded hover:bg-yellow-200"
  //               onClick={() => handleShowModal(p)}
  //             >
  //             ✏️ Edit
  //             </button>
  //             <button
  //               className="px-3 py-1 rounded hover:bg-red-200"
  //               onClick={() => handleDelete(p.id)}
  //             >
  //             🗑️ Delete
  //             </button>
  //           </div>
  //         </td>

  //           </tr>
  //         ))}
  //       </tbody>
  //     </table>
  //     </div>
  //     {showModal && (
  //       <div className="fixed inset-0 z-50 backdrop-blur-sm bg-white/10 flex items-center justify-center">
  //         <div className="bg-white w-full max-w-xl p-6 rounded shadow-lg">
  //           <h3 className="text-xl font-semibold mb-4">
  //             {editMode ? "Edit Payroll" : "Add Payroll"}
  //           </h3>
  //           <div className="grid grid-cols-2 gap-4">
  //             <div>
  //               <label className="block text-sm">Employee</label>
  //               <select
  //                 name="employeeId"
  //                 className="w-full border rounded p-1"
  //                 value={currentPayroll.employeeId}
  //                 onChange={handleChange}
  //               >
  //                 <option value="">Select Employee</option>
  //                 {employees.map((emp) => (
  //                   <option key={emp.id} value={emp.id}>
  //                     {emp.firstName} {emp.lastName}
  //                   </option>
  //                 ))}
  //               </select>
  //             </div>
  //             <div>
  //               <label className="block text-sm">Basic Salary</label>
  //               <input
  //                 type="number"
  //                 name="basicSalary"
  //                 className="w-full border rounded p-1"
  //                 value={currentPayroll.basicSalary}
  //                 onChange={handleChange}
  //               />
  //             </div>
  //             <div>
  //               <label className="block text-sm">Allowances</label>
  //               <input
  //                 type="number"
  //                 name="allowances"
  //                 className="w-full border rounded p-1"
  //                 value={currentPayroll.allowances}
  //                 onChange={handleChange}
  //               />
  //             </div>
  //             <div>
  //               <label className="block text-sm">Bonuses</label>
  //               <input
  //                 type="number"
  //                 name="bonuses"
  //                 className="w-full border rounded p-1"
  //                 value={currentPayroll.bonuses}
  //                 onChange={handleChange}
  //               />
  //             </div>
  //             <div>
  //               <label className="block text-sm">Deductions</label>
  //               <input
  //                 type="number"
  //                 name="deductions"
  //                 className="w-full border rounded p-1"
  //                 value={currentPayroll.deductions}
  //                 onChange={handleChange}
  //               />
  //             </div>
  //             <div>
  //               <label className="block text-sm">Payment Status</label>
  //               <select
  //                 name="paymentStatus"
  //                 className="w-full border rounded p-1"
  //                 value={currentPayroll.paymentStatus}
  //                 onChange={handleChange}
  //               >
  //                 <option value="PENDING">Pending</option>
  //                 <option value="PROCESSED">Processed</option>
  //                 <option value="FAILED">Failed</option>
  //               </select>
  //             </div>
  //           </div>
  //           <div className="mt-6 flex justify-end gap-2">
  //             <button
  //               onClick={handleCloseModal}
  //               className="px-4 py-2 bg-gray-300 rounded"
  //             >
  //               Cancel
  //             </button>
  //             <button
  //               onClick={handleSubmit}
  //               className="px-4 py-2 bg-green-600 text-white rounded"
  //             >
  //               {editMode ? "Update" : "Add"}
  //             </button>
  //           </div>
  //         </div>
  //       </div>
  //     )}
  //   </div>
    
  //   </>
  // );
  return (
  <>
    <HeaderNavbar />
    <div className="min-h-screen bg-[#eaeaea]">
      <div className="p-6 max-w-7xl mx-auto">
        <h2 className="text-3xl font-bold mb-6 text-gray-800">Payroll Processing</h2>
        <button
          onClick={() => handleShowModal()}
          className="bg-gradient-to-r from-[#1f3b57] via-[#476b8c] to-[#1c2e44] text-white px-5 py-2 rounded hover:opacity-90 shadow"
        >
          ➕ Add Payroll
        </button>

        <div className="overflow-auto mt-6 rounded-lg shadow-lg">
          <table className="w-full border-collapse border border-gray-300 bg-gradient-to-br from-blue-100 to-blue-200">
            <thead className="bg-gradient-to-r from-[#1f3b57] via-[#476b8c] to-[#1c2e44] text-white text-sm text-left">
              <tr>
                <th className="p-3 border">#</th>
                <th className="p-3 border">Employee Name</th>
                <th className="p-3 border">Employee ID</th>
                <th className="p-3 border">Basic Salary</th>
                <th className="p-3 border">Allowances</th>
                <th className="p-3 border">Overtime</th>
                <th className="p-3 border">Bonuses</th>
                <th className="p-3 border">Deductions</th>
                <th className="p-3 border">LOP Days</th>
                <th className="p-3 border">LOP Deduction</th>
                <th className="p-3 border">Net Salary</th>
                <th className="p-3 border">Status</th>
                <th className="p-3 border">Processed At</th>
                <th className="p-3 border">Actions</th>
              </tr>
            </thead>
            <tbody>
              {payrolls.map((p) => (
                <tr key={p.id} className="text-center border-t hover:bg-gray-100">
                  <td className="p-2 border">{p.id}</td>
                  <td className="p-2 border">{p.employeeName}</td>
                  <td className="p-2 border">{p.employeeId}</td>
                  <td className="p-2 border">${p.basicSalary}</td>
                  <td className="p-2 border">${p.allowances}</td>
                  <td className="p-2 border">{p.overtime}</td>
                  <td className="p-2 border">${p.bonuses}</td>
                  <td className="p-2 border">${p.deductions}</td>
                  <td className="p-2 border">{p.lopDays}</td>
                  <td className="p-2 border">{p.lopDeduction}</td>
                  <td className="p-2 font-semibold border">${p.netSalary}</td>
                  <td className="p-2 border">
                    <span
                      className={`px-2 py-1 rounded text-sm ${
                        p.paymentStatus === "PROCESSED"
                          ? "bg-green-200 text-green-700"
                          : p.paymentStatus === "FAILED"
                          ? "bg-red-200 text-red-700"
                          : "bg-yellow-200 text-yellow-700"
                      }`}
                    >
                      {p.paymentStatus}
                    </span>
                  </td>
                  <td className="p-2 border">
                    {p.processedAt ? new Date(p.processedAt).toLocaleString() : "-"}
                  </td>
                  <td className="p-2 border">
                    <div className="flex justify-center gap-2">
                      <button
                        className="px-3 py-1 rounded hover:bg-yellow-300 bg-yellow-100"
                        onClick={() => handleShowModal(p)}
                      >
                        ✏️ Edit
                      </button>
                      <button
                        className="px-3 py-1 rounded hover:bg-red-300 bg-red-100"
                        onClick={() => handleDelete(p.id)}
                      >
                        🗑️ Delete
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {showModal && (
          <div className="fixed inset-0 z-50 backdrop-blur-sm bg-white/10 flex items-center justify-center">
            <div className="bg-white w-full max-w-xl p-6 rounded-lg shadow-2xl">
              <h3 className="text-2xl font-semibold mb-4 text-gray-800">
                {editMode ? "Edit Payroll" : "Add Payroll"}
              </h3>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Employee</label>
                  <select
                    name="employeeId"
                    className="w-full border rounded p-2"
                    value={currentPayroll.employeeId}
                    onChange={handleChange}
                  >
                    <option value="">Select Employee</option>
                    {employees.map((emp) => (
                      <option key={emp.id} value={emp.id}>
                        {emp.firstName} {emp.lastName}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Basic Salary</label>
                  <input
                    type="number"
                    name="basicSalary"
                    className="w-full border rounded p-2"
                    value={currentPayroll.basicSalary}
                    onChange={handleChange}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Allowances</label>
                  <input
                    type="number"
                    name="allowances"
                    className="w-full border rounded p-2"
                    value={currentPayroll.allowances}
                    onChange={handleChange}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Bonuses</label>
                  <input
                    type="number"
                    name="bonuses"
                    className="w-full border rounded p-2"
                    value={currentPayroll.bonuses}
                    onChange={handleChange}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Deductions</label>
                  <input
                    type="number"
                    name="deductions"
                    className="w-full border rounded p-2"
                    value={currentPayroll.deductions}
                    onChange={handleChange}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Payment Status</label>
                  <select
                    name="paymentStatus"
                    className="w-full border rounded p-2"
                    value={currentPayroll.paymentStatus}
                    onChange={handleChange}
                  >
                    <option value="PENDING">Pending</option>
                    <option value="PROCESSED">Processed</option>
                    <option value="FAILED">Failed</option>
                  </select>
                </div>
              </div>
              <div className="mt-6 flex justify-end gap-2">
                <button
                  onClick={handleCloseModal}
                  className="px-4 py-2 bg-gray-300 text-gray-800 rounded"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSubmit}
                  className="px-4 py-2 bg-gradient-to-r from-[#1f3b57] via-[#476b8c] to-[#1c2e44] text-white rounded"
                >
                  {editMode ? "Update" : "Add"}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  </>
);

};

export default PayrollProcessing;
