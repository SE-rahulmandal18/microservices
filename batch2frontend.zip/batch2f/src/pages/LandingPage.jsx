// import React from 'react';
// import Card from '../component/Card';
// import { motion } from 'framer-motion';
// import { useNavigate } from 'react-router-dom';
// import Footer from '../component/Footer';
// import HeaderNavbar from '../component/HeaderNavbar';

// const LandingPage = () => {
//     const navigate = useNavigate();

//     return (
//         <div className="flex flex-col min-h-screen">
//             {/* Header - Full width */}
//             <div className="w-full">
//                 <HeaderNavbar />
//             </div>

//             <div className="flex flex-col items-center justify-between gap-8 pt-16 lg:flex-row lg:py-5 lg:gap-10 flex-1 lg:px-14 sm:px-8 px-4">
//                 <div className="flex-1">
//                     <motion.h1
//                         initial={{ opacity: 0, y: -80 }}
//                         whileInView={{ opacity: 1, y: 0 }}
//                         viewport={{ once: true }}
//                         transition={{ duration: 0.8 }}
//                         className="font-bold font-roboto text-slate-800 md:text-5xl sm:text-4xl text-3xl md:leading-[55px] sm:leading-[45px] leading-10 lg:w-full md:w-[70%] w-full"
//                     >
//                         Payroll Software  
//                         Fully-Automated Payroll & Compliance Software
//                     </motion.h1>

//                     <p className="max-w-screen-lg mt-4 text-center text-gray-400">
//                         Automate your payroll with precision– disburse salaries, file & pay taxes, like TDS, PF, PT & ESIC from a single dashboard on your payroll software.
//                     </p>

//                     {/* Buttons */}
//                     <div className="flex items-center gap-3">
//                         <motion.button
//                             initial={{ opacity: 0, y: 80 }}
//                             whileInView={{ opacity: 1, y: 0 }}
//                             viewport={{ once: true }}
//                             transition={{ duration: 0.8 }}
//                             onClick={() => navigate("/login")}
//                             className="w-40 py-2 text-white rounded-md bg-gradient-to-r from-blue-500 to-green-500"
//                         >
//                             Start Now
//                         </motion.button>

//                         <motion.button
//                             initial={{ opacity: 0, y: 80 }}
//                             whileInView={{ opacity: 1, y: 0 }}
//                             viewport={{ once: true }}
//                             transition={{ duration: 0.8 }}
//                             onClick={() => navigate("/about")}
//                             className="w-40 py-2 text-white rounded-md bg-gradient-to-r from-blue-500 to-green-500"
//                         >
//                             About Us
//                         </motion.button>
//                     </div>
//                 </div>

//                 {/* Image */}
//                 <div className="flex justify-center flex-1 w-full">
//                     <motion.img
//                         initial={{ opacity: 0 }}
//                         whileInView={{ opacity: 1 }}
//                         viewport={{ once: true }}
//                         transition={{ duration: 0.8 }}
//                         className="sm:w-[480px] w-[400px] object-cover rounded-md"
//                         src="https://razorpay.com/build/browser/static/hero.adf3ca09.svg"
//                         alt="Payroll Software"
//                     />
//                 </div>
//             </div>

//             {/* Trusted by Companies */}
//             <div className="sm:pt-12 pt-7">
//                 <motion.p
//                     initial={{ opacity: 0, y: 50 }}
//                     whileInView={{ opacity: 1, y: 0 }}
//                     viewport={{ once: true }}
//                     transition={{ duration: 0.8 }}
//                     className="text-slate-800 font-roboto font-bold lg:w-[60%] md:w-[70%] sm:w-[80%] mx-auto text-3xl text-center"
//                 >
//                     Trusted by individuals and teams at the world’s best companies
//                 </motion.p>

//                 {/* Feature Cards */}
//                 <div className="grid grid-cols-1 gap-4 pt-4 mt-4 pb-7 lg:gap-7 xl:grid-cols-4 lg:grid-cols-3 sm:grid-cols-2">
//                     <Card title="Seamless Payroll Processing" desc="Automate salary calculations, tax deductions, and payouts with ease. Ensure accurate and timely payroll processing every month." />
//                     <Card title="Employee Management" desc="Keep track of employee records, attendance, and salary structures in one unified platform, making HR management effortless." />
//                     <Card title="Tax Compliance & Reports" desc="Stay compliant with automated tax calculations and generate reports for audits, filings, and financial insights without hassle." />
//                     <Card title="Secure & Reliable" desc="Protect sensitive payroll data with industry-grade encryption and secure access controls, ensuring confidentiality and reliability." />
//                 </div>
//             </div>

//             {/* Footer - Full width */}
//             <div className="w-full">
//                 <Footer />
//             </div>
//         </div>
//     );
// };

// export default LandingPage;




// import React from 'react';
// import { motion } from 'framer-motion';
// import { useNavigate } from 'react-router-dom';
// import Footer from '../component/Footer';
// import HeaderNavbar from '../component/HeaderNavbar';

// const features = [
//   {
//     emoji: '💼',
//     title: '360° Payroll Management',
//     desc: 'Calculate & transfer accurate salaries, Easy Attendance - Salary Sync. No need to manually match attendance data to payroll computation.',
//   },
//   {
//     emoji: '📊',
//     title: 'Strategic Insights with Analytics & Reports',
//     desc: 'Track and analyze data on a centralized dashboard. Use our suite of pre-built reports, or custom create one using your employee data.',
//   },
//   {
//     emoji: '📄',
//     title: 'Payslips & Reimbursements',
//     desc: 'Employees can easily access payslips and file for reimbursements on WhatsApp or on the dashboard.',
//   },
//   {
//     emoji: '💸',
//     title: 'Automated Tax Filing and Payment',
//     desc: 'We file and pay your TDS, PF, PT & ESIC for you, and keep the challans ready on your dashboard.',
//   },
//   {
//     emoji: '🕒',
//     title: 'Attendance Management',
//     desc: 'Manage, approve and track leaves. Attendance will be automatically computed into the salary cycle.',
//   },
//   {
//     emoji: '⚙️',
//     title: 'Personalize salary components',
//     desc: 'Accommodate diverse salary structures that suit each employee and your organisation hierarchy with custom earnings, and deductions.',
//   },
//   {
//     emoji: '🔐',
//     title: 'Secure payroll with multi-level approvals',
//     desc: 'Ensure every pay run passes through the right hands with multi-level approvals, keeping your process completely reliable.',
//   },
//   {
//     emoji: '🚀',
//     title: 'Effortless scalability',
//     desc: 'From budding start-ups to established large businesses, we help simplify your payroll.',
//   },
// ];

// const LandingPage = () => {
//   const navigate = useNavigate();

//   const leftFeatures = features.slice(0, 4);
//   const rightFeatures = features.slice(4, 8);

//   return (
//     <div className="flex flex-col min-h-screen bg-[#eaeaea] text-slate-800">
//       <HeaderNavbar />

//       <div className="flex flex-col items-center justify-center flex-1 px-4 py-16 text-center">
//         <motion.h1
//           initial={{ opacity: 0, y: -50 }}
//           whileInView={{ opacity: 1, y: 0 }}
//           viewport={{ once: true }}
//           transition={{ duration: 0.8 }}
//           className="font-bold font-roboto bg-gradient-to-br from-[#1f3b57] via-[#476b8c] to-[#1c2e44] bg-clip-text text-transparent text-4xl sm:text-5xl md:text-6xl leading-tight"
//         >
//           Reimagine Payroll — Simplified, Automated, Empowered
//         </motion.h1>

//         <motion.p
//           initial={{ opacity: 0, y: 20 }}
//           whileInView={{ opacity: 1, y: 0 }}
//           viewport={{ once: true }}
//           transition={{ duration: 0.6 }}
//           className="mt-4 text-lg text-gray-700"
//         >
//           A Payroll System That Does More Than Just Processing Salaries
//         </motion.p>

//         <div className="flex flex-col sm:flex-row gap-4 mt-6">
//           <motion.button
//             initial={{ opacity: 0, y: 80 }}
//             whileInView={{ opacity: 1, y: 0 }}
//             viewport={{ once: true }}
//             transition={{ duration: 0.8 }}
//             onClick={() => navigate("/login")}
//             className="w-40 py-2 text-white rounded-md bg-gradient-to-r from-[#4B352A] via-[#6E4F3A] to-[#8C6A54] hover:to-[#4B352A] shadow-lg transition duration-300"
//           >
//             Start Now
//           </motion.button>

//           <motion.button
//             initial={{ opacity: 0, y: 80 }}
//             whileInView={{ opacity: 1, y: 0 }}
//             viewport={{ once: true }}
//             transition={{ duration: 0.8 }}
//             onClick={() => navigate("/about")}
//             className="w-40 py-2 text-white rounded-md bg-gradient-to-r from-[#4B352A] via-[#6E4F3A] to-[#8C6A54] hover:to-[#4B352A] shadow-lg transition duration-300"
//           >
//             About Us
//           </motion.button>
//         </div>
//       </div>

//       <motion.div
//         initial={{ opacity: 0, y: 40 }}
//         whileInView={{ opacity: 1, y: 0 }}
//         viewport={{ once: true }}
//         transition={{ duration: 0.8 }}
//         className="text-center mb-8 px-4"
//       >
//         <h2 className="font-bold text-3xl sm:text-4xl drop-shadow-sm bg-gradient-to-br from-[#1f3b57] via-[#476b8c] to-[#1c2e44] bg-clip-text text-transparent">
//           Effortless Payroll
//         </h2>
//         <p className="mt-2 text-gray-700 text-lg">
//           Automate payroll. From start to finish.
//         </p>
//       </motion.div>

//       <div className="flex flex-col md:flex-row justify-center gap-12 pb-16 px-6">
//         <div className="flex flex-col gap-8 w-full md:w-1/2">
//           {leftFeatures.map((feature, index) => (
//             <motion.div
//               key={index}
//               initial={{ opacity: 0, y: 40 }}
//               whileInView={{ opacity: 1, y: 0 }}
//               viewport={{ once: true }}
//               transition={{ duration: 0.6 + index * 0.1 }}
//               className="bg-gradient-to-br from-[#5a7cae] via-[#8aaacf] to-[#b1c7e0] rounded-xl shadow-md p-6 hover:shadow-2xl transition duration-300 ease-in-out hover:scale-[1.03]"
//             >
//               <h3 className="font-semibold text-2xl text-[#213448] mb-2">
//                 {feature.emoji} {feature.title}
//               </h3>
//               <p className="text-[#1f2f3f] text-lg leading-relaxed">{feature.desc}</p>
//             </motion.div>
//           ))}
//         </div>

//         <div className="flex flex-col gap-8 w-full md:w-1/2">
//           {rightFeatures.map((feature, index) => (
//             <motion.div
//               key={index + 4}
//               initial={{ opacity: 0, y: 40 }}
//               whileInView={{ opacity: 1, y: 0 }}
//               viewport={{ once: true }}
//               transition={{ duration: 0.6 + (index + 4) * 0.1 }}
//               className="bg-gradient-to-br from-[#5a7cae] via-[#8aaacf] to-[#b1c7e0] rounded-xl shadow-md p-6 hover:shadow-2xl transition duration-300 ease-in-out hover:scale-[1.03]"
//             >
//               <h3 className="font-semibold text-2xl text-[#213448] mb-2">
//                 {feature.emoji} {feature.title}
//               </h3>
//               <p className="text-[#1f2f3f] text-lg leading-relaxed">{feature.desc}</p>
//             </motion.div>
//           ))}
//         </div>
//       </div>

//       <Footer />
//     </div>
//   );
// };

// export default LandingPage;

import React from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import Footer from '../component/Footer';
import HeaderNavbar from '../component/HeaderNavbar';
 
const features = [
  {
    icon: '💼', // Will be replaced with an icon component
    title: '360° Payroll Management',
    desc: 'Calculate & transfer accurate salaries, Easy Attendance - Salary Sync. No need to manually match attendance data to payroll computation.',
  },
  {
    icon: '📊', // Will be replaced with an icon component
    title: 'Strategic Insights with Analytics & Reports',
    desc: 'Track and analyze data on a centralized dashboard. Use our suite of pre-built reports, or custom create one using your employee data.',
  },
  {
    icon: '📄', // Will be replaced with an icon component
    title: 'Payslips & Reimbursements',
    desc: 'Employees can easily access payslips and file for reimbursements on WhatsApp or on the dashboard.',
  },
  {
    icon: '💸', // Will be replaced with an icon component
    title: 'Automated Tax Filing and Payment',
    desc: 'We file and pay your TDS, PF, PT & ESIC for you, and keep the challans ready on your dashboard.',
  },
  {
    icon: '🕒', // Will be replaced with an icon component
    title: 'Attendance Management',
    desc: 'Manage, approve and track leaves. Attendance will be automatically computed into the salary cycle.',
  },
  {
    icon: '⚙️', // Will be replaced with an icon component
    title: 'Personalize salary components',
    desc: 'Accommodate diverse salary structures that suit each employee and your organisation hierarchy with custom earnings, and deductions.',
  },
  {
    icon: '🔐', // Will be replaced with an icon component
    title: 'Secure payroll with multi-level approvals',
    desc: 'Ensure every pay run passes through the right hands with multi-level approvals, keeping your process completely reliable.',
  },
  {
    icon: '🚀', // Will be replaced with an icon component
    title: 'Effortless scalability',
    desc: 'From budding start-ups to established large businesses, we help simplify your payroll.',
  },
];
 
// Icon component to replace emojis
const FeatureIcon = ({ icon }) => {
  // In a real implementation, you would replace these with actual SVG icons
  // This is just a placeholder to show the concept
  return (
    <div className="flex items-center justify-center w-12 h-12 mb-4 rounded-full bg-blue-100 text-blue-600 text-xl">
      {icon}
    </div>
  );
};
 
const LandingPage = () => {
  const navigate = useNavigate();
 
  const leftFeatures = features.slice(0, 4);
  const rightFeatures = features.slice(4, 8);
 
  return (
    <div className="flex flex-col min-h-screen bg-[#f8f9fa] text-gray-800">
      <HeaderNavbar />
 
      {/* Hero Section */}
      <div className="flex flex-col items-center justify-center flex-1 px-4 py-16 text-center bg-gradient-to-b from-white to-[#eaeaea]">
            <motion.h1
        initial={{ opacity: 0, y: -50 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.8 }}
        className="font-bold font-roboto bg-gradient-to-br from-[#1f3b57] via-[#476b8c] to-[#1c2e44] bg-clip-text text-transparent text-4xl sm:text-5xl md:text-6xl leading-tight max-w-4xl mx-auto"
      >
        <span className="block">Reimagine Payroll</span>
        <span className="block">Simplified, Automated, Empowered</span>
      </motion.h1>
 
 
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mt-6 text-lg text-gray-600 max-w-2xl mx-auto"
        >
          A comprehensive payroll solution that goes beyond salary processing to transform your HR operations
        </motion.p>
 
        <div className="flex flex-col sm:flex-row gap-4 mt-8">
          <motion.button
            initial={{ opacity: 0, y: 80 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            onClick={() => navigate("/login")}
            className="px-8 py-3 text-white rounded-md bg-gradient-to-r from-[#1f3b57] to-[#476b8c] hover:from-[#476b8c] hover:to-[#1f3b57] shadow-md transition-all duration-300 hover:shadow-lg"
          >
            Get Started
          </motion.button>
 
          <motion.button
            initial={{ opacity: 0, y: 80 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            onClick={() => navigate("/about")}
            className="px-8 py-3 text-[#1f3b57] rounded-md bg-white border border-[#1f3b57] hover:bg-[#f0f4f8] shadow-md transition-all duration-300 hover:shadow-lg"
          >
            Learn More
          </motion.button>
        </div>
      </div>
 
      {/* Features Section */}
      <div className="py-16 bg-white">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-12 px-4"
        >
          <h2 className="font-bold text-3xl sm:text-4xl text-[#1f3b57]">
            Comprehensive Payroll Solutions
          </h2>
          <p className="mt-4 text-gray-600 text-lg max-w-2xl mx-auto">
            End-to-end payroll automation designed for modern businesses
          </p>
        </motion.div>
 
        <div className="flex flex-col md:flex-row justify-center gap-8 pb-8 px-6 max-w-7xl mx-auto">
          <div className="flex flex-col gap-8 w-full md:w-1/2">
            {leftFeatures.map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 + index * 0.1 }}
                className="bg-white rounded-xl shadow-sm p-8 hover:shadow-md transition duration-300 ease-in-out border border-gray-100"
              >
                <FeatureIcon icon={feature.icon} />
                <h3 className="font-semibold text-xl text-[#1f3b57] mb-3">
                  {feature.title}
                </h3>
                <p className="text-gray-600 leading-relaxed">{feature.desc}</p>
              </motion.div>
            ))}
          </div>
 
          <div className="flex flex-col gap-8 w-full md:w-1/2">
            {rightFeatures.map((feature, index) => (
              <motion.div
                key={index + 4}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 + (index + 4) * 0.1 }}
                className="bg-white rounded-xl shadow-sm p-8 hover:shadow-md transition duration-300 ease-in-out border border-gray-100"
              >
                <FeatureIcon icon={feature.icon} />
                <h3 className="font-semibold text-xl text-[#1f3b57] mb-3">
                  {feature.title}
                </h3>
                <p className="text-gray-600 leading-relaxed">{feature.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
 
      {/* CTA Section */}
      <div className="py-16 bg-gradient-to-r from-[#1f3b57] to-[#476b8c] text-white">
        <div className="max-w-4xl mx-auto text-center px-4">
          <h2 className="font-bold text-3xl sm:text-4xl mb-6">
            Ready to transform your payroll process?
          </h2>
          <p className="text-lg mb-8 opacity-90 max-w-2xl mx-auto">
            Join hundreds of businesses who trust our platform for their payroll needs.
          </p>
          <button
            onClick={() => navigate("/login")}
            className="px-8 py-3 bg-white text-[#1f3b57] rounded-md font-medium hover:bg-gray-100 transition duration-300 shadow-lg"
          >
            Start Your Free Trial
          </button>
        </div>
      </div>
 
      <Footer />
    </div>
  );
};
 
export default LandingPage;