// import React, { useEffect, useState } from 'react';
// import axios from 'axios';
// import { useNavigate } from 'react-router-dom';
// import HeaderNavbar from '../component/HeaderNavbar';
// import Footer from '../component/Footer';
// import { motion } from 'framer-motion';

// const EmployeeAnalyticsDashboard = () => {
//   const [employee, setEmployee] = useState(null);
//   const [attendance, setAttendance] = useState([]);
//   const [leaves, setLeaves] = useState([]);
//   const [payrolls, setPayrolls] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState(null);
//   const navigate = useNavigate();

//   useEffect(() => {
//     const fetchEmployeeData = async () => {
//       try {
//         const token = localStorage.getItem('token');
//         if (!token) {
//           navigate('/login');
//           return;
//         }

//         const config = {
//           headers: { Authorization: `Bearer ${token}` }
//         };

//         // Fetch employee details
//         const employeeRes = await axios.get('http://localhost:8080/api/employees/me', config);
//         const employeeData = employeeRes.data;
//         setEmployee(employeeData);

//         // Fetch all data in parallel
//         const [attendanceRes, leavesRes, payrollsRes] = await Promise.all([
//           axios.get('http://localhost:8080/api/attendance', config),
//           axios.get('http://localhost:8080/api/leaves', config),
//           axios.get('http://localhost:8080/api/payrolls', config)
//         ]);

//         // Filter data for current employee
//         const filteredAttendance = attendanceRes.data.filter(
//           a => a.employee && a.employee.id === employeeData.id
//         );
//         setAttendance(filteredAttendance);

//         const filteredLeaves = leavesRes.data.filter(
//           l => l.employee && l.employee.id === employeeData.id
//         );
//         setLeaves(filteredLeaves);

//         const filteredPayrolls = payrollsRes.data.filter(
//           p => p.employee && p.employee.id === employeeData.id
//         );
//         setPayrolls(filteredPayrolls);

//       } catch (err) {
//         setError(err.response?.data?.message || 'Failed to fetch data');
//         console.error('Error fetching data:', err);
//       } finally {
//         setLoading(false);
//       }
//     };

//     fetchEmployeeData();
//   }, [navigate]);

//   // Calculate insights
//   const calculateInsights = () => {
//     if (!employee) return {};

//     const totalWorkDays = attendance.length;
//     const totalLeaves = leaves.length;
//     const paidLeaves = leaves.filter(l => l.isPaid).length;
//     const unpaidLeaves = totalLeaves - paidLeaves;
//     const totalOvertime = attendance.reduce((sum, a) => sum + (a.overtimeHours || 0), 0);
//     const totalHours = attendance.reduce((sum, a) => sum + (a.totalHours || 0), 0);
//     const avgHoursPerDay = attendance.length > 0 ? totalHours / attendance.length : 0;
    
//     // Payroll calculations
//     const processedPayrolls = payrolls.filter(p => p.paymentStatus === 'PROCESSED');
//     const lastPayroll = processedPayrolls.length > 0 
//       ? processedPayrolls[processedPayrolls.length - 1] 
//       : null;
//     const totalSalary = processedPayrolls.reduce((sum, p) => sum + (p.netSalary || 0), 0);
//     const avgMonthlySalary = processedPayrolls.length > 0 
//       ? totalSalary / processedPayrolls.length 
//       : 0;
    
//     // Current month data
//     const currentMonth = new Date().getMonth();
//     const currentYear = new Date().getFullYear();
    
//     const thisMonthAttendance = attendance.filter(a => {
//       const date = new Date(a.workDate);
//       return date.getMonth() === currentMonth && date.getFullYear() === currentYear;
//     });
    
//     const thisMonthLeaves = leaves.filter(l => {
//       const date = new Date(l.leaveDate || l.startDate);
//       return date.getMonth() === currentMonth && date.getFullYear() === currentYear;
//     });

//     // Employment duration
//     const joinDate = new Date(employee.joinDate);
//     const today = new Date();
//     const employmentDurationMonths = (today.getFullYear() - joinDate.getFullYear()) * 12 + 
//                                     (today.getMonth() - joinDate.getMonth());

//     // Leave balances
//     const casualLeavesTaken = leaves.filter(l => l.leaveType === 'CASUAL').length;
//     const sickLeavesTaken = leaves.filter(l => l.leaveType === 'SICK').length;
//     const annualLeavesTaken = leaves.filter(l => l.leaveType === 'ANNUAL').length;

//     // Attendance streak
//     let currentStreak = 0;
//     const sortedAttendance = [...attendance].sort((a, b) => new Date(b.workDate) - new Date(a.workDate));
//     const yesterday = new Date();
//     yesterday.setDate(yesterday.getDate() - 1);
    
//     for (let i = 0; i < sortedAttendance.length; i++) {
//       const attDate = new Date(sortedAttendance[i].workDate);
//       if (i === 0 && attDate.toDateString() === yesterday.toDateString()) {
//         currentStreak = 1;
//       } else if (i > 0) {
//         const prevDate = new Date(sortedAttendance[i-1].workDate);
//         const dayDiff = (prevDate - attDate) / (1000 * 60 * 60 * 24);
//         if (dayDiff === 1) {
//           currentStreak++;
//         } else {
//           break;
//         }
//       }
//     }

//     return {
//       totalWorkDays,
//       totalLeaves,
//       paidLeaves,
//       unpaidLeaves,
//       totalOvertime,
//       avgHoursPerDay,
//       lastPayroll,
//       avgMonthlySalary,
//       thisMonthAttendance: thisMonthAttendance.length,
//       thisMonthLeaves: thisMonthLeaves.length,
//       employmentDuration: employmentDurationMonths,
//       remainingCasualLeaves: Math.max(0, 10 - casualLeavesTaken),
//       remainingSickLeaves: Math.max(0, 10 - sickLeavesTaken),
//       remainingAnnualLeaves: Math.max(0, 12 - annualLeavesTaken),
//       lastAttendance: attendance.length > 0 ? attendance[attendance.length - 1] : null,
//       currentStreak,
//       processedPayrollsCount: processedPayrolls.length,
//       pendingPayrolls: payrolls.filter(p => p.paymentStatus === 'PENDING').length,
//       basicSalary: employee.basicSalary || 0,
//       employmentType: employee.employmentType || 'FULL_TIME'
//     };
//   };

//   const insights = calculateInsights();

//   if (loading) {
//     return (
//       <div className="min-h-screen flex items-center justify-center">
//         <div className="text-xl">Loading your dashboard...</div>
//       </div>
//     );
//   }

//   if (error) {
//     return (
//       <div className="min-h-screen flex items-center justify-center">
//         <div className="text-red-500 text-xl">{error}</div>
//       </div>
//     );
//   }

//   if (!employee) {
//     return (
//       <div className="min-h-screen flex items-center justify-center">
//         <div className="text-xl">No employee data found</div>
//       </div>
//     );
//   }

//   // Format currency
//   const formatCurrency = (amount) => {
//     return new Intl.NumberFormat('en-IN', {
//       style: 'currency',
//       currency: 'INR'
//     }).format(amount || 0);
//   };

//   return (
//     <>
//       <HeaderNavbar />
//       <div className="min-h-[calc(100vh-64px)] bg-gray-50 p-6">
//         <div className="max-w-7xl mx-auto">
//           {/* Header */}
//           <motion.div
//             initial={{ opacity: 0, y: -20 }}
//             animate={{ opacity: 1, y: 0 }}
//             transition={{ duration: 0.5 }}
//             className="bg-white rounded-lg shadow-md p-6 mb-6"
//           >
//             <div className="flex flex-col md:flex-row items-start md:items-center justify-between">
//               <div>
//                 <h1 className="text-3xl font-bold text-gray-800">
//                   Welcome, {employee.firstName} {employee.lastName}
//                 </h1>
//                 <p className="text-gray-600 mt-2">
//                   {employee.designation} | {employee.department} Department
//                 </p>
//               </div>
//               <div className="mt-4 md:mt-0 text-left md:text-right">
//                 <p className="text-sm text-gray-500">Employee ID: {employee.id}</p>
//                 <p className="text-sm text-gray-500">
//                   Joined on: {new Date(employee.joinDate).toLocaleDateString()}
//                 </p>
//                 <p className="text-sm text-gray-500">
//                   Status: <span className={`font-semibold ${
//                     employee.status === 'ACTIVE' ? 'text-green-600' : 'text-red-600'
//                   }`}>
//                     {employee.status}
//                   </span>
//                 </p>
//               </div>
//             </div>
//           </motion.div>

//           {/* Key Metrics */}
//           <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
//             {/* Basic Salary */}
//             <motion.div
//               initial={{ opacity: 0, y: 20 }}
//               animate={{ opacity: 1, y: 0 }}
//               transition={{ duration: 0.5, delay: 0.1 }}
//               className="bg-white rounded-lg shadow-md p-6"
//             >
//               <h3 className="text-lg font-semibold text-gray-800 mb-2">Basic Salary</h3>
//               <p className="text-3xl font-bold text-blue-600">
//                 {formatCurrency(insights.basicSalary)}
//               </p>
//               <p className="text-sm text-gray-500 mt-2">Monthly base salary</p>
//             </motion.div>

//             {/* Last Salary */}
//             <motion.div
//               initial={{ opacity: 0, y: 20 }}
//               animate={{ opacity: 1, y: 0 }}
//               transition={{ duration: 0.5, delay: 0.2 }}
//               className="bg-white rounded-lg shadow-md p-6"
//             >
//               <h3 className="text-lg font-semibold text-gray-800 mb-2">Last Salary</h3>
//               {insights.lastPayroll ? (
//                 <>
//                   <p className="text-3xl font-bold text-green-600">
//                     {formatCurrency(insights.lastPayroll.netSalary)}
//                   </p>
//                   <p className="text-sm text-gray-500 mt-2">
//                     Processed on: {new Date(insights.lastPayroll.processedAt).toLocaleDateString()}
//                   </p>
//                 </>
//               ) : (
//                 <p className="text-gray-500">No processed payroll records</p>
//               )}
//             </motion.div>

//             {/* Average Monthly Salary */}
//             <motion.div
//               initial={{ opacity: 0, y: 20 }}
//               animate={{ opacity: 1, y: 0 }}
//               transition={{ duration: 0.5, delay: 0.3 }}
//               className="bg-white rounded-lg shadow-md p-6"
//             >
//               <h3 className="text-lg font-semibold text-gray-800 mb-2">Avg. Monthly Salary</h3>
//               <p className="text-3xl font-bold text-purple-600">
//                 {formatCurrency(insights.avgMonthlySalary)}
//               </p>
//               <p className="text-sm text-gray-500 mt-2">
//                 Based on {insights.processedPayrollsCount} payrolls
//               </p>
//             </motion.div>

//             {/* Pending Payments */}
//             <motion.div
//               initial={{ opacity: 0, y: 20 }}
//               animate={{ opacity: 1, y: 0 }}
//               transition={{ duration: 0.5, delay: 0.4 }}
//               className="bg-white rounded-lg shadow-md p-6"
//             >
//               <h3 className="text-lg font-semibold text-gray-800 mb-2">Pending Payments</h3>
//               <p className="text-3xl font-bold text-orange-600">
//                 {insights.pendingPayrolls}
//               </p>
//               <p className="text-sm text-gray-500 mt-2">
//                 Awaiting processing
//               </p>
//             </motion.div>
//           </div>

//           {/* Insights Grid */}
//           <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
//             {/* Employment Duration */}
//             <motion.div
//               initial={{ opacity: 0, y: 20 }}
//               animate={{ opacity: 1, y: 0 }}
//               transition={{ duration: 0.5, delay: 0.5 }}
//               className="bg-white rounded-lg shadow-md p-6"
//             >
//               <h3 className="text-lg font-semibold text-gray-800 mb-2">Employment Duration</h3>
//               <p className="text-3xl font-bold text-blue-600">
//                 {insights.employmentDuration} months
//               </p>
//               <p className="text-sm text-gray-500 mt-2">
//                 Since {new Date(employee.joinDate).toLocaleDateString()}
//               </p>
//             </motion.div>

//             {/* Attendance Streak */}
//             <motion.div
//               initial={{ opacity: 0, y: 20 }}
//               animate={{ opacity: 1, y: 0 }}
//               transition={{ duration: 0.5, delay: 0.6 }}
//               className="bg-white rounded-lg shadow-md p-6"
//             >
//               <h3 className="text-lg font-semibold text-gray-800 mb-2">Current Attendance Streak</h3>
//               <p className="text-3xl font-bold text-green-600">{insights.currentStreak} days</p>
//               <p className="text-sm text-gray-500 mt-2">Consecutive work days</p>
//             </motion.div>

//             {/* Total Work Days */}
//             <motion.div
//               initial={{ opacity: 0, y: 20 }}
//               animate={{ opacity: 1, y: 0 }}
//               transition={{ duration: 0.5, delay: 0.7 }}
//               className="bg-white rounded-lg shadow-md p-6"
//             >
//               <h3 className="text-lg font-semibold text-gray-800 mb-2">Total Work Days</h3>
//               <p className="text-3xl font-bold text-green-600">{insights.totalWorkDays}</p>
//               <p className="text-sm text-gray-500 mt-2">All-time attendance records</p>
//             </motion.div>

//             {/* Average Hours Per Day */}
//             <motion.div
//               initial={{ opacity: 0, y: 20 }}
//               animate={{ opacity: 1, y: 0 }}
//               transition={{ duration: 0.5, delay: 0.8 }}
//               className="bg-white rounded-lg shadow-md p-6"
//             >
//               <h3 className="text-lg font-semibold text-gray-800 mb-2">Average Hours Per Day</h3>
//               <p className="text-3xl font-bold text-purple-600">
//                 {insights.avgHoursPerDay.toFixed(2)} hrs
//               </p>
//               <p className="text-sm text-gray-500 mt-2">Based on your attendance</p>
//             </motion.div>

//             {/* Total Overtime */}
//             <motion.div
//               initial={{ opacity: 0, y: 20 }}
//               animate={{ opacity: 1, y: 0 }}
//               transition={{ duration: 0.5, delay: 0.9 }}
//               className="bg-white rounded-lg shadow-md p-6"
//             >
//               <h3 className="text-lg font-semibold text-gray-800 mb-2">Total Overtime</h3>
//               <p className="text-3xl font-bold text-yellow-600">
//                 {insights.totalOvertime.toFixed(2)} hrs
//               </p>
//               <p className="text-sm text-gray-500 mt-2">All-time extra hours worked</p>
//             </motion.div>

//             {/* Total Leaves */}
//             <motion.div
//               initial={{ opacity: 0, y: 20 }}
//               animate={{ opacity: 1, y: 0 }}
//               transition={{ duration: 0.5, delay: 1.0 }}
//               className="bg-white rounded-lg shadow-md p-6"
//             >
//               <h3 className="text-lg font-semibold text-gray-800 mb-2">Total Leaves Taken</h3>
//               <div className="flex justify-between">
//                 <div>
//                   <p className="text-3xl font-bold text-red-600">{insights.totalLeaves}</p>
//                   <p className="text-sm text-gray-500 mt-2">All leaves</p>
//                 </div>
//                 <div className="text-right">
//                   <p className="text-xl font-semibold text-green-600">{insights.paidLeaves}</p>
//                   <p className="text-sm text-gray-500">Paid leaves</p>
//                 </div>
//                 <div className="text-right">
//                   <p className="text-xl font-semibold text-orange-600">{insights.unpaidLeaves}</p>
//                   <p className="text-sm text-gray-500">Unpaid leaves</p>
//                 </div>
//               </div>
//             </motion.div>

//             {/* This Month Attendance */}
//             <motion.div
//               initial={{ opacity: 0, y: 20 }}
//               animate={{ opacity: 1, y: 0 }}
//               transition={{ duration: 0.5, delay: 1.1 }}
//               className="bg-white rounded-lg shadow-md p-6"
//             >
//               <h3 className="text-lg font-semibold text-gray-800 mb-2">This Month</h3>
//               <div className="flex justify-between">
//                 <div>
//                   <p className="text-2xl font-bold text-blue-600">{insights.thisMonthAttendance}</p>
//                   <p className="text-sm text-gray-500 mt-2">Work days</p>
//                 </div>
//                 <div className="text-right">
//                   <p className="text-2xl font-bold text-red-600">{insights.thisMonthLeaves}</p>
//                   <p className="text-sm text-gray-500">Leaves taken</p>
//                 </div>
//               </div>
//             </motion.div>

//             {/* Leave Balances */}
//             <motion.div
//               initial={{ opacity: 0, y: 20 }}
//               animate={{ opacity: 1, y: 0 }}
//               transition={{ duration: 0.5, delay: 1.2 }}
//               className="bg-white rounded-lg shadow-md p-6"
//             >
//               <h3 className="text-lg font-semibold text-gray-800 mb-4">Leave Balances</h3>
              
//               <div className="space-y-4">
//                 {/* Casual Leaves */}
//                 <div>
//                   <div className="flex justify-between mb-1">
//                     <span className="text-sm font-medium text-blue-700">Casual</span>
//                     <span className="text-sm font-medium text-blue-700">
//                       {insights.remainingCasualLeaves}/10
//                     </span>
//                   </div>
//                   <div className="w-full bg-gray-200 rounded-full h-2.5">
//                     <div 
//                       className="bg-blue-600 h-2.5 rounded-full" 
//                       style={{ width: `${(insights.remainingCasualLeaves / 10) * 100}%` }}
//                     ></div>
//                   </div>
//                 </div>
                
//                 {/* Sick Leaves */}
//                 <div>
//                   <div className="flex justify-between mb-1">
//                     <span className="text-sm font-medium text-green-700">Sick</span>
//                     <span className="text-sm font-medium text-green-700">
//                       {insights.remainingSickLeaves}/10
//                     </span>
//                   </div>
//                   <div className="w-full bg-gray-200 rounded-full h-2.5">
//                     <div 
//                       className="bg-green-600 h-2.5 rounded-full" 
//                       style={{ width: `${(insights.remainingSickLeaves / 10) * 100}%` }}
//                     ></div>
//                   </div>
//                 </div>
                
//                 {/* Annual Leaves */}
//                 <div>
//                   <div className="flex justify-between mb-1">
//                     <span className="text-sm font-medium text-purple-700">Annual</span>
//                     <span className="text-sm font-medium text-purple-700">
//                       {insights.remainingAnnualLeaves}/12
//                     </span>
//                   </div>
//                   <div className="w-full bg-gray-200 rounded-full h-2.5">
//                     <div 
//                       className="bg-purple-600 h-2.5 rounded-full" 
//                       style={{ width: `${(insights.remainingAnnualLeaves / 12) * 100}%` }}
//                     ></div>
//                   </div>
//                 </div>
//               </div>
//             </motion.div>

//             {/* Last Attendance */}
//             <motion.div
//               initial={{ opacity: 0, y: 20 }}
//               animate={{ opacity: 1, y: 0 }}
//               transition={{ duration: 0.5, delay: 1.3 }}
//               className="bg-white rounded-lg shadow-md p-6"
//             >
//               <h3 className="text-lg font-semibold text-gray-800 mb-2">Last Attendance</h3>
//               {insights.lastAttendance ? (
//                 <>
//                   <p className="text-xl font-bold text-gray-800">
//                     {new Date(insights.lastAttendance.workDate).toLocaleDateString()}
//                   </p>
//                   <div className="flex justify-between mt-4">
//                     <div>
//                       <p className="text-sm text-gray-500">Check-in</p>
//                       <p className="font-medium">{insights.lastAttendance.checkInTime}</p>
//                     </div>
//                     <div>
//                       <p className="text-sm text-gray-500">Check-out</p>
//                       <p className="font-medium">{insights.lastAttendance.checkOutTime}</p>
//                     </div>
//                     <div>
//                       <p className="text-sm text-gray-500">Total</p>
//                       <p className="font-medium">{insights.lastAttendance.totalHours} hrs</p>
//                     </div>
//                   </div>
//                 </>
//               ) : (
//                 <p className="text-gray-500">No attendance records found</p>
//               )}
//             </motion.div>

//             {/* Employment Type */}
//             <motion.div
//               initial={{ opacity: 0, y: 20 }}
//               animate={{ opacity: 1, y: 0 }}
//               transition={{ duration: 0.5, delay: 1.4 }}
//               className="bg-white rounded-lg shadow-md p-6"
//             >
//               <h3 className="text-lg font-semibold text-gray-800 mb-2">Employment Type</h3>
//               <p className="text-xl font-bold text-blue-600 capitalize">
//                 {insights.employmentType.toLowerCase().replace('_', ' ')}
//               </p>
//               <p className="text-sm text-gray-500 mt-2">Current employment status</p>
//             </motion.div>

//             {/* Bank Account */}
//             <motion.div
//               initial={{ opacity: 0, y: 20 }}
//               animate={{ opacity: 1, y: 0 }}
//               transition={{ duration: 0.5, delay: 1.5 }}
//               className="bg-white rounded-lg shadow-md p-6"
//             >
//               <h3 className="text-lg font-semibold text-gray-800 mb-2">Bank Account</h3>
//               {employee.bankAccount ? (
//                 <>
//                   <p className="text-xl font-bold text-gray-800">****{employee.bankAccount.slice(-4)}</p>
//                   <p className="text-sm text-gray-500 mt-2">Salary account</p>
//                 </>
//               ) : (
//                 <p className="text-gray-500">No bank account on record</p>
//               )}
//             </motion.div>
//           </div>
//         </div>
//       </div>
//       <Footer />
//     </>
//   );
// };

// export default EmployeeAnalyticsDashboard;


// import React, { useEffect, useState } from 'react';
// import axios from 'axios';
// import { useNavigate } from 'react-router-dom';
// import HeaderNavbar from '../component/HeaderNavbar';
// import Footer from '../component/Footer';
// import { motion } from 'framer-motion';
// import { Bar, Pie, Line } from 'react-chartjs-2';
// import { Chart, registerables } from 'chart.js';
// Chart.register(...registerables);

// const EmployeeAnalyticsDashboard = () => {
//   const [employee, setEmployee] = useState(null);
//   const [attendance, setAttendance] = useState([]);
//   const [leaves, setLeaves] = useState([]);
//   const [payrolls, setPayrolls] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState(null);
//   const navigate = useNavigate();

//   useEffect(() => {
//     const fetchEmployeeData = async () => {
//       try {
//         const token = localStorage.getItem('token');
//         if (!token) {
//           navigate('/login');
//           return;
//         }

//         const config = {
//           headers: { Authorization: `Bearer ${token}` }
//         };

//         // Fetch employee details
//         const employeeRes = await axios.get('http://localhost:8080/api/employees/me', config);
//         const employeeData = employeeRes.data;
//         setEmployee(employeeData);

//         // Fetch all data in parallel
//         const [attendanceRes, leavesRes, payrollsRes] = await Promise.all([
//           axios.get('http://localhost:8080/api/attendance', config),
//           axios.get('http://localhost:8080/api/leaves', config),
//           axios.get('http://localhost:8080/api/payrolls', config)
//         ]);

//         // Filter data for current employee
//         const filteredAttendance = attendanceRes.data.filter(
//           a => a.employee && a.employee.id === employeeData.id
//         );
//         setAttendance(filteredAttendance);

//         const filteredLeaves = leavesRes.data.filter(
//           l => l.employee && l.employee.id === employeeData.id
//         );
//         setLeaves(filteredLeaves);

//         const filteredPayrolls = payrollsRes.data.filter(
//           p => p.employee && p.employee.id === employeeData.id
//         );
//         setPayrolls(filteredPayrolls);

//       } catch (err) {
//         setError(err.response?.data?.message || 'Failed to fetch data');
//         console.error('Error fetching data:', err);
//       } finally {
//         setLoading(false);
//       }
//     };

//     fetchEmployeeData();
//   }, [navigate]);

//   // Calculate insights
//   const calculateInsights = () => {
//     if (!employee) return {};

//     // Attendance calculations
//     const totalWorkDays = attendance.length;
//     const totalOvertime = attendance.reduce((sum, a) => sum + (a.overtimeHours || 0), 0);
//     const totalHours = attendance.reduce((sum, a) => sum + (a.totalHours || 0), 0);
//     const avgHoursPerDay = attendance.length > 0 ? totalHours / attendance.length : 0;
    
//     // Leave calculations
//     const totalLeaves = leaves.length;
//     const paidLeaves = leaves.filter(l => l.isPaid).length;
//     const unpaidLeaves = totalLeaves - paidLeaves;
//     const casualLeavesTaken = leaves.filter(l => l.leaveType === 'CASUAL').length;
//     const sickLeavesTaken = leaves.filter(l => l.leaveType === 'SICK').length;
//     const annualLeavesTaken = leaves.filter(l => l.leaveType === 'ANNUAL').length;
    
//     // Payroll calculations
//     const processedPayrolls = payrolls.filter(p => p.paymentStatus === 'PROCESSED');
//     const lastPayroll = processedPayrolls.length > 0 
//       ? processedPayrolls[processedPayrolls.length - 1] 
//       : null;
//     const totalSalary = processedPayrolls.reduce((sum, p) => sum + (p.netSalary || 0), 0);
//     const avgMonthlySalary = processedPayrolls.length > 0 
//       ? totalSalary / processedPayrolls.length 
//       : 0;
    
//     // Current month data
//     const currentMonth = new Date().getMonth();
//     const currentYear = new Date().getFullYear();
    
//     const thisMonthAttendance = attendance.filter(a => {
//       const date = new Date(a.workDate);
//       return date.getMonth() === currentMonth && date.getFullYear() === currentYear;
//     });
    
//     const thisMonthLeaves = leaves.filter(l => {
//       const date = new Date(l.leaveDate || l.startDate);
//       return date.getMonth() === currentMonth && date.getFullYear() === currentYear;
//     });

//     // Employment duration
//     const joinDate = new Date(employee.joinDate);
//     const today = new Date();
//     const employmentDurationMonths = (today.getFullYear() - joinDate.getFullYear()) * 12 + 
//                                     (today.getMonth() - joinDate.getMonth());

//     // Attendance streak
//     let currentStreak = 0;
//     const sortedAttendance = [...attendance].sort((a, b) => new Date(b.workDate) - new Date(a.workDate));
//     const yesterday = new Date();
//     yesterday.setDate(yesterday.getDate() - 1);
    
//     for (let i = 0; i < sortedAttendance.length; i++) {
//       const attDate = new Date(sortedAttendance[i].workDate);
//       if (i === 0 && attDate.toDateString() === yesterday.toDateString()) {
//         currentStreak = 1;
//       } else if (i > 0) {
//         const prevDate = new Date(sortedAttendance[i-1].workDate);
//         const dayDiff = (prevDate - attDate) / (1000 * 60 * 60 * 24);
//         if (dayDiff === 1) {
//           currentStreak++;
//         } else {
//           break;
//         }
//       }
//     }

//     // Monthly attendance data for chart
//     const monthlyAttendanceData = Array(12).fill(0);
//     attendance.forEach(a => {
//       const date = new Date(a.workDate);
//       if (date.getFullYear() === currentYear) {
//         monthlyAttendanceData[date.getMonth()]++;
//       }
//     });

//     // Leave type distribution for chart
//     const leaveTypeData = {
//       CASUAL: leaves.filter(l => l.leaveType === 'CASUAL').length,
//       SICK: leaves.filter(l => l.leaveType === 'SICK').length,
//       ANNUAL: leaves.filter(l => l.leaveType === 'ANNUAL').length,
//       UNPAID: unpaidLeaves
//     };

//     return {
//       totalWorkDays,
//       totalLeaves,
//       paidLeaves,
//       unpaidLeaves,
//       totalOvertime,
//       avgHoursPerDay,
//       lastPayroll,
//       avgMonthlySalary,
//       thisMonthAttendance: thisMonthAttendance.length,
//       thisMonthLeaves: thisMonthLeaves.length,
//       employmentDuration: employmentDurationMonths,
//       remainingCasualLeaves: Math.max(0, 10 - casualLeavesTaken),
//       remainingSickLeaves: Math.max(0, 10 - sickLeavesTaken),
//       remainingAnnualLeaves: Math.max(0, 12 - annualLeavesTaken),
//       lastAttendance: attendance.length > 0 ? attendance[attendance.length - 1] : null,
//       currentStreak,
//       processedPayrollsCount: processedPayrolls.length,
//       pendingPayrolls: payrolls.filter(p => p.paymentStatus === 'PENDING').length,
//       basicSalary: employee.basicSalary || 0,
//       employmentType: employee.employmentType || 'FULL_TIME',
//       monthlyAttendanceData,
//       leaveTypeData,
//       payrollHistory: processedPayrolls.map(p => ({
//         month: new Date(p.processedAt).toLocaleString('default', { month: 'short' }),
//         amount: p.netSalary
//       })).slice(-6) // Last 6 months
//     };
//   };

//   const insights = calculateInsights();

//   // Chart data
//   const attendanceChartData = {
//     labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
//     datasets: [
//       {
//         label: 'Work Days',
//         data: insights.monthlyAttendanceData || [],
//         backgroundColor: 'rgba(54, 162, 235, 0.5)',
//         borderColor: 'rgba(54, 162, 235, 1)',
//         borderWidth: 1
//       }
//     ]
//   };

//   const leaveTypeChartData = {
//     labels: ['Casual', 'Sick', 'Annual', 'Unpaid'],
//     datasets: [
//       {
//         data: [
//           insights.leaveTypeData?.CASUAL || 0,
//           insights.leaveTypeData?.SICK || 0,
//           insights.leaveTypeData?.ANNUAL || 0,
//           insights.leaveTypeData?.UNPAID || 0
//         ],
//         backgroundColor: [
//           'rgba(54, 162, 235, 0.5)',
//           'rgba(75, 192, 192, 0.5)',
//           'rgba(153, 102, 255, 0.5)',
//           'rgba(255, 159, 64, 0.5)'
//         ],
//         borderColor: [
//           'rgba(54, 162, 235, 1)',
//           'rgba(75, 192, 192, 1)',
//           'rgba(153, 102, 255, 1)',
//           'rgba(255, 159, 64, 1)'
//         ],
//         borderWidth: 1
//       }
//     ]
//   };

//   const salaryTrendChartData = {
//     labels: insights.payrollHistory?.map(p => p.month) || [],
//     datasets: [
//       {
//         label: 'Net Salary',
//         data: insights.payrollHistory?.map(p => p.amount) || [],
//         fill: false,
//         backgroundColor: 'rgba(75, 192, 192, 0.5)',
//         borderColor: 'rgba(75, 192, 192, 1)',
//         tension: 0.1
//       }
//     ]
//   };

//   // Format currency
//   const formatCurrency = (amount) => {
//     return new Intl.NumberFormat('en-IN', {
//       style: 'currency',
//       currency: 'INR',
//       minimumFractionDigits: 0,
//       maximumFractionDigits: 0
//     }).format(amount || 0);
//   };

//   // Format date
//   const formatDate = (dateString) => {
//     if (!dateString) return 'N/A';
//     const options = { year: 'numeric', month: 'short', day: 'numeric' };
//     return new Date(dateString).toLocaleDateString(undefined, options);
//   };

//   if (loading) {
//     return (
//       <div className="min-h-screen flex items-center justify-center">
//         <div className="text-xl">Loading your dashboard...</div>
//       </div>
//     );
//   }

//   if (error) {
//     return (
//       <div className="min-h-screen flex items-center justify-center">
//         <div className="text-red-500 text-xl">{error}</div>
//       </div>
//     );
//   }

//   if (!employee) {
//     return (
//       <div className="min-h-screen flex items-center justify-center">
//         <div className="text-xl">No employee data found</div>
//       </div>
//     );
//   }

//   return (
//     <>
//       <HeaderNavbar />
//       <div className="min-h-[calc(100vh-64px)] bg-gray-50 p-4 md:p-6">
//         <div className="max-w-7xl mx-auto">
//           {/* Header */}
//           <motion.div
//             initial={{ opacity: 0, y: -20 }}
//             animate={{ opacity: 1, y: 0 }}
//             transition={{ duration: 0.5 }}
//             className="bg-white rounded-xl shadow-sm p-6 mb-6 border border-gray-100"
//           >
//             <div className="flex flex-col md:flex-row items-start md:items-center justify-between">
//               <div className="flex items-center space-x-4">
//                 <div className="bg-blue-100 p-3 rounded-full">
//                   <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
//                     <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
//                   </svg>
//                 </div>
//                 <div>
//                   <h1 className="text-2xl font-bold text-gray-800">
//                     {employee.firstName} {employee.lastName}
//                   </h1>
//                   <p className="text-gray-600">
//                     {employee.designation} • {employee.department}
//                   </p>
//                 </div>
//               </div>
//               <div className="mt-4 md:mt-0 grid grid-cols-2 gap-4 text-sm">
//                 <div>
//                   <p className="text-gray-500">Employee ID</p>
//                   <p className="font-medium">#{employee.id}</p>
//                 </div>
//                 <div>
//                   <p className="text-gray-500">Join Date</p>
//                   <p className="font-medium">{formatDate(employee.joinDate)}</p>
//                 </div>
//                 <div>
//                   <p className="text-gray-500">Status</p>
//                   <p className={`font-medium ${
//                     employee.status === 'ACTIVE' ? 'text-green-600' : 'text-red-600'
//                   }`}>
//                     {employee.status}
//                   </p>
//                 </div>
//                 <div>
//                   <p className="text-gray-500">Employment Type</p>
//                   <p className="font-medium capitalize">
//                     {employee.employmentType.toLowerCase().replace('_', ' ')}
//                   </p>
//                 </div>
//               </div>
//             </div>
//           </motion.div>

//           {/* Key Metrics */}
//           <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
//             {/* Salary Card */}
//             <motion.div
//               initial={{ opacity: 0, y: 20 }}
//               animate={{ opacity: 1, y: 0 }}
//               transition={{ duration: 0.3, delay: 0.1 }}
//               className="bg-white rounded-xl shadow-sm p-6 border border-gray-100"
//             >
//               <div className="flex items-center justify-between">
//                 <div>
//                   <p className="text-sm font-medium text-gray-500">Monthly Salary</p>
//                   <p className="text-2xl font-bold text-gray-800 mt-1">
//                     {formatCurrency(insights.basicSalary)}
//                   </p>
//                 </div>
//                 <div className="bg-blue-100 p-3 rounded-lg">
//                   <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
//                     <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
//                   </svg>
//                 </div>
//               </div>
//               <div className="mt-4 pt-4 border-t border-gray-100">
//                 <p className="text-xs text-gray-500">Last Payment: {insights.lastPayroll ? formatCurrency(insights.lastPayroll.netSalary) : 'N/A'}</p>
//               </div>
//             </motion.div>

//             {/* Attendance Card */}
//             <motion.div
//               initial={{ opacity: 0, y: 20 }}
//               animate={{ opacity: 1, y: 0 }}
//               transition={{ duration: 0.3, delay: 0.2 }}
//               className="bg-white rounded-xl shadow-sm p-6 border border-gray-100"
//             >
//               <div className="flex items-center justify-between">
//                 <div>
//                   <p className="text-sm font-medium text-gray-500">Attendance</p>
//                   <p className="text-2xl font-bold text-gray-800 mt-1">
//                     {insights.totalWorkDays} <span className="text-sm font-normal text-gray-500">days</span>
//                   </p>
//                 </div>
//                 <div className="bg-green-100 p-3 rounded-lg">
//                   <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
//                     <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
//                   </svg>
//                 </div>
//               </div>
//               <div className="mt-4 pt-4 border-t border-gray-100">
//                 <p className="text-xs text-gray-500">Current Streak: {insights.currentStreak} days • Avg: {insights.avgHoursPerDay.toFixed(1)} hrs/day</p>
//               </div>
//             </motion.div>

//             {/* Overtime Card */}
//             <motion.div
//               initial={{ opacity: 0, y: 20 }}
//               animate={{ opacity: 1, y: 0 }}
//               transition={{ duration: 0.3, delay: 0.3 }}
//               className="bg-white rounded-xl shadow-sm p-6 border border-gray-100"
//             >
//               <div className="flex items-center justify-between">
//                 <div>
//                   <p className="text-sm font-medium text-gray-500">Overtime</p>
//                   <p className="text-2xl font-bold text-gray-800 mt-1">
//                     {insights.totalOvertime.toFixed(1)} <span className="text-sm font-normal text-gray-500">hours</span>
//                   </p>
//                 </div>
//                 <div className="bg-yellow-100 p-3 rounded-lg">
//                   <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-yellow-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
//                     <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
//                   </svg>
//                 </div>
//               </div>
//               <div className="mt-4 pt-4 border-t border-gray-100">
//                 <p className="text-xs text-gray-500">This Month: {insights.thisMonthAttendance} work days</p>
//               </div>
//             </motion.div>

//             {/* Leaves Card */}
//             <motion.div
//               initial={{ opacity: 0, y: 20 }}
//               animate={{ opacity: 1, y: 0 }}
//               transition={{ duration: 0.3, delay: 0.4 }}
//               className="bg-white rounded-xl shadow-sm p-6 border border-gray-100"
//             >
//               <div className="flex items-center justify-between">
//                 <div>
//                   <p className="text-sm font-medium text-gray-500">Leaves Taken</p>
//                   <p className="text-2xl font-bold text-gray-800 mt-1">
//                     {insights.totalLeaves} <span className="text-sm font-normal text-gray-500">days</span>
//                   </p>
//                 </div>
//                 <div className="bg-red-100 p-3 rounded-lg">
//                   <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
//                     <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
//                   </svg>
//                 </div>
//               </div>
//               <div className="mt-4 pt-4 border-t border-gray-100">
//                 <p className="text-xs text-gray-500">This Month: {insights.thisMonthLeaves} days</p>
//               </div>
//             </motion.div>
//           </div>

//           {/* Charts Section */}
//           <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
//             {/* Attendance Trend */}
//             <motion.div
//               initial={{ opacity: 0, y: 20 }}
//               animate={{ opacity: 1, y: 0 }}
//               transition={{ duration: 0.5, delay: 0.5 }}
//               className="bg-white rounded-xl shadow-sm p-6 border border-gray-100"
//             >
//               <h3 className="text-lg font-semibold text-gray-800 mb-4">Monthly Attendance Trend</h3>
//               <div className="h-64">
//                 <Bar 
//                   data={attendanceChartData}
//                   options={{
//                     responsive: true,
//                     maintainAspectRatio: false,
//                     scales: {
//                       y: {
//                         beginAtZero: true,
//                         ticks: {
//                           precision: 0
//                         }
//                       }
//                     },
//                     plugins: {
//                       legend: {
//                         display: false
//                       }
//                     }
//                   }}
//                 />
//               </div>
//               <p className="text-xs text-gray-500 mt-2 text-center">Work days per month in {new Date().getFullYear()}</p>
//             </motion.div>

//             {/* Leave Distribution */}
//             <motion.div
//               initial={{ opacity: 0, y: 20 }}
//               animate={{ opacity: 1, y: 0 }}
//               transition={{ duration: 0.5, delay: 0.7 }}
//               className="bg-white rounded-xl shadow-sm p-6 border border-gray-100"
//             >
//               <h3 className="text-lg font-semibold text-gray-800 mb-4">Leave Type Distribution</h3>
//               <div className="h-64">
//                 <Pie 
//                   data={leaveTypeChartData}
//                   options={{
//                     responsive: true,
//                     maintainAspectRatio: false,
//                     plugins: {
//                       legend: {
//                         position: 'right'
//                       }
//                     }
//                   }}
//                 />
//               </div>
//               <p className="text-xs text-gray-500 mt-2 text-center">Breakdown of all leaves taken</p>
//             </motion.div>
//           </div>

//           {/* Detailed Insights */}
//           <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
//             {/* Salary Trend */}
//             <motion.div
//               initial={{ opacity: 0, y: 20 }}
//               animate={{ opacity: 1, y: 0 }}
//               transition={{ duration: 0.5, delay: 0.9 }}
//               className="bg-white rounded-xl shadow-sm p-6 border border-gray-100"
//             >
//               <h3 className="text-lg font-semibold text-gray-800 mb-4">Salary Trend</h3>
//               <div className="h-64">
//                 <Line 
//                   data={salaryTrendChartData}
//                   options={{
//                     responsive: true,
//                     maintainAspectRatio: false,
//                     scales: {
//                       y: {
//                         beginAtZero: false,
//                         ticks: {
//                           callback: function(value) {
//                             return formatCurrency(value);
//                           }
//                         }
//                       }
//                     },
//                     plugins: {
//                       tooltip: {
//                         callbacks: {
//                           label: function(context) {
//                             return formatCurrency(context.raw);
//                           }
//                         }
//                       }
//                     }
//                   }}
//                 />
//               </div>
//               <p className="text-xs text-gray-500 mt-2 text-center">Last 6 processed payrolls</p>
//             </motion.div>

//             {/* Leave Balances */}
//             <motion.div
//               initial={{ opacity: 0, y: 20 }}
//               animate={{ opacity: 1, y: 0 }}
//               transition={{ duration: 0.5, delay: 1.1 }}
//               className="bg-white rounded-xl shadow-sm p-6 border border-gray-100"
//             >
//               <h3 className="text-lg font-semibold text-gray-800 mb-4">Leave Balances</h3>
//               <div className="space-y-4">
//                 {/* Casual Leave */}
//                 <div>
//                   <div className="flex justify-between mb-1">
//                     <span className="text-sm font-medium text-blue-700">Casual Leave</span>
//                     <span className="text-sm font-medium text-blue-700">
//                       {insights.remainingCasualLeaves} / 10 days
//                     </span>
//                   </div>
//                   <div className="w-full bg-gray-200 rounded-full h-2.5">
//                     <div 
//                       className="bg-blue-600 h-2.5 rounded-full" 
//                       style={{ width: `${(insights.remainingCasualLeaves / 10) * 100}%` }}
//                     ></div>
//                   </div>
//                 </div>
                
//                 {/* Sick Leave */}
//                 <div>
//                   <div className="flex justify-between mb-1">
//                     <span className="text-sm font-medium text-green-700">Sick Leave</span>
//                     <span className="text-sm font-medium text-green-700">
//                       {insights.remainingSickLeaves} / 10 days
//                     </span>
//                   </div>
//                   <div className="w-full bg-gray-200 rounded-full h-2.5">
//                     <div 
//                       className="bg-green-600 h-2.5 rounded-full" 
//                       style={{ width: `${(insights.remainingSickLeaves / 10) * 100}%` }}
//                     ></div>
//                   </div>
//                 </div>
                
//                 {/* Annual Leave */}
//                 <div>
//                   <div className="flex justify-between mb-1">
//                     <span className="text-sm font-medium text-purple-700">Annual Leave</span>
//                     <span className="text-sm font-medium text-purple-700">
//                       {insights.remainingAnnualLeaves} / 12 days
//                     </span>
//                   </div>
//                   <div className="w-full bg-gray-200 rounded-full h-2.5">
//                     <div 
//                       className="bg-purple-600 h-2.5 rounded-full" 
//                       style={{ width: `${(insights.remainingAnnualLeaves / 12) * 100}%` }}
//                     ></div>
//                   </div>
//                 </div>
//               </div>
              
//               <div className="mt-6 pt-4 border-t border-gray-100">
//                 <h4 className="text-sm font-medium text-gray-800 mb-2">Quick Stats</h4>
//                 <div className="grid grid-cols-2 gap-4 text-sm">
//                   <div>
//                     <p className="text-gray-500">Total Leaves Taken</p>
//                     <p className="font-medium">{insights.totalLeaves}</p>
//                   </div>
//                   <div>
//                     <p className="text-gray-500">Paid Leaves</p>
//                     <p className="font-medium text-green-600">{insights.paidLeaves}</p>
//                   </div>
//                   <div>
//                     <p className="text-gray-500">Unpaid Leaves</p>
//                     <p className="font-medium text-red-600">{insights.unpaidLeaves}</p>
//                   </div>
//                   <div>
//                     <p className="text-gray-500">This Month</p>
//                     <p className="font-medium">{insights.thisMonthLeaves}</p>
//                   </div>
//                 </div>
//               </div>
//             </motion.div>
//           </div>

//           {/* Recent Activity */}
//           <motion.div
//             initial={{ opacity: 0, y: 20 }}
//             animate={{ opacity: 1, y: 0 }}
//             transition={{ duration: 0.5, delay: 1.3 }}
//             className="bg-white rounded-xl shadow-sm p-6 border border-gray-100 mb-6"
//           >
//             <h3 className="text-lg font-semibold text-gray-800 mb-4">Recent Activity</h3>
            
//             <div className="space-y-4">
//               {/* Last Attendance */}
//               <div className="flex items-start">
//                 <div className="bg-blue-100 p-2 rounded-lg mr-4">
//                   <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
//                     <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
//                   </svg>
//                 </div>
//                 <div>
//                   <h4 className="font-medium text-gray-800">Last Attendance</h4>
//                   {insights.lastAttendance ? (
//                     <div className="text-sm text-gray-600 mt-1">
//                       <p>Date: {formatDate(insights.lastAttendance.workDate)}</p>
//                       <p>Check-in: {insights.lastAttendance.checkInTime} • Check-out: {insights.lastAttendance.checkOutTime}</p>
//                       <p>Total: {insights.lastAttendance.totalHours} hours • Overtime: {insights.lastAttendance.overtimeHours || 0} hours</p>
//                     </div>
//                   ) : (
//                     <p className="text-sm text-gray-600 mt-1">No attendance records found</p>
//                   )}
//                 </div>
//               </div>

//               {/* Last Payroll */}
//               <div className="flex items-start">
//                 <div className="bg-green-100 p-2 rounded-lg mr-4">
//                   <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
//                     <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
//                   </svg>
//                 </div>
//                 <div>
//                   <h4 className="font-medium text-gray-800">Last Payroll</h4>
//                   {insights.lastPayroll ? (
//                     <div className="text-sm text-gray-600 mt-1">
//                       <p>Amount: {formatCurrency(insights.lastPayroll.netSalary)}</p>
//                       <p>Processed on: {formatDate(insights.lastPayroll.processedAt)}</p>
//                       <p>Status: <span className="font-medium text-green-600">Processed</span></p>
//                     </div>
//                   ) : (
//                     <p className="text-sm text-gray-600 mt-1">No payroll records found</p>
//                   )}
//                 </div>
//               </div>

//               {/* Bank Details */}
//               <div className="flex items-start">
//                 <div className="bg-purple-100 p-2 rounded-lg mr-4">
//                   <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-purple-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
//                     <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 6l3 1m0 0l-3 9a5.002 5.002 0 006.001 0M6 7l3 9M6 7l6-2m6 2l3-1m-3 1l-3 9a5.002 5.002 0 006.001 0M18 7l3 9m-3-9l-6-2m0-2v2m0 16V5m0 16H9m3 0h3" />
//                   </svg>
//                 </div>
//                 <div>
//                   <h4 className="font-medium text-gray-800">Bank Account</h4>
//                   <div className="text-sm text-gray-600 mt-1">
//                     {employee.bankAccount ? (
//                       <p>Account ending with: ••••{employee.bankAccount.slice(-4)}</p>
//                     ) : (
//                       <p>No bank account on record</p>
//                     )}
//                   </div>
//                 </div>
//               </div>
//             </div>
//           </motion.div>
//         </div>
//       </div>
//       <Footer />
//     </>
//   );
// };

// export default EmployeeAnalyticsDashboard;


import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import HeaderNavbar from '../component/HeaderNavbar';
import Footer from '../component/Footer';
import { motion } from 'framer-motion';
import { Bar, Pie, Line } from 'react-chartjs-2';
import { Chart, registerables } from 'chart.js';
Chart.register(...registerables);

const EmployeeAnalyticsDashboard = () => {
  const [employee, setEmployee] = useState(null);
  const [attendance, setAttendance] = useState([]);
  const [leaves, setLeaves] = useState([]);
  const [payrolls, setPayrolls] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchEmployeeData = async () => {
      try {
        const token = localStorage.getItem('token');
        if (!token) {
          navigate('/login');
          return;
        }

        const config = {
          headers: { Authorization: `Bearer ${token}` }
        };

        // Fetch employee details
        const employeeRes = await axios.get('http://localhost:8080/api/employees/me', config);
        const employeeData = employeeRes.data;
        setEmployee(employeeData);

        // Fetch all data in parallel
        const [attendanceRes, leavesRes, payrollsRes] = await Promise.all([
          axios.get('http://localhost:8080/api/attendance', config),
          axios.get('http://localhost:8080/api/leaves/employee/' + employeeData.id, config),
          axios.get('http://localhost:8080/api/payrolls', config)
        ]);

        // Filter data for current employee
        const filteredAttendance = attendanceRes.data.filter(
          a => a.employee && a.employee.id === employeeData.id
        );
        setAttendance(filteredAttendance);

        setLeaves(leavesRes.data);

        const filteredPayrolls = payrollsRes.data.filter(
          p => p.employeeId === employeeData.id
        );
        setPayrolls(filteredPayrolls);

      } catch (err) {
        setError(err.response?.data?.message || 'Failed to fetch data');
        console.error('Error fetching data:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchEmployeeData();
  }, [navigate]);

  // Calculate insights
  const calculateInsights = () => {
    if (!employee) return {};

    // Attendance calculations
    const totalWorkDays = attendance.length;
    const totalOvertime = attendance.reduce((sum, a) => sum + (a.overtimeHours || 0), 0);
    const totalHours = attendance.reduce((sum, a) => sum + (a.totalHours || 0), 0);
    const avgHoursPerDay = attendance.length > 0 ? totalHours / attendance.length : 0;
    
    // Leave calculations
    const totalLeaves = leaves.length;
    const paidLeaves = leaves.filter(l => l.isPaid).length;
    const unpaidLeaves = totalLeaves - paidLeaves;
    const casualLeavesTaken = leaves.filter(l => l.leaveType === 'CASUAL').length;
    const sickLeavesTaken = leaves.filter(l => l.leaveType === 'SICK').length;
    const annualLeavesTaken = leaves.filter(l => l.leaveType === 'ANNUAL').length;
    
    // Payroll calculations
    const processedPayrolls = payrolls.filter(p => p.paymentStatus === 'PROCESSED');
    const lastPayroll = processedPayrolls.length > 0 
      ? processedPayrolls.reduce((latest, current) => 
          new Date(current.processedAt) > new Date(latest.processedAt) ? current : latest
        ) 
      : null;
      
    const totalSalary = processedPayrolls.reduce((sum, p) => sum + (p.netSalary || 0), 0);
    const avgMonthlySalary = processedPayrolls.length > 0 
      ? totalSalary / processedPayrolls.length 
      : 0;
    
    // Current month data
    const currentMonth = new Date().getMonth();
    const currentYear = new Date().getFullYear();
    
    const thisMonthAttendance = attendance.filter(a => {
      const date = new Date(a.workDate);
      return date.getMonth() === currentMonth && date.getFullYear() === currentYear;
    });
    
    const thisMonthLeaves = leaves.filter(l => {
      const date = new Date(l.leaveDate || l.startDate);
      return date.getMonth() === currentMonth && date.getFullYear() === currentYear;
    });

    // Employment duration
    const joinDate = new Date(employee.joinDate);
    const today = new Date();
    const employmentDurationMonths = (today.getFullYear() - joinDate.getFullYear()) * 12 + 
                                    (today.getMonth() - joinDate.getMonth());

    // Attendance streak
    let currentStreak = 0;
    const sortedAttendance = [...attendance].sort((a, b) => new Date(b.workDate) - new Date(a.workDate));
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    
    for (let i = 0; i < sortedAttendance.length; i++) {
      const attDate = new Date(sortedAttendance[i].workDate);
      if (i === 0 && attDate.toDateString() === yesterday.toDateString()) {
        currentStreak = 1;
      } else if (i > 0) {
        const prevDate = new Date(sortedAttendance[i-1].workDate);
        const dayDiff = (prevDate - attDate) / (1000 * 60 * 60 * 24);
        if (dayDiff === 1) {
          currentStreak++;
        } else {
          break;
        }
      }
    }

    // Monthly attendance data for chart
    const monthlyAttendanceData = Array(12).fill(0);
    attendance.forEach(a => {
      const date = new Date(a.workDate);
      if (date.getFullYear() === currentYear) {
        monthlyAttendanceData[date.getMonth()]++;
      }
    });

    // Leave type distribution for chart
    const leaveTypeData = {
      CASUAL: leaves.filter(l => l.leaveType === 'CASUAL').length,
      SICK: leaves.filter(l => l.leaveType === 'SICK').length,
      ANNUAL: leaves.filter(l => l.leaveType === 'ANNUAL').length,
      UNPAID: unpaidLeaves
    };

    // Process payroll history for chart - sort by processedAt date
    const payrollHistory = processedPayrolls
      .sort((a, b) => new Date(a.processedAt) - new Date(b.processedAt))
      .slice(-6) // Last 6 months
      .map(p => ({
        month: new Date(p.processedAt).toLocaleString('default', { month: 'short' }),
        amount: p.netSalary,
        processedAt: p.processedAt
      }));

    return {
      totalWorkDays,
      totalLeaves,
      paidLeaves,
      unpaidLeaves,
      totalOvertime,
      avgHoursPerDay,
      lastPayroll,
      avgMonthlySalary,
      thisMonthAttendance: thisMonthAttendance.length,
      thisMonthLeaves: thisMonthLeaves.length,
      employmentDuration: employmentDurationMonths,
      remainingCasualLeaves: Math.max(0, 10 - casualLeavesTaken),
      remainingSickLeaves: Math.max(0, 10 - sickLeavesTaken),
      remainingAnnualLeaves: Math.max(0, 12 - annualLeavesTaken),
      lastAttendance: attendance.length > 0 ? attendance[attendance.length - 1] : null,
      currentStreak,
      processedPayrollsCount: processedPayrolls.length,
      pendingPayrolls: payrolls.filter(p => p.paymentStatus === 'PENDING').length,
      basicSalary: lastPayroll?.basicSalary || 0,
      employmentType: employee.employmentType || 'FULL_TIME',
      monthlyAttendanceData,
      leaveTypeData,
      payrollHistory
    };
  };

  const insights = calculateInsights();

  // Chart data
  const attendanceChartData = {
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
    datasets: [
      {
        label: 'Work Days',
        data: insights.monthlyAttendanceData || [],
        backgroundColor: 'rgba(54, 162, 235, 0.5)',
        borderColor: 'rgba(54, 162, 235, 1)',
        borderWidth: 1
      }
    ]
  };

  const leaveTypeChartData = {
    labels: ['Casual', 'Sick', 'Annual', 'Unpaid'],
    datasets: [
      {
        data: [
          insights.leaveTypeData?.CASUAL || 0,
          insights.leaveTypeData?.SICK || 0,
          insights.leaveTypeData?.ANNUAL || 0,
          insights.leaveTypeData?.UNPAID || 0
        ],
        backgroundColor: [
          'rgba(54, 162, 235, 0.5)',
          'rgba(75, 192, 192, 0.5)',
          'rgba(153, 102, 255, 0.5)',
          'rgba(255, 159, 64, 0.5)'
        ],
        borderColor: [
          'rgba(54, 162, 235, 1)',
          'rgba(75, 192, 192, 1)',
          'rgba(153, 102, 255, 1)',
          'rgba(255, 159, 64, 1)'
        ],
        borderWidth: 1
      }
    ]
  };

  const salaryTrendChartData = {
    labels: insights.payrollHistory?.map(p => p.month) || [],
    datasets: [
      {
        label: 'Net Salary',
        data: insights.payrollHistory?.map(p => p.amount) || [],
        fill: false,
        backgroundColor: 'rgba(75, 192, 192, 0.5)',
        borderColor: 'rgba(75, 192, 192, 1)',
        tension: 0.1
      }
    ]
  };

  // Format currency
  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount || 0);
  };

  // Format date
  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    const options = { year: 'numeric', month: 'short', day: 'numeric' };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-xl">Loading your dashboard...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-red-500 text-xl">{error}</div>
      </div>
    );
  }

  if (!employee) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-xl">No employee data found</div>
      </div>
    );
  }

  return (
    <>
      <HeaderNavbar />
      <div className="min-h-[calc(100vh-64px)] bg-[#eaeaea] p-4 md:p-6">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="bg-white rounded-xl shadow-sm p-6 mb-6 border border-gray-100"
          >
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="bg-blue-100 p-3 rounded-full">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                  </svg>
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-gray-800">
                    {employee.firstName} {employee.lastName}
                  </h1>
                  <p className="text-gray-600">
                    {employee.designation} • {employee.department}
                  </p>
                </div>
              </div>
              <div className="mt-4 md:mt-0 grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-gray-500">Employee ID</p>
                  <p className="font-medium">#{employee.id}</p>
                </div>
                <div>
                  <p className="text-gray-500">Join Date</p>
                  <p className="font-medium">{formatDate(employee.joinDate)}</p>
                </div>
                <div>
                  <p className="text-gray-500">Status</p>
                  <p className={`font-medium ${
                    employee.status === 'ACTIVE' ? 'text-green-600' : 'text-red-600'
                  }`}>
                    {employee.status}
                  </p>
                </div>
                <div>
                  <p className="text-gray-500">Employment Type</p>
                  <p className="font-medium capitalize">
                    {employee.employmentType.toLowerCase().replace('_', ' ')}
                  </p>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Key Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            {/* Salary Card */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.1 }}
              className="bg-white rounded-xl shadow-sm p-6 border border-gray-100"
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500">Monthly Salary</p>
                  <p className="text-2xl font-bold text-gray-800 mt-1">
                    {formatCurrency(insights.basicSalary)}
                  </p>
                </div>
                <div className="bg-blue-100 p-3 rounded-lg">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
              </div>
              <div className="mt-4 pt-4 border-t border-gray-100">
                <p className="text-xs text-gray-500">
                  Avg. Salary: {formatCurrency(insights.avgMonthlySalary)} • 
                  Processed: {insights.processedPayrollsCount} payrolls
                </p>
              </div>
            </motion.div>

            {/* Attendance Card */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.2 }}
              className="bg-white rounded-xl shadow-sm p-6 border border-gray-100"
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500">Attendance</p>
                  <p className="text-2xl font-bold text-gray-800 mt-1">
                    {insights.totalWorkDays} <span className="text-sm font-normal text-gray-500">days</span>
                  </p>
                </div>
                <div className="bg-green-100 p-3 rounded-lg">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                  </svg>
                </div>
              </div>
              <div className="mt-4 pt-4 border-t border-gray-100">
                <p className="text-xs text-gray-500">Current Streak: {insights.currentStreak} days • Avg: {insights.avgHoursPerDay.toFixed(1)} hrs/day</p>
              </div>
            </motion.div>

            {/* Overtime Card */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.3 }}
              className="bg-white rounded-xl shadow-sm p-6 border border-gray-100"
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500">Overtime</p>
                  <p className="text-2xl font-bold text-gray-800 mt-1">
                    {insights.totalOvertime.toFixed(1)} <span className="text-sm font-normal text-gray-500">hours</span>
                  </p>
                </div>
                <div className="bg-yellow-100 p-3 rounded-lg">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-yellow-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
              </div>
              <div className="mt-4 pt-4 border-t border-gray-100">
                <p className="text-xs text-gray-500">This Month: {insights.thisMonthAttendance} work days</p>
              </div>
            </motion.div>

            {/* Leaves Card */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.4 }}
              className="bg-white rounded-xl shadow-sm p-6 border border-gray-100"
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500">Leaves Taken</p>
                  <p className="text-2xl font-bold text-gray-800 mt-1">
                    {insights.totalLeaves} <span className="text-sm font-normal text-gray-500">days</span>
                  </p>
                </div>
                <div className="bg-red-100 p-3 rounded-lg">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
                  </svg>
                </div>
              </div>
              <div className="mt-4 pt-4 border-t border-gray-100">
                <p className="text-xs text-gray-500">This Month: {insights.thisMonthLeaves} days</p>
              </div>
            </motion.div>
          </div>

          {/* Charts Section */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
            {/* Attendance Trend */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.5 }}
              className="bg-white rounded-xl shadow-sm p-6 border border-gray-100"
            >
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Monthly Attendance Trend</h3>
              <div className="h-64">
                <Bar 
                  data={attendanceChartData}
                  options={{
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                      y: {
                        beginAtZero: true,
                        ticks: {
                          precision: 0
                        }
                      }
                    },
                    plugins: {
                      legend: {
                        display: false
                      }
                    }
                  }}
                />
              </div>
              <p className="text-xs text-gray-500 mt-2 text-center">Work days per month in {new Date().getFullYear()}</p>
            </motion.div>

            {/* Leave Distribution */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.7 }}
              className="bg-white rounded-xl shadow-sm p-6 border border-gray-100"
            >
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Leave Type Distribution</h3>
              <div className="h-64">
                <Pie 
                  data={leaveTypeChartData}
                  options={{
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                      legend: {
                        position: 'right'
                      }
                    }
                  }}
                />
              </div>
              <p className="text-xs text-gray-500 mt-2 text-center">Breakdown of all leaves taken</p>
            </motion.div>
          </div>

          {/* Detailed Insights */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            {/* Salary Trend */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.9 }}
              className="bg-white rounded-xl shadow-sm p-6 border border-gray-100"
            >
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Salary Trend</h3>
              <div className="h-64">
                <Line 
                  data={salaryTrendChartData}
                  options={{
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                      y: {
                        beginAtZero: false,
                        ticks: {
                          callback: function(value) {
                            return formatCurrency(value);
                          }
                        }
                      }
                    },
                    plugins: {
                      tooltip: {
                        callbacks: {
                          label: function(context) {
                            return formatCurrency(context.raw);
                          }
                        }
                      }
                    }
                  }}
                />
              </div>
              <p className="text-xs text-gray-500 mt-2 text-center">
                Last {insights.payrollHistory?.length || 0} processed payrolls
              </p>
            </motion.div>

            {/* Leave Balances */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 1.1 }}
              className="bg-white rounded-xl shadow-sm p-6 border border-gray-100"
            >
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Leave Balances</h3>
              <div className="space-y-4">
                {/* Casual Leave */}
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-sm font-medium text-blue-700">Casual Leave</span>
                    <span className="text-sm font-medium text-blue-700">
                      {insights.remainingCasualLeaves} / 10 days
                    </span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2.5">
                    <div 
                      className="bg-blue-600 h-2.5 rounded-full" 
                      style={{ width: `${(insights.remainingCasualLeaves / 10) * 100}%` }}
                    ></div>
                  </div>
                </div>
                
                {/* Sick Leave */}
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-sm font-medium text-green-700">Sick Leave</span>
                    <span className="text-sm font-medium text-green-700">
                      {insights.remainingSickLeaves} / 10 days
                    </span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2.5">
                    <div 
                      className="bg-green-600 h-2.5 rounded-full" 
                      style={{ width: `${(insights.remainingSickLeaves / 10) * 100}%` }}
                    ></div>
                  </div>
                </div>
                
                {/* Annual Leave */}
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-sm font-medium text-purple-700">Annual Leave</span>
                    <span className="text-sm font-medium text-purple-700">
                      {insights.remainingAnnualLeaves} / 12 days
                    </span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2.5">
                    <div 
                      className="bg-purple-600 h-2.5 rounded-full" 
                      style={{ width: `${(insights.remainingAnnualLeaves / 12) * 100}%` }}
                    ></div>
                  </div>
                </div>
              </div>
              
              <div className="mt-6 pt-4 border-t border-gray-100">
                <h4 className="text-sm font-medium text-gray-800 mb-2">Quick Stats</h4>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-gray-500">Total Leaves Taken</p>
                    <p className="font-medium">{insights.totalLeaves}</p>
                  </div>
                  <div>
                    <p className="text-gray-500">Paid Leaves</p>
                    <p className="font-medium text-green-600">{insights.paidLeaves}</p>
                  </div>
                  <div>
                    <p className="text-gray-500">Unpaid Leaves</p>
                    <p className="font-medium text-red-600">{insights.unpaidLeaves}</p>
                  </div>
                  <div>
                    <p className="text-gray-500">This Month</p>
                    <p className="font-medium">{insights.thisMonthLeaves}</p>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>

          {/* Recent Activity */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 1.3 }}
            className="bg-white rounded-xl shadow-sm p-6 border border-gray-100 mb-6"
          >
            <h3 className="text-lg font-semibold text-gray-800 mb-4">Recent Activity</h3>
            
            <div className="space-y-4">
              {/* Last Attendance */}
              <div className="flex items-start">
                <div className="bg-blue-100 p-2 rounded-lg mr-4">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
                <div>
                  <h4 className="font-medium text-gray-800">Last Attendance</h4>
                  {insights.lastAttendance ? (
                    <div className="text-sm text-gray-600 mt-1">
                      <p>Date: {formatDate(insights.lastAttendance.workDate)}</p>
                      <p>Check-in: {insights.lastAttendance.checkInTime} • Check-out: {insights.lastAttendance.checkOutTime}</p>
                      <p>Total: {insights.lastAttendance.totalHours} hours • Overtime: {insights.lastAttendance.overtimeHours || 0} hours</p>
                    </div>
                  ) : (
                    <p className="text-sm text-gray-600 mt-1">No attendance records found</p>
                  )}
                </div>
              </div>

              {/* Last Payroll */}
              <div className="flex items-start">
                <div className="bg-green-100 p-2 rounded-lg mr-4">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
                <div>
                  <h4 className="font-medium text-gray-800">Last Payroll</h4>
                  {insights.lastPayroll ? (
                    <div className="text-sm text-gray-600 mt-1">
                      <p>Amount: {formatCurrency(insights.lastPayroll.netSalary)}</p>
                      <p>Basic: {formatCurrency(insights.lastPayroll.basicSalary)} • Allowances: {formatCurrency(insights.lastPayroll.allowances)}</p>
                      <p>Deductions: {formatCurrency(insights.lastPayroll.deductions)} • Processed on: {formatDate(insights.lastPayroll.processedAt)}</p>
                    </div>
                  ) : (
                    <p className="text-sm text-gray-600 mt-1">No payroll records found</p>
                  )}
                </div>
              </div>

              {/* Bank Details */}
              <div className="flex items-start">
                <div className="bg-purple-100 p-2 rounded-lg mr-4">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-purple-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 6l3 1m0 0l-3 9a5.002 5.002 0 006.001 0M6 7l3 9M6 7l6-2m6 2l3-1m-3 1l-3 9a5.002 5.002 0 006.001 0M18 7l3 9m-3-9l-6-2m0-2v2m0 16V5m0 16H9m3 0h3" />
                  </svg>
                </div>
                <div>
                  <h4 className="font-medium text-gray-800">Bank Account</h4>
                  <div className="text-sm text-gray-600 mt-1">
                    {employee.bankAccount ? (
                      <p>Account ending with: ••••{employee.bankAccount.slice(-4)}</p>
                    ) : (
                      <p>No bank account on record</p>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
      <Footer />
    </>
  );
};

export default EmployeeAnalyticsDashboard;