// import React, { useEffect, useState } from 'react';
// import axios from 'axios';
// import Footer from '../component/Footer';
// import {
//   Bar,
//   Pie
// } from 'react-chartjs-2';
// import {
//   Chart as ChartJS,
//   CategoryScale,
//   LinearScale,
//   PointElement,
//   LineElement,
//   BarElement,
//   ArcElement,
//   Tooltip,
//   Legend
// } from 'chart.js';
// import HeaderNavbar from '../component/HeaderNavbar';

// ChartJS.register(
//   CategoryScale,
//   LinearScale,
//   PointElement,
//   LineElement,
//   BarElement,
//   ArcElement,
//   Tooltip,
//   Legend
// );

// const token = localStorage.getItem("token");
// const config = { headers: { Authorization: `Bearer ${token}` } };

// const Reports = () => {
//   const [payrollTrends, setPayrollTrends] = useState([]);
//   const [overtimeTrends, setOvertimeTrends] = useState([]);
//   const [leaveDistribution, setLeaveDistribution] = useState([]);
//   const [loading, setLoading] = useState(true);

//   useEffect(() => {    
//     const fetchData = async () => {
//       try {
//         const [payrollRes, overtimeRes, leaveRes] = await Promise.all([
//           axios.get('http://localhost:8080/api/reports/payroll-trends?year=2025', config),
//           axios.get('http://localhost:8080/api/reports/overtime-trends', config),
//           axios.get('http://localhost:8080/api/reports/leave-distribution', config)
//         ]);

//         setPayrollTrends(payrollRes.data);
//         setOvertimeTrends(overtimeRes.data);
//         setLeaveDistribution(leaveRes.data);
//       } catch (error) {
//         console.error("Error fetching report data:", error);
//       } finally {
//         setLoading(false);
//       }
//     };

//     fetchData();
    
//   }, []);

//   const payrollChartData = {
//     labels: payrollTrends.map(d => `${d.month}/${d.year}`),
//     datasets: [{
//       label: 'Total Salary',
//       data: payrollTrends.map(d => d.totalSalary),
//       backgroundColor: 'rgba(59, 130, 246, 0.5)',
//       borderColor: 'rgba(59, 130, 246, 1)',
//       borderWidth: 1
//     }]
//   };

//   const overtimeChartData = {
//     labels: overtimeTrends.map(d => `${d.year}-${String(d.month).padStart(2, '0')}`),
//     datasets: [{
//       label: 'Overtime Hours',
//       data: overtimeTrends.map(d => d.totalOvertime),
//       backgroundColor: 'rgba(34, 197, 94, 0.5)',
//       borderColor: 'rgba(34, 197, 94, 1)',
//       borderWidth: 1
//     }]
//   };

//   const leaveChartData = {
//     labels: leaveDistribution.map(d => d.leaveType),
//     datasets: [{
//       label: 'Leave Count',
//       data: leaveDistribution.map(d => d.count),
//       backgroundColor: ['#f97316', '#3b82f6', '#10b981', '#8b5cf6']

//     }]
//   };

//   if (loading) return <div className="text-center mt-10">Loading...</div>;
//   return (
//     <>
//     <HeaderNavbar />
//     <div className="bg-gradient-to-br from-blue-100 p-6 space-y-10">
      
//       <h2 className="text-2xl font-bold text-gray-800 text-center mb-8">📊 Reports & Analytics Dashboard</h2>
  
//       {/* FLEX CONTAINER FOR ALL GRAPHS */}
//       <div className="flex flex-wrap justify-center gap-8">
        
//         {/* Payroll Trends */}
//         <div className="bg-white p-4 rounded shadow w-[400px]">
//           <h3 className="text-xl font-semibold mb-2 text-center">Payroll Trends</h3>
//           {payrollTrends.length > 0 ? <Bar data={payrollChartData} /> : <p>No payroll data</p>}
//         </div>
  
//         {/* Overtime Trends */}
//         <div className="bg-white p-4 rounded shadow w-[400px]">
//           <h3 className="text-xl font-semibold mb-2 text-center">Overtime Trends</h3>
//           {overtimeTrends.length > 0 ? <Bar data={overtimeChartData} /> : <p>No overtime data</p>}
//         </div>
  
//         {/* Leave Distribution */}
//         <div className="bg-white p-4 rounded shadow w-[400px]">
//           <h3 className="text-xl font-semibold mb-2 text-center">Leave Type Distribution</h3>
//           {leaveDistribution.length > 0 ? <Pie data={leaveChartData} /> : <p>No leave data</p>}
//         </div>
  
//       </div>
//     </div>
    
//     </>
//   );
  
// };

// export default Reports;

