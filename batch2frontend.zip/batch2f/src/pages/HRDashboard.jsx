// import React, { useEffect, useState } from 'react';
// import axios from 'axios';
// import { useNavigate } from 'react-router-dom';
// import HeaderNavbar from '../component/HeaderNavbar';
// import Footer from '../component/Footer';
// import { motion } from 'framer-motion';
// import { 
//   FaUsers, 
//   FaUserClock, 
//   FaMoneyBillWave, 
//   FaChartLine, 
//   FaCalendarAlt, 
//   FaFileAlt, 
//   FaIdCard, 
//   FaUserCheck,
//   FaUserTimes,
//   FaBusinessTime,
//   FaPercentage,
//   FaBalanceScale
// } from 'react-icons/fa';

// const HRDashboard = () => {
//   const [employees, setEmployees] = useState([]);
//   const [attendance, setAttendance] = useState([]);
//   const [leaves, setLeaves] = useState([]);
//   const [payrolls, setPayrolls] = useState([]);
//   const [transactions, setTransactions] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState(null);
//   const navigate = useNavigate();

//   useEffect(() => {
//     const fetchHRData = async () => {
//       try {
//         const token = localStorage.getItem('token');
//         if (!token) {
//           navigate('/login');
//           return;
//         }

//         const config = {
//           headers: { Authorization: `Bearer ${token}` }
//         };

//         // Fetch all employees
//         const employeesRes = await axios.get('http://localhost:8080/api/employees', config);
//         setEmployees(employeesRes.data);

//         // Fetch all attendance records
//         const attendanceRes = await axios.get('http://localhost:8080/api/attendance', config);
//         setAttendance(attendanceRes.data);

//         // Fetch all leave records
//         const leavesRes = await axios.get('http://localhost:8080/api/leaves', config);
//         setLeaves(leavesRes.data);

//         // Fetch all payroll records
//         const payrollsRes = await axios.get('http://localhost:8080/api/payrolls', config);
//         setPayrolls(payrollsRes.data);

//         // Fetch all transactions
//         const transactionsRes = await axios.get('http://localhost:8080/api/transactions', config);
//         setTransactions(transactionsRes.data);

//       } catch (err) {
//         setError(err.response?.data?.message || 'Failed to fetch HR data');
//         console.error('Error fetching HR data:', err);
//       } finally {
//         setLoading(false);
//       }
//     };

//     fetchHRData();
//   }, [navigate]);

//   // Calculate HR insights
//   const calculateInsights = () => {
//     const currentDate = new Date();
//     const currentMonth = currentDate.getMonth();
//     const currentYear = currentDate.getFullYear();
//     const thirtyDaysAgo = new Date();
//     thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

//     // Employee stats
//     const totalEmployees = employees.length;
//     const activeEmployees = employees.filter(e => e.status === 'ACTIVE').length;
//     const inactiveEmployees = totalEmployees - activeEmployees;

//     // Department distribution
//     const departmentCount = employees.reduce((acc, employee) => {
//       acc[employee.department] = (acc[employee.department] || 0) + 1;
//       return acc;
//     }, {});

//     // Attendance stats
//     const totalAttendance = attendance.length;
//     const recentAttendance = attendance.filter(a => new Date(a.workDate) >= thirtyDaysAgo).length;
//     const avgAttendancePerEmployee = totalEmployees > 0 ? (totalAttendance / totalEmployees).toFixed(2) : 0;
//     const totalOvertime = attendance.reduce((sum, a) => sum + (a.overtimeHours || 0), 0);

//     // Leave stats
//     const totalLeaves = leaves.length;
//     const unpaidLeaves = leaves.filter(l => !l.isPaid).length;

//     // Payroll stats
//     const totalPayrolls = payrolls.length;
//     const totalSalaryPaid = payrolls.reduce((sum, p) => sum + (p.netSalary || 0), 0);
//     const avgSalary = totalEmployees > 0 ? (totalSalaryPaid / totalEmployees).toFixed(2) : 0;
//     const pendingPayrolls = payrolls.filter(p => p.paymentStatus === 'PENDING').length;
//     const processedPayrolls = payrolls.filter(p => p.paymentStatus === 'PROCESSED').length;

//     // Transaction stats
//     const totalTransactions = transactions.length;
//     const successfulTransactions = transactions.filter(t => t.status === 'SUCCESS').length;
//     const failedTransactions = transactions.filter(t => t.status === 'FAILED').length;
//     const pendingTransactions = transactions.filter(t => t.status === 'PENDING').length;
//     const totalAmountTransferred = transactions.reduce((sum, t) => sum + (t.amount || 0), 0);

//     // Current month stats
//     const thisMonthPayrolls = payrolls.filter(p => {
//       const processedDate = new Date(p.processedAt);
//       return processedDate.getMonth() === currentMonth && processedDate.getFullYear() === currentYear;
//     });
//     const thisMonthSalary = thisMonthPayrolls.reduce((sum, p) => sum + (p.netSalary || 0), 0);

//     return {
//       // Employee metrics
//       totalEmployees,
//       activeEmployees,
//       inactiveEmployees,
//       departmentCount,

//       // Attendance metrics
//       totalAttendance,
//       recentAttendance,
//       avgAttendancePerEmployee,
//       totalOvertime,

//       // Leave metrics
//       totalLeaves,
//       unpaidLeaves,

//       // Payroll metrics
//       totalPayrolls,
//       totalSalaryPaid,
//       avgSalary,
//       pendingPayrolls,
//       processedPayrolls,
//       thisMonthSalary,

//       // Transaction metrics
//       totalTransactions,
//       successfulTransactions,
//       failedTransactions,
//       pendingTransactions,
//       totalAmountTransferred
//     };
//   };

//   const insights = calculateInsights();

//   if (loading) {
//     return (
//       <div className="min-h-screen flex items-center justify-center">
//         <div className="text-xl">Loading HR dashboard...</div>
//       </div>
//     );
//   }

//   if (error) {
//     return (
//       <div className="min-h-screen flex items-center justify-center">
//         <div className="text-red-500 text-xl">{error}</div>
//       </div>
//     );
//   }

//   // Helper function to format currency
//   const formatCurrency = (amount) => {
//     return new Intl.NumberFormat('en-IN', {
//       style: 'currency',
//       currency: 'INR'
//     }).format(amount);
//   };

//   // Get top 3 departments
//   const topDepartments = Object.entries(insights.departmentCount)
//     .sort((a, b) => b[1] - a[1])
//     .slice(0, 3);

//   return (
//     <>
//       <HeaderNavbar />
//       <div className="min-h-[calc(100vh-64px)] bg-gray-50 p-6">
//         <div className="max-w-7xl mx-auto">
//           {/* Header */}
//           <motion.div
//             initial={{ opacity: 0, y: -20 }}
//             animate={{ opacity: 1, y: 0 }}
//             transition={{ duration: 0.5 }}
//             className="bg-white rounded-lg shadow-md p-6 mb-6"
//           >
//             <div className="flex flex-col md:flex-row md:items-center md:justify-between">
//               <div className="mb-4 md:mb-0">
//                 <h1 className="text-3xl font-bold text-gray-800">
//                   HR Dashboard
//                 </h1>
//                 <p className="text-gray-600 mt-2">
//                   Comprehensive overview of workforce management
//                 </p>
//               </div>
//               <div className="flex flex-col items-end">
//                 <div className="px-3 py-1 rounded-full bg-blue-100 text-blue-800 text-sm font-medium">
//                   HR Administrator
//                 </div>
//                 <p className="text-sm text-gray-500 mt-2">
//                   Last updated: {new Date().toLocaleString()}
//                 </p>
//               </div>
//             </div>
//           </motion.div>

//           {/* Main Grid */}
//           <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
//             {/* Employee Overview Card */}
//             <motion.div
//               initial={{ opacity: 0, y: 20 }}
//               animate={{ opacity: 1, y: 0 }}
//               transition={{ duration: 0.5, delay: 0.1 }}
//               className="bg-white rounded-lg shadow-md p-6"
//             >
//               <div className="flex items-center mb-4">
//                 <div className="p-3 rounded-full bg-blue-100 text-blue-600 mr-3">
//                   <FaUsers size={20} />
//                 </div>
//                 <h3 className="text-lg font-semibold text-gray-800">Employee Overview</h3>
//               </div>
//               <div className="space-y-3">
//                 <div className="flex justify-between">
//                   <span className="text-gray-600">Total Employees</span>
//                   <span className="font-medium">{insights.totalEmployees}</span>
//                 </div>
//                 <div className="flex justify-between">
//                   <span className="text-gray-600">Active</span>
//                   <span className="font-medium text-green-600">{insights.activeEmployees}</span>
//                 </div>
//                 <div className="flex justify-between">
//                   <span className="text-gray-600">Inactive</span>
//                   <span className="font-medium text-red-600">{insights.inactiveEmployees}</span>
//                 </div>
//                 <div className="pt-2 border-t">
//                   <h4 className="text-sm font-medium text-gray-600 mb-2">Top Departments</h4>
//                   {topDepartments.map(([dept, count]) => (
//                     <div key={dept} className="flex justify-between mb-1">
//                       <span className="text-sm text-gray-600">{dept}</span>
//                       <span className="text-sm font-medium">{count}</span>
//                     </div>
//                   ))}
//                 </div>
//               </div>
//             </motion.div>

//             {/* Attendance Summary Card */}
//             <motion.div
//               initial={{ opacity: 0, y: 20 }}
//               animate={{ opacity: 1, y: 0 }}
//               transition={{ duration: 0.5, delay: 0.2 }}
//               className="bg-white rounded-lg shadow-md p-6"
//             >
//               <div className="flex items-center mb-4">
//                 <div className="p-3 rounded-full bg-green-100 text-green-600 mr-3">
//                   <FaUserClock size={20} />
//                 </div>
//                 <h3 className="text-lg font-semibold text-gray-800">Attendance Summary</h3>
//               </div>
//               <div className="space-y-3">
//                 <div className="flex justify-between">
//                   <span className="text-gray-600">Total Records</span>
//                   <span className="font-medium">{insights.totalAttendance}</span>
//                 </div>
//                 <div className="flex justify-between">
//                   <span className="text-gray-600">Recent (30 days)</span>
//                   <span className="font-medium">{insights.recentAttendance}</span>
//                 </div>
//                 <div className="flex justify-between">
//                   <span className="text-gray-600">Avg per Employee</span>
//                   <span className="font-medium">{insights.avgAttendancePerEmployee}</span>
//                 </div>
//                 <div className="flex justify-between">
//                   <span className="text-gray-600">Total Overtime</span>
//                   <span className="font-medium">{insights.totalOvertime.toFixed(2)} hrs</span>
//                 </div>
//                 <div className="pt-2 border-t">
//                   <div className="flex justify-between">
//                     <span className="text-sm text-gray-600">Attendance Rate</span>
//                     <span className="text-sm font-medium">
//                       {insights.totalEmployees > 0 
//                         ? `${((insights.totalAttendance / (insights.totalAttendance + insights.totalLeaves)) * 100).toFixed(2)}%` 
//                         : 'N/A'}
//                     </span>
//                   </div>
//                 </div>
//               </div>
//             </motion.div>

//             {/* Payroll Overview Card */}
//             <motion.div
//               initial={{ opacity: 0, y: 20 }}
//               animate={{ opacity: 1, y: 0 }}
//               transition={{ duration: 0.5, delay: 0.3 }}
//               className="bg-white rounded-lg shadow-md p-6"
//             >
//               <div className="flex items-center mb-4">
//                 <div className="p-3 rounded-full bg-purple-100 text-purple-600 mr-3">
//                   <FaMoneyBillWave size={20} />
//                 </div>
//                 <h3 className="text-lg font-semibold text-gray-800">Payroll Overview</h3>
//               </div>
//               <div className="space-y-3">
//                 <div className="flex justify-between">
//                   <span className="text-gray-600">Total Processed</span>
//                   <span className="font-medium">{insights.totalPayrolls}</span>
//                 </div>
//                 <div className="flex justify-between">
//                   <span className="text-gray-600">Total Salary Paid</span>
//                   <span className="font-medium">{formatCurrency(insights.totalSalaryPaid)}</span>
//                 </div>
//                 <div className="flex justify-between">
//                   <span className="text-gray-600">Avg Salary</span>
//                   <span className="font-medium">{formatCurrency(insights.avgSalary)}</span>
//                 </div>
//                 <div className="flex justify-between">
//                   <span className="text-gray-600">This Month Salary</span>
//                   <span className="font-medium">{formatCurrency(insights.thisMonthSalary)}</span>
//                 </div>
//                 <div className="pt-2 border-t">
//                   <div className="flex justify-between">
//                     <span className="text-sm text-gray-600">Pending</span>
//                     <span className="text-sm font-medium text-yellow-600">{insights.pendingPayrolls}</span>
//                   </div>
//                   <div className="flex justify-between">
//                     <span className="text-sm text-gray-600">Processed</span>
//                     <span className="text-sm font-medium text-green-600">{insights.processedPayrolls}</span>
//                   </div>
//                 </div>
//               </div>
//             </motion.div>

//             {/* Leave Management Card */}
//             <motion.div
//               initial={{ opacity: 0, y: 20 }}
//               animate={{ opacity: 1, y: 0 }}
//               transition={{ duration: 0.5, delay: 0.4 }}
//               className="bg-white rounded-lg shadow-md p-6"
//             >
//               <div className="flex items-center mb-4">
//                 <div className="p-3 rounded-full bg-yellow-100 text-yellow-600 mr-3">
//                   <FaCalendarAlt size={20} />
//                 </div>
//                 <h3 className="text-lg font-semibold text-gray-800">Leave Management</h3>
//               </div>
//               <div className="space-y-3">
//                 <div className="flex justify-between">
//                   <span className="text-gray-600">Total Leaves</span>
//                   <span className="font-medium">{insights.totalLeaves}</span>
//                 </div>
//                 <div className="flex justify-between">
//                   <span className="text-gray-600">Unpaid Leaves</span>
//                   <span className="font-medium">{insights.unpaidLeaves}</span>
//                 </div>
//                 <div className="pt-2 border-t">
//                   <div className="flex justify-between">
//                     <span className="text-sm text-gray-600">Leave Utilization</span>
//                     <span className="text-sm font-medium">
//                       {insights.totalEmployees > 0 
//                         ? `${((insights.totalLeaves / (insights.totalEmployees * 20)) * 100).toFixed(2)}%` 
//                         : 'N/A'}
//                     </span>
//                   </div>
//                 </div>
//               </div>
//             </motion.div>

//             {/* Transaction Summary Card */}
//             <motion.div
//               initial={{ opacity: 0, y: 20 }}
//               animate={{ opacity: 1, y: 0 }}
//               transition={{ duration: 0.5, delay: 0.5 }}
//               className="bg-white rounded-lg shadow-md p-6"
//             >
//               <div className="flex items-center mb-4">
//                 <div className="p-3 rounded-full bg-red-100 text-red-600 mr-3">
//                   <FaFileAlt size={20} />
//                 </div>
//                 <h3 className="text-lg font-semibold text-gray-800">Transaction Summary</h3>
//               </div>
//               <div className="space-y-3">
//                 <div className="flex justify-between">
//                   <span className="text-gray-600">Total Transactions</span>
//                   <span className="font-medium">{insights.totalTransactions}</span>
//                 </div>
//                 <div className="flex justify-between">
//                   <span className="text-gray-600">Total Amount</span>
//                   <span className="font-medium">{formatCurrency(insights.totalAmountTransferred)}</span>
//                 </div>
//                 <div className="flex justify-between">
//                   <span className="text-gray-600">Successful</span>
//                   <span className="font-medium text-green-600">{insights.successfulTransactions}</span>
//                 </div>
//                 <div className="flex justify-between">
//                   <span className="text-gray-600">Failed</span>
//                   <span className="font-medium text-red-600">{insights.failedTransactions}</span>
//                 </div>
//                 <div className="flex justify-between">
//                   <span className="text-gray-600">Pending</span>
//                   <span className="font-medium text-yellow-600">{insights.pendingTransactions}</span>
//                 </div>
//                 <div className="pt-2 border-t">
//                   <div className="flex justify-between">
//                     <span className="text-sm text-gray-600">Success Rate</span>
//                     <span className="text-sm font-medium">
//                       {insights.totalTransactions > 0 
//                         ? `${((insights.successfulTransactions / insights.totalTransactions) * 100).toFixed(2)}%` 
//                         : 'N/A'}
//                     </span>
//                   </div>
//                 </div>
//               </div>
//             </motion.div>

//             {/* Workforce Analytics Card */}
//             <motion.div
//               initial={{ opacity: 0, y: 20 }}
//               animate={{ opacity: 1, y: 0 }}
//               transition={{ duration: 0.5, delay: 0.6 }}
//               className="bg-white rounded-lg shadow-md p-6"
//             >
//               <div className="flex items-center mb-4">
//                 <div className="p-3 rounded-full bg-indigo-100 text-indigo-600 mr-3">
//                   <FaChartLine size={20} />
//                 </div>
//                 <h3 className="text-lg font-semibold text-gray-800">Workforce Analytics</h3>
//               </div>
//               <div className="space-y-4">
//                 <div>
//                   <div className="flex justify-between mb-1">
//                     <span className="text-sm font-medium text-gray-600">Employee Retention</span>
//                     <span className="text-sm font-medium">
//                       {insights.totalEmployees > 0 
//                         ? `${((insights.activeEmployees / insights.totalEmployees) * 100).toFixed(2)}%` 
//                         : 'N/A'}
//                     </span>
//                   </div>
//                   <div className="w-full bg-gray-200 rounded-full h-2">
//                     <div 
//                       className="bg-blue-600 h-2 rounded-full" 
//                       style={{ 
//                         width: insights.totalEmployees > 0 
//                           ? `${(insights.activeEmployees / insights.totalEmployees) * 100}%` 
//                           : '0%'
//                       }}
//                     ></div>
//                   </div>
//                 </div>
//                 <div>
//                   <div className="flex justify-between mb-1">
//                     <span className="text-sm font-medium text-gray-600">Overtime Utilization</span>
//                     <span className="text-sm font-medium">
//                       {insights.totalOvertime.toFixed(2)} hrs
//                     </span>
//                   </div>
//                   <div className="w-full bg-gray-200 rounded-full h-2">
//                     <div 
//                       className="bg-green-600 h-2 rounded-full" 
//                       style={{ 
//                         width: `${Math.min(100, (insights.totalOvertime / (insights.totalEmployees * 40)) * 100)}%` 
//                       }}
//                     ></div>
//                   </div>
//                 </div>
//                 <div>
//                   <div className="flex justify-between mb-1">
//                     <span className="text-sm font-medium text-gray-600">Payroll Accuracy</span>
//                     <span className="text-sm font-medium">
//                       {insights.totalTransactions > 0 
//                         ? `${((insights.successfulTransactions / insights.totalTransactions) * 100).toFixed(2)}%` 
//                         : 'N/A'}
//                     </span>
//                   </div>
//                   <div className="w-full bg-gray-200 rounded-full h-2">
//                     <div 
//                       className="bg-purple-600 h-2 rounded-full" 
//                       style={{ 
//                         width: insights.totalTransactions > 0 
//                           ? `${(insights.successfulTransactions / insights.totalTransactions) * 100}%` 
//                           : '0%'
//                       }}
//                     ></div>
//                   </div>
//                 </div>
//                 <div className="pt-2 border-t">
//                   <div className="flex justify-between">
//                     <span className="text-sm text-gray-600">Active Employees</span>
//                     <span className="text-sm font-medium">
//                       {((insights.activeEmployees / insights.totalEmployees) * 100).toFixed(2)}%
//                     </span>
//                   </div>
//                   <div className="flex justify-between">
//                     <span className="text-sm text-gray-600">Payroll Success Rate</span>
//                     <span className="text-sm font-medium">
//                       {insights.totalTransactions > 0 
//                         ? `${((insights.successfulTransactions / insights.totalTransactions) * 100).toFixed(2)}%` 
//                         : 'N/A'}
//                     </span>
//                   </div>
//                 </div>
//               </div>
//             </motion.div>

//             {/* Quick Actions Card */}
//             <motion.div
//               initial={{ opacity: 0, y: 20 }}
//               animate={{ opacity: 1, y: 0 }}
//               transition={{ duration: 0.5, delay: 0.7 }}
//               className="bg-white rounded-lg shadow-md p-6"
//             >
//               <div className="flex items-center mb-4">
//                 <div className="p-3 rounded-full bg-pink-100 text-pink-600 mr-3">
//                   <FaIdCard size={20} />
//                 </div>
//                 <h3 className="text-lg font-semibold text-gray-800">Quick Actions</h3>
//               </div>
//               <div className="grid grid-cols-2 gap-3">
//                 <button 
//                   onClick={() => navigate('/employee-management')}
//                   className="bg-blue-100 text-blue-800 p-3 rounded-lg text-sm font-medium hover:bg-blue-200 transition"
//                 >
//                   Manage Employees
//                 </button>
//                 <button 
//                   onClick={() => navigate('/payroll')}
//                   className="bg-green-100 text-green-800 p-3 rounded-lg text-sm font-medium hover:bg-green-200 transition"
//                 >
//                   Process Payroll
//                 </button>
//                 <button 
//                   onClick={() => navigate('/leave-records')}
//                   className="bg-purple-100 text-purple-800 p-3 rounded-lg text-sm font-medium hover:bg-purple-200 transition"
//                 >
//                   Approve Leaves
//                 </button>
//                 <button 
//                   onClick={() => navigate('/transaction-status')}
//                   className="bg-indigo-100 text-indigo-800 p-3 rounded-lg text-sm font-medium hover:bg-indigo-200 transition"
//                 >
//                   View Transactions
//                 </button>
//                 <button 
//                   onClick={() => navigate('/reports')}
//                   className="bg-yellow-100 text-yellow-800 p-3 rounded-lg text-sm font-medium hover:bg-yellow-200 transition"
//                 >
//                   Generate Reports
//                 </button>
//                 <button 
//                   onClick={() => navigate('/employee-management/add')}
//                   className="bg-teal-100 text-teal-800 p-3 rounded-lg text-sm font-medium hover:bg-teal-200 transition"
//                 >
//                   Add New Employee
//                 </button>
//               </div>
//             </motion.div>

//             {/* Recent Activity Card */}
//             <motion.div
//               initial={{ opacity: 0, y: 20 }}
//               animate={{ opacity: 1, y: 0 }}
//               transition={{ duration: 0.5, delay: 0.8 }}
//               className="bg-white rounded-lg shadow-md p-6"
//             >
//               <div className="flex items-center mb-4">
//                 <div className="p-3 rounded-full bg-teal-100 text-teal-600 mr-3">
//                   <FaBusinessTime size={20} />
//                 </div>
//                 <h3 className="text-lg font-semibold text-gray-800">Recent Activity</h3>
//               </div>
//               <div className="space-y-4">
//                 <div>
//                   <div className="flex justify-between">
//                     <span className="text-sm font-medium text-gray-600">Recent Attendance</span>
//                     <span className="text-sm font-medium">{insights.recentAttendance}</span>
//                   </div>
//                   <div className="w-full bg-gray-200 rounded-full h-1 mt-1">
//                     <div 
//                       className="bg-blue-600 h-1 rounded-full" 
//                       style={{ width: `${Math.min(100, (insights.recentAttendance / 10) * 100)}%` }}
//                     ></div>
//                   </div>
//                 </div>
//                 <div>
//                   <div className="flex justify-between">
//                     <span className="text-sm font-medium text-gray-600">Pending Payrolls</span>
//                     <span className="text-sm font-medium">{insights.pendingPayrolls}</span>
//                   </div>
//                   <div className="w-full bg-gray-200 rounded-full h-1 mt-1">
//                     <div 
//                       className="bg-purple-600 h-1 rounded-full" 
//                       style={{ width: `${Math.min(100, (insights.pendingPayrolls / 10) * 100)}%` }}
//                     ></div>
//                   </div>
//                 </div>
//                 <div>
//                   <div className="flex justify-between">
//                     <span className="text-sm font-medium text-gray-600">Failed Transactions</span>
//                     <span className="text-sm font-medium">{insights.failedTransactions}</span>
//                   </div>
//                   <div className="w-full bg-gray-200 rounded-full h-1 mt-1">
//                     <div 
//                       className="bg-red-600 h-1 rounded-full" 
//                       style={{ width: `${Math.min(100, (insights.failedTransactions / 10) * 100)}%` }}
//                     ></div>
//                   </div>
//                 </div>
//               </div>
//             </motion.div>

//             {/* Performance Metrics Card */}
//             <motion.div
//               initial={{ opacity: 0, y: 20 }}
//               animate={{ opacity: 1, y: 0 }}
//               transition={{ duration: 0.5, delay: 0.9 }}
//               className="bg-white rounded-lg shadow-md p-6"
//             >
//               <div className="flex items-center mb-4">
//                 <div className="p-3 rounded-full bg-orange-100 text-orange-600 mr-3">
//                   <FaPercentage size={20} />
//                 </div>
//                 <h3 className="text-lg font-semibold text-gray-800">Performance Metrics</h3>
//               </div>
//               <div className="space-y-4">
//                 <div>
//                   <div className="flex justify-between mb-1">
//                     <span className="text-sm font-medium text-gray-600">Employee Retention</span>
//                     <span className="text-sm font-medium">
//                       {insights.totalEmployees > 0 
//                         ? `${((insights.activeEmployees / insights.totalEmployees) * 100).toFixed(2)}%` 
//                         : 'N/A'}
//                     </span>
//                   </div>
//                   <div className="w-full bg-gray-200 rounded-full h-2">
//                     <div 
//                       className="bg-green-600 h-2 rounded-full" 
//                       style={{ 
//                         width: insights.totalEmployees > 0 
//                           ? `${(insights.activeEmployees / insights.totalEmployees) * 100}%` 
//                           : '0%'
//                       }}
//                     ></div>
//                   </div>
//                 </div>
//                 <div>
//                   <div className="flex justify-between mb-1">
//                     <span className="text-sm font-medium text-gray-600">Payroll Accuracy</span>
//                     <span className="text-sm font-medium">
//                       {insights.totalTransactions > 0 
//                         ? `${((insights.successfulTransactions / insights.totalTransactions) * 100).toFixed(2)}%` 
//                         : 'N/A'}
//                     </span>
//                   </div>
//                   <div className="w-full bg-gray-200 rounded-full h-2">
//                     <div 
//                       className="bg-blue-600 h-2 rounded-full" 
//                       style={{ 
//                         width: insights.totalTransactions > 0 
//                           ? `${(insights.successfulTransactions / insights.totalTransactions) * 100}%` 
//                           : '0%'
//                       }}
//                     ></div>
//                   </div>
//                 </div>
//                 <div className="pt-2 border-t">
//                   <div className="flex justify-between">
//                     <span className="text-sm text-gray-600">Overtime Utilization</span>
//                     <span className="text-sm font-medium">
//                       {insights.totalEmployees > 0 
//                         ? `${(insights.totalOvertime / (insights.totalEmployees * 40)).toFixed(2)}%` 
//                         : 'N/A'}
//                     </span>
//                   </div>
//                   <div className="flex justify-between">
//                     <span className="text-sm text-gray-600">Attendance Rate</span>
//                     <span className="text-sm font-medium">
//                       {insights.totalEmployees > 0 
//                         ? `${((insights.totalAttendance / (insights.totalAttendance + insights.totalLeaves)) * 100).toFixed(2)}%` 
//                         : 'N/A'}
//                     </span>
//                   </div>
//                 </div>
//               </div>
//             </motion.div>
//           </div>
//         </div>
//       </div>
//       <Footer />
//     </>
//   );
// };

// export default HRDashboard;

import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import HeaderNavbar from '../component/HeaderNavbar';
import Footer from '../component/Footer';
import { motion } from 'framer-motion';
import { 
  FaUsers, 
  FaUserClock, 
  FaMoneyBillWave, 
  FaChartLine, 
  FaCalendarAlt, 
  FaFileAlt, 
  FaIdCard, 
  FaUserCheck,
  FaUserTimes,
  FaBusinessTime,
  FaPercentage,
  FaBalanceScale,
  FaSearch,
  FaUser,
  FaMoneyBill,
  FaClock,
  FaCalendarDay,
  FaPhone,
  FaEnvelope,
  FaBuilding,
  FaBriefcase,
  FaCalendar,
  FaCreditCard
} from 'react-icons/fa';

const HRDashboard = () => {
  const [employees, setEmployees] = useState([]);
  const [attendance, setAttendance] = useState([]);
  const [leaves, setLeaves] = useState([]);
  const [payrolls, setPayrolls] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [employeeId, setEmployeeId] = useState('');
  const [employeeDetails, setEmployeeDetails] = useState(null);
  const [employeePayrolls, setEmployeePayrolls] = useState([]);
  const [employeeAttendance, setEmployeeAttendance] = useState([]);
  const [employeeLeaves, setEmployeeLeaves] = useState([]);
  const [searchLoading, setSearchLoading] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchHRData = async () => {
      try {
        const token = localStorage.getItem('token');
        if (!token) {
          navigate('/login');
          return;
        }

        const config = {
          headers: { Authorization: `Bearer ${token}` }
        };

        // Fetch all employees
        const employeesRes = await axios.get('http://localhost:8080/api/employees', config);
        setEmployees(employeesRes.data);

        // Fetch all attendance records
        const attendanceRes = await axios.get('http://localhost:8080/api/attendance', config);
        setAttendance(attendanceRes.data);

        // Fetch all leave records
        const leavesRes = await axios.get('http://localhost:8080/api/leaves', config);
        setLeaves(leavesRes.data);

        // Fetch all payroll records
        const payrollsRes = await axios.get('http://localhost:8080/api/payrolls', config);
        setPayrolls(payrollsRes.data);

        // Fetch all transactions
        const transactionsRes = await axios.get('http://localhost:8080/api/transactions', config);
        setTransactions(transactionsRes.data);

      } catch (err) {
        setError(err.response?.data?.message || 'Failed to fetch HR data');
        console.error('Error fetching HR data:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchHRData();
  }, [navigate]);

  const fetchEmployeeDetails = async () => {
    if (!employeeId) return;
    
    setSearchLoading(true);
    try {
      const token = localStorage.getItem('token');
      const config = {
        headers: { Authorization: `Bearer ${token}` }
      };

      // Fetch employee details
      const employeeRes = await axios.get(`http://localhost:8080/api/employees/${employeeId}`, config);
      setEmployeeDetails(employeeRes.data);

      // Fetch employee payrolls
      const payrollsRes = await axios.get(`http://localhost:8080/api/payrolls`, config);
      const filteredPayrolls = payrollsRes.data.filter(p => p.employeeId == employeeId);
      setEmployeePayrolls(filteredPayrolls);

      // Fetch employee attendance
      const attendanceRes = await axios.get(`http://localhost:8080/api/attendance`, config);
      const filteredAttendance = attendanceRes.data.filter(a => a.employee.id == employeeId);
      setEmployeeAttendance(filteredAttendance);

      // Fetch employee leaves
      const leavesRes = await axios.get(`http://localhost:8080/api/leaves/employee/${employeeId}`, config);
      setEmployeeLeaves(leavesRes.data);

    } catch (err) {
      setError(err.response?.data?.message || 'Failed to fetch employee data');
      console.error('Error fetching employee data:', err);
      setEmployeeDetails(null);
      setEmployeePayrolls([]);
      setEmployeeAttendance([]);
      setEmployeeLeaves([]);
    } finally {
      setSearchLoading(false);
    }
  };

  // Calculate HR insights
  const calculateInsights = () => {
    const currentDate = new Date();
    const currentMonth = currentDate.getMonth();
    const currentYear = currentDate.getFullYear();
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

    // Employee stats
    const totalEmployees = employees.length;
    const activeEmployees = employees.filter(e => e.status === 'ACTIVE').length;
    const inactiveEmployees = totalEmployees - activeEmployees;

    // Department distribution
    const departmentCount = employees.reduce((acc, employee) => {
      acc[employee.department] = (acc[employee.department] || 0) + 1;
      return acc;
    }, {});

    // Attendance stats
    const totalAttendance = attendance.length;
    const recentAttendance = attendance.filter(a => new Date(a.workDate) >= thirtyDaysAgo).length;
    const avgAttendancePerEmployee = totalEmployees > 0 ? (totalAttendance / totalEmployees).toFixed(2) : 0;
    const totalOvertime = attendance.reduce((sum, a) => sum + (a.overtimeHours || 0), 0);

    // Leave stats
    const totalLeaves = leaves.length;
    const unpaidLeaves = leaves.filter(l => !l.isPaid).length;

    // Payroll stats
    const totalPayrolls = payrolls.length;
    const totalSalaryPaid = payrolls.reduce((sum, p) => sum + (p.netSalary || 0), 0);
    const avgSalary = totalEmployees > 0 ? (totalSalaryPaid / totalEmployees).toFixed(2) : 0;
    const pendingPayrolls = payrolls.filter(p => p.paymentStatus === 'PENDING').length;
    const processedPayrolls = payrolls.filter(p => p.paymentStatus === 'PROCESSED').length;

    // Transaction stats
    const totalTransactions = transactions.length;
    const successfulTransactions = transactions.filter(t => t.status === 'SUCCESS').length;
    const failedTransactions = transactions.filter(t => t.status === 'FAILED').length;
    const pendingTransactions = transactions.filter(t => t.status === 'PENDING').length;
    const totalAmountTransferred = transactions.reduce((sum, t) => sum + (t.amount || 0), 0);

    // Current month stats
    const thisMonthPayrolls = payrolls.filter(p => {
      const processedDate = new Date(p.processedAt);
      return processedDate.getMonth() === currentMonth && processedDate.getFullYear() === currentYear;
    });
    const thisMonthSalary = thisMonthPayrolls.reduce((sum, p) => sum + (p.netSalary || 0), 0);

    return {
      // Employee metrics
      totalEmployees,
      activeEmployees,
      inactiveEmployees,
      departmentCount,

      // Attendance metrics
      totalAttendance,
      recentAttendance,
      avgAttendancePerEmployee,
      totalOvertime,

      // Leave metrics
      totalLeaves,
      unpaidLeaves,

      // Payroll metrics
      totalPayrolls,
      totalSalaryPaid,
      avgSalary,
      pendingPayrolls,
      processedPayrolls,
      thisMonthSalary,

      // Transaction metrics
      totalTransactions,
      successfulTransactions,
      failedTransactions,
      pendingTransactions,
      totalAmountTransferred
    };
  };

  const insights = calculateInsights();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-xl">Loading HR dashboard...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-red-500 text-xl">{error}</div>
      </div>
    );
  }

  // Helper function to format currency
  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR'
    }).format(amount);
  };

  // Get top 3 departments
  const topDepartments = Object.entries(insights.departmentCount)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 3);

  return (
    <>
      <HeaderNavbar />
      <div className="min-h-[calc(100vh-64px)] bg-[#eaeaea] p-6">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="bg-white rounded-lg shadow-md p-6 mb-6"
          >
            <div className="flex flex-col md:flex-row md:items-center md:justify-between">
              <div className="mb-4 md:mb-0">
                <h1 className="text-3xl font-bold text-gray-800">
                  HR Dashboard
                </h1>
                <p className="text-gray-600 mt-2">
                  Comprehensive overview of workforce management
                </p>
              </div>
              <div className="flex flex-col items-end">
                <div className="px-3 py-1 rounded-full bg-blue-100 text-blue-800 text-sm font-medium">
                  HR Administrator
                </div>
                <p className="text-sm text-gray-500 mt-2">
                  Last updated: {new Date().toLocaleString()}
                </p>
              </div>
            </div>
          </motion.div>

          {/* Employee Lookup Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="bg-white rounded-lg shadow-md p-6 mb-6"
          >
            <div className="flex items-center mb-4">
              <div className="p-3 rounded-full bg-indigo-100 text-indigo-600 mr-3">
                <FaSearch size={20} />
              </div>
              <h3 className="text-lg font-semibold text-gray-800">Employee Lookup</h3>
            </div>
            
            <div className="flex flex-col md:flex-row md:items-center gap-4 mb-4">
              <div className="flex-1">
                <label htmlFor="employeeId" className="block text-sm font-medium text-gray-700 mb-1">
                  Enter Employee ID
                </label>
                <input
                  type="text"
                  id="employeeId"
                  value={employeeId}
                  onChange={(e) => setEmployeeId(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  placeholder="e.g. 1, 2, 3..."
                />
              </div>
              <div className="mt-4 md:mt-6">
                <button
                  onClick={fetchEmployeeDetails}
                  disabled={searchLoading || !employeeId}
                  className={`px-4 py-2 rounded-md text-white ${searchLoading || !employeeId ? 'bg-indigo-300 cursor-not-allowed' : 'bg-indigo-600 hover:bg-indigo-700'}`}
                >
                  {searchLoading ? 'Searching...' : 'Search'}
                </button>
              </div>
            </div>

            {employeeDetails && (
              <div className="mt-6 border-t pt-4">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  {/* Employee Details Card */}
                  <div className="bg-blue-50 rounded-lg p-4">
                    <div className="flex items-center mb-2">
                      <FaUser className="text-blue-600 mr-2" />
                      <h4 className="font-medium text-gray-800">Employee Details</h4>
                    </div>
                    <div className="text-sm space-y-2">
                      <p className="flex items-center">
                        <FaUser className="text-blue-500 mr-2" />
                        <span className="font-medium">Name:</span> {employeeDetails.firstName} {employeeDetails.lastName}
                      </p>
                      <p className="flex items-center">
                        <FaBuilding className="text-blue-500 mr-2" />
                        <span className="font-medium">Department:</span> {employeeDetails.department}
                      </p>
                      <p className="flex items-center">
                        <FaBriefcase className="text-blue-500 mr-2" />
                        <span className="font-medium">Designation:</span> {employeeDetails.designation}
                      </p>
                      <p className="flex items-center">
                        <span className="font-medium">Status:</span> 
                        <span className={`ml-1 px-2 py-1 rounded-full text-xs ${employeeDetails.status === 'ACTIVE' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                          {employeeDetails.status}
                        </span>
                      </p>
                      <p className="flex items-center">
                        <FaEnvelope className="text-blue-500 mr-2" />
                        <span className="font-medium">Email:</span> {employeeDetails.email}
                      </p>
                      <p className="flex items-center">
                        <FaPhone className="text-blue-500 mr-2" />
                        <span className="font-medium">Phone:</span> {employeeDetails.phone}
                      </p>
                      <p className="flex items-center">
                        <FaCalendar className="text-blue-500 mr-2" />
                        <span className="font-medium">Join Date:</span> {new Date(employeeDetails.joinDate).toLocaleDateString()}
                      </p>
                      <p className="flex items-center">
                        <FaCreditCard className="text-blue-500 mr-2" />
                        <span className="font-medium">Bank Account:</span> {employeeDetails.bankAccount}
                      </p>
                    </div>
                  </div>

                  {/* Payroll Summary Card */}
                  <div className="bg-purple-50 rounded-lg p-4">
                    <div className="flex items-center mb-2">
                      <FaMoneyBill className="text-purple-600 mr-2" />
                      <h4 className="font-medium text-gray-800">Payroll Summary</h4>
                    </div>
                    <div className="text-sm space-y-2">
                      <p><span className="font-medium">Total Payrolls:</span> {employeePayrolls.length}</p>
                      <p><span className="font-medium">Last Salary:</span> 
                        {employeePayrolls.length > 0 ? 
                          formatCurrency(employeePayrolls[employeePayrolls.length - 1].netSalary) : 
                          'N/A'}
                      </p>
                      <p><span className="font-medium">Avg Salary:</span> 
                        {employeePayrolls.length > 0 ? 
                          formatCurrency(
                            employeePayrolls.reduce((sum, p) => sum + p.netSalary, 0) / employeePayrolls.length
                          ) : 
                          'N/A'}
                      </p>
                      <p><span className="font-medium">Highest Salary:</span> 
                        {employeePayrolls.length > 0 ? 
                          formatCurrency(Math.max(...employeePayrolls.map(p => p.netSalary))) : 
                          'N/A'}
                      </p>
                      <p><span className="font-medium">Lowest Salary:</span> 
                        {employeePayrolls.length > 0 ? 
                          formatCurrency(Math.min(...employeePayrolls.map(p => p.netSalary))) : 
                          'N/A'}
                      </p>
                    </div>
                  </div>

                  {/* Attendance Summary Card */}
                  <div className="bg-green-50 rounded-lg p-4">
                    <div className="flex items-center mb-2">
                      <FaClock className="text-green-600 mr-2" />
                      <h4 className="font-medium text-gray-800">Attendance Summary</h4>
                    </div>
                    <div className="text-sm space-y-2">
                      <p><span className="font-medium">Total Records:</span> {employeeAttendance.length}</p>
                      <p><span className="font-medium">Recent (30 days):</span> 
                        {employeeAttendance.filter(a => {
                          const recordDate = new Date(a.workDate);
                          const thirtyDaysAgo = new Date();
                          thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
                          return recordDate >= thirtyDaysAgo;
                        }).length}
                      </p>
                      <p><span className="font-medium">Total Overtime:</span> 
                        {employeeAttendance.reduce((sum, a) => sum + (a.overtimeHours || 0), 0).toFixed(2)} hrs
                      </p>
                      <p><span className="font-medium">Avg Daily Hours:</span> 
                        {employeeAttendance.length > 0 ? 
                          (employeeAttendance.reduce((sum, a) => sum + a.totalHours, 0) / employeeAttendance.length).toFixed(2) + ' hrs' : 
                          'N/A'}
                      </p>
                      <p><span className="font-medium">Last Record:</span> 
                        {employeeAttendance.length > 0 ? 
                          new Date(employeeAttendance[employeeAttendance.length - 1].workDate).toLocaleDateString() : 
                          'N/A'}
                      </p>
                    </div>
                  </div>

                  {/* Leave Summary Card */}
                  <div className="bg-yellow-50 rounded-lg p-4">
                    <div className="flex items-center mb-2">
                      <FaCalendarDay className="text-yellow-600 mr-2" />
                      <h4 className="font-medium text-gray-800">Leave Summary</h4>
                    </div>
                    <div className="text-sm space-y-2">
                      <p><span className="font-medium">Total Leaves:</span> {employeeLeaves.length}</p>
                      <p><span className="font-medium">Unpaid Leaves:</span> 
                        {employeeLeaves.filter(l => !l.isPaid).length}
                      </p>
                      <p><span className="font-medium">Recent Leave:</span> 
                        {employeeLeaves.length > 0 ? 
                          new Date(employeeLeaves[employeeLeaves.length - 1].startDate).toLocaleDateString() : 
                          'N/A'}
                      </p>
                      <p><span className="font-medium">Leave Types:</span></p>
                      <div className="ml-2">
                        {Object.entries(
                          employeeLeaves.reduce((acc, leave) => {
                            acc[leave.leaveType] = (acc[leave.leaveType] || 0) + 1;
                            return acc;
                          }, {})
                        ).map(([type, count]) => (
                          <p key={type} className="flex justify-between">
                            <span>{type}:</span>
                            <span>{count}</span>
                          </p>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </motion.div>


          {/* Main Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Employee Overview Card */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="bg-white rounded-lg shadow-md p-6"
            >
              <div className="flex items-center mb-4">
                <div className="p-3 rounded-full bg-blue-100 text-blue-600 mr-3">
                  <FaUsers size={20} />
                </div>
                <h3 className="text-lg font-semibold text-gray-800">Employee Overview</h3>
              </div>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-gray-600">Total Employees</span>
                  <span className="font-medium">{insights.totalEmployees}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Active</span>
                  <span className="font-medium text-green-600">{insights.activeEmployees}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Inactive</span>
                  <span className="font-medium text-red-600">{insights.inactiveEmployees}</span>
                </div>
                <div className="pt-2 border-t">
                  <h4 className="text-sm font-medium text-gray-600 mb-2">Top Departments</h4>
                  {topDepartments.map(([dept, count]) => (
                    <div key={dept} className="flex justify-between mb-1">
                      <span className="text-sm text-gray-600">{dept}</span>
                      <span className="text-sm font-medium">{count}</span>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>

            {/* Attendance Summary Card */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="bg-white rounded-lg shadow-md p-6"
            >
              <div className="flex items-center mb-4">
                <div className="p-3 rounded-full bg-green-100 text-green-600 mr-3">
                  <FaUserClock size={20} />
                </div>
                <h3 className="text-lg font-semibold text-gray-800">Attendance Summary</h3>
              </div>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-gray-600">Total Records</span>
                  <span className="font-medium">{insights.totalAttendance}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Recent (30 days)</span>
                  <span className="font-medium">{insights.recentAttendance}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Avg per Employee</span>
                  <span className="font-medium">{insights.avgAttendancePerEmployee}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Total Overtime</span>
                  <span className="font-medium">{insights.totalOvertime.toFixed(2)} hrs</span>
                </div>
                <div className="pt-2 border-t">
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Attendance Rate</span>
                    <span className="text-sm font-medium">
                      {insights.totalEmployees > 0 
                        ? `${((insights.totalAttendance / (insights.totalAttendance + insights.totalLeaves)) * 100).toFixed(2)}%` 
                        : 'N/A'}
                    </span>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Payroll Overview Card */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="bg-white rounded-lg shadow-md p-6"
            >
              <div className="flex items-center mb-4">
                <div className="p-3 rounded-full bg-purple-100 text-purple-600 mr-3">
                  <FaMoneyBillWave size={20} />
                </div>
                <h3 className="text-lg font-semibold text-gray-800">Payroll Overview</h3>
              </div>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-gray-600">Total Processed</span>
                  <span className="font-medium">{insights.totalPayrolls}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Total Salary Paid</span>
                  <span className="font-medium">{formatCurrency(insights.totalSalaryPaid)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Avg Salary</span>
                  <span className="font-medium">{formatCurrency(insights.avgSalary)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">This Month Salary</span>
                  <span className="font-medium">{formatCurrency(insights.thisMonthSalary)}</span>
                </div>
                <div className="pt-2 border-t">
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Pending</span>
                    <span className="text-sm font-medium text-yellow-600">{insights.pendingPayrolls}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Processed</span>
                    <span className="text-sm font-medium text-green-600">{insights.processedPayrolls}</span>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Leave Management Card */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
              className="bg-white rounded-lg shadow-md p-6"
            >
              <div className="flex items-center mb-4">
                <div className="p-3 rounded-full bg-yellow-100 text-yellow-600 mr-3">
                  <FaCalendarAlt size={20} />
                </div>
                <h3 className="text-lg font-semibold text-gray-800">Leave Management</h3>
              </div>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-gray-600">Total Leaves</span>
                  <span className="font-medium">{insights.totalLeaves}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Unpaid Leaves</span>
                  <span className="font-medium">{insights.unpaidLeaves}</span>
                </div>
                <div className="pt-2 border-t">
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Leave Utilization</span>
                    <span className="text-sm font-medium">
                      {insights.totalEmployees > 0 
                        ? `${((insights.totalLeaves / (insights.totalEmployees * 20)) * 100).toFixed(2)}%` 
                        : 'N/A'}
                    </span>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Transaction Summary Card */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.5 }}
              className="bg-white rounded-lg shadow-md p-6"
            >
              <div className="flex items-center mb-4">
                <div className="p-3 rounded-full bg-red-100 text-red-600 mr-3">
                  <FaFileAlt size={20} />
                </div>
                <h3 className="text-lg font-semibold text-gray-800">Transaction Summary</h3>
              </div>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-gray-600">Total Transactions</span>
                  <span className="font-medium">{insights.totalTransactions}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Total Amount</span>
                  <span className="font-medium">{formatCurrency(insights.totalAmountTransferred)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Successful</span>
                  <span className="font-medium text-green-600">{insights.successfulTransactions}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Failed</span>
                  <span className="font-medium text-red-600">{insights.failedTransactions}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Pending</span>
                  <span className="font-medium text-yellow-600">{insights.pendingTransactions}</span>
                </div>
                <div className="pt-2 border-t">
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Success Rate</span>
                    <span className="text-sm font-medium">
                      {insights.totalTransactions > 0 
                        ? `${((insights.successfulTransactions / insights.totalTransactions) * 100).toFixed(2)}%` 
                        : 'N/A'}
                    </span>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Workforce Analytics Card */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.6 }}
              className="bg-white rounded-lg shadow-md p-6"
            >
              <div className="flex items-center mb-4">
                <div className="p-3 rounded-full bg-indigo-100 text-indigo-600 mr-3">
                  <FaChartLine size={20} />
                </div>
                <h3 className="text-lg font-semibold text-gray-800">Workforce Analytics</h3>
              </div>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-sm font-medium text-gray-600">Employee Retention</span>
                    <span className="text-sm font-medium">
                      {insights.totalEmployees > 0 
                        ? `${((insights.activeEmployees / insights.totalEmployees) * 100).toFixed(2)}%` 
                        : 'N/A'}
                    </span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-blue-600 h-2 rounded-full" 
                      style={{ 
                        width: insights.totalEmployees > 0 
                          ? `${(insights.activeEmployees / insights.totalEmployees) * 100}%` 
                          : '0%'
                      }}
                    ></div>
                  </div>
                </div>
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-sm font-medium text-gray-600">Overtime Utilization</span>
                    <span className="text-sm font-medium">
                      {insights.totalOvertime.toFixed(2)} hrs
                    </span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-green-600 h-2 rounded-full" 
                      style={{ 
                        width: `${Math.min(100, (insights.totalOvertime / (insights.totalEmployees * 40)) * 100)}%` 
                      }}
                    ></div>
                  </div>
                </div>
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-sm font-medium text-gray-600">Payroll Accuracy</span>
                    <span className="text-sm font-medium">
                      {insights.totalTransactions > 0 
                        ? `${((insights.successfulTransactions / insights.totalTransactions) * 100).toFixed(2)}%` 
                        : 'N/A'}
                    </span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-purple-600 h-2 rounded-full" 
                      style={{ 
                        width: insights.totalTransactions > 0 
                          ? `${(insights.successfulTransactions / insights.totalTransactions) * 100}%` 
                          : '0%'
                      }}
                    ></div>
                  </div>
                </div>
                <div className="pt-2 border-t">
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Active Employees</span>
                    <span className="text-sm font-medium">
                      {((insights.activeEmployees / insights.totalEmployees) * 100).toFixed(2)}%
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Payroll Success Rate</span>
                    <span className="text-sm font-medium">
                      {insights.totalTransactions > 0 
                        ? `${((insights.successfulTransactions / insights.totalTransactions) * 100).toFixed(2)}%` 
                        : 'N/A'}
                    </span>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Quick Actions Card */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.7 }}
              className="bg-white rounded-lg shadow-md p-6"
            >
              <div className="flex items-center mb-4">
                <div className="p-3 rounded-full bg-pink-100 text-pink-600 mr-3">
                  <FaIdCard size={20} />
                </div>
                <h3 className="text-lg font-semibold text-gray-800">Quick Actions</h3>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <button 
                  onClick={() => navigate('/employee-management')}
                  className="bg-blue-100 text-blue-800 p-3 rounded-lg text-sm font-medium hover:bg-blue-200 transition"
                >
                  Manage Employees
                </button>
                <button 
                  onClick={() => navigate('/payroll')}
                  className="bg-green-100 text-green-800 p-3 rounded-lg text-sm font-medium hover:bg-green-200 transition"
                >
                  Process Payroll
                </button>
                <button 
                  onClick={() => navigate('/leave-records')}
                  className="bg-purple-100 text-purple-800 p-3 rounded-lg text-sm font-medium hover:bg-purple-200 transition"
                >
                  Approve Leaves
                </button>
                <button 
                  onClick={() => navigate('/transaction-status')}
                  className="bg-indigo-100 text-indigo-800 p-3 rounded-lg text-sm font-medium hover:bg-indigo-200 transition"
                >
                  View Transactions
                </button>
                <button 
                  onClick={() => navigate('/reports')}
                  className="bg-yellow-100 text-yellow-800 p-3 rounded-lg text-sm font-medium hover:bg-yellow-200 transition"
                >
                  Generate Reports
                </button>
                <button 
                  onClick={() => navigate('/employee-management/add')}
                  className="bg-teal-100 text-teal-800 p-3 rounded-lg text-sm font-medium hover:bg-teal-200 transition"
                >
                  Add New Employee
                </button>
              </div>
            </motion.div>

            {/* Recent Activity Card */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.8 }}
              className="bg-white rounded-lg shadow-md p-6"
            >
              <div className="flex items-center mb-4">
                <div className="p-3 rounded-full bg-teal-100 text-teal-600 mr-3">
                  <FaBusinessTime size={20} />
                </div>
                <h3 className="text-lg font-semibold text-gray-800">Recent Activity</h3>
              </div>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between">
                    <span className="text-sm font-medium text-gray-600">Recent Attendance</span>
                    <span className="text-sm font-medium">{insights.recentAttendance}</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-1 mt-1">
                    <div 
                      className="bg-blue-600 h-1 rounded-full" 
                      style={{ width: `${Math.min(100, (insights.recentAttendance / 10) * 100)}%` }}
                    ></div>
                  </div>
                </div>
                <div>
                  <div className="flex justify-between">
                    <span className="text-sm font-medium text-gray-600">Pending Payrolls</span>
                    <span className="text-sm font-medium">{insights.pendingPayrolls}</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-1 mt-1">
                    <div 
                      className="bg-purple-600 h-1 rounded-full" 
                      style={{ width: `${Math.min(100, (insights.pendingPayrolls / 10) * 100)}%` }}
                    ></div>
                  </div>
                </div>
                <div>
                  <div className="flex justify-between">
                    <span className="text-sm font-medium text-gray-600">Failed Transactions</span>
                    <span className="text-sm font-medium">{insights.failedTransactions}</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-1 mt-1">
                    <div 
                      className="bg-red-600 h-1 rounded-full" 
                      style={{ width: `${Math.min(100, (insights.failedTransactions / 10) * 100)}%` }}
                    ></div>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Performance Metrics Card */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.9 }}
              className="bg-white rounded-lg shadow-md p-6"
            >
              <div className="flex items-center mb-4">
                <div className="p-3 rounded-full bg-orange-100 text-orange-600 mr-3">
                  <FaPercentage size={20} />
                </div>
                <h3 className="text-lg font-semibold text-gray-800">Performance Metrics</h3>
              </div>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-sm font-medium text-gray-600">Employee Retention</span>
                    <span className="text-sm font-medium">
                      {insights.totalEmployees > 0 
                        ? `${((insights.activeEmployees / insights.totalEmployees) * 100).toFixed(2)}%` 
                        : 'N/A'}
                    </span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-green-600 h-2 rounded-full" 
                      style={{ 
                        width: insights.totalEmployees > 0 
                          ? `${(insights.activeEmployees / insights.totalEmployees) * 100}%` 
                          : '0%'
                      }}
                    ></div>
                  </div>
                </div>
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-sm font-medium text-gray-600">Payroll Accuracy</span>
                    <span className="text-sm font-medium">
                      {insights.totalTransactions > 0 
                        ? `${((insights.successfulTransactions / insights.totalTransactions) * 100).toFixed(2)}%` 
                        : 'N/A'}
                    </span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-blue-600 h-2 rounded-full" 
                      style={{ 
                        width: insights.totalTransactions > 0 
                          ? `${(insights.successfulTransactions / insights.totalTransactions) * 100}%` 
                          : '0%'
                      }}
                    ></div>
                  </div>
                </div>
                <div className="pt-2 border-t">
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Overtime Utilization</span>
                    <span className="text-sm font-medium">
                      {insights.totalEmployees > 0 
                        ? `${(insights.totalOvertime / (insights.totalEmployees * 40)).toFixed(2)}%` 
                        : 'N/A'}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Attendance Rate</span>
                    <span className="text-sm font-medium">
                      {insights.totalEmployees > 0 
                        ? `${((insights.totalAttendance / (insights.totalAttendance + insights.totalLeaves)) * 100).toFixed(2)}%` 
                        : 'N/A'}
                    </span>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
};

export default HRDashboard;
