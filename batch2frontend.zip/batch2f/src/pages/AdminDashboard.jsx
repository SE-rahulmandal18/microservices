

import React, { useState, useEffect } from 'react';
import { 
  Chart as ChartJS, 
  ArcElement, 
  Tooltip, 
  Legend, 
  CategoryScale, 
  LinearScale, 
  BarElement, 
  PointElement, 
  LineElement,
  Title,
  RadialLinearScale
} from 'chart.js';
import { Pie, Bar, Line, Doughnut, PolarArea } from 'react-chartjs-2';
import axios from 'axios';
import HeaderNavbar from '../component/HeaderNavbar';
import { 
  FiUsers, 
  FiClock, 
  FiTrendingUp, 
  FiAward,
  FiDollarSign,
  FiCreditCard,
  FiAlertCircle,
  FiShield,
  FiActivity,
  FiDatabase,
  FiCalendar,
  FiUserCheck,
  FiUserX,
  FiLayers,
  FiPieChart
} from 'react-icons/fi';

ChartJS.register(
  ArcElement, Tooltip, Legend, CategoryScale, 
  LinearScale, BarElement, PointElement, LineElement, Title,
  RadialLinearScale
);

const AdminDashboard = () => {
  const [dashboardData, setDashboardData] = useState({
    employees: [],
    attendance: [],
    payrolls: [],
    transactions: [],
    auditLogs: [],
    leaveRecords: [],
    loading: true,
    error: null
  });

  const [activeTab, setActiveTab] = useState('overview');
  const [timeframe, setTimeframe] = useState('monthly');

  useEffect(() => {
    const fetchData = async () => {
      const token = localStorage.getItem('token');
      try {
        const [
          employeesRes, 
          attendanceRes, 
          payrollsRes, 
          transactionsRes, 
          auditLogsRes,
          leaveRecordsRes
        ] = await Promise.all([
          axios.get('http://localhost:8080/api/employees', {
            headers: { Authorization: `Bearer ${token}` }
          }),
          axios.get('http://localhost:8080/api/attendance', {
            headers: { Authorization: `Bearer ${token}` }
          }),
          axios.get('http://localhost:8080/api/payrolls', {
            headers: { Authorization: `Bearer ${token}` }
          }),
          axios.get('http://localhost:8080/api/transactions', {
            headers: { Authorization: `Bearer ${token}` }
          }),
          axios.get('http://localhost:8080/api/audit-logs', {
            headers: { Authorization: `Bearer ${token}` }
          }),
          axios.get('http://localhost:8080/api/leaves', {
            headers: { Authorization: `Bearer ${token}` }
          })
        ]);

        // Fetch employee details for each payroll to fix the "unknown" issue
        const payrollsWithEmployeeDetails = await Promise.all(
          payrollsRes.data.map(async (payroll) => {
            try {
              const employeeRes = await axios.get(`http://localhost:8080/api/employees/${payroll.employeeId}`, {
                headers: { Authorization: `Bearer ${token}` }
              });
              return {
                ...payroll,
                employee: employeeRes.data
              };
            } catch (error) {
              console.error("Error fetching employee details:", error);
              return payroll;
            }
          })
        );

        setDashboardData({
          employees: employeesRes.data || [],
          attendance: attendanceRes.data || [],
          payrolls: payrollsWithEmployeeDetails || [],
          transactions: transactionsRes.data || [],
          auditLogs: auditLogsRes.data || [],
          leaveRecords: leaveRecordsRes.data || [],
          loading: false,
          error: null
        });
      } catch (err) {
        setDashboardData(prev => ({
          ...prev,
          loading: false,
          error: "Failed to load dashboard data. Please try again later."
        }));
        console.error("Error fetching data:", err);
      }
    };
    fetchData();
  }, [timeframe]);

  // Calculate metrics based on backend data
  const calculateMetrics = () => {
    const { employees, attendance, payrolls, transactions, auditLogs, leaveRecords } = dashboardData;

    // Employee metrics
    const activeEmployees = employees.filter(e => e.status === 'ACTIVE').length;
    const inactiveEmployees = employees.filter(e => e.status === 'INACTIVE').length;
    const departmentCounts = employees.reduce((acc, emp) => {
      const dept = emp.department || 'Unassigned';
      acc[dept] = (acc[dept] || 0) + 1;
      return acc;
    }, {});
    const employmentTypeCounts = employees.reduce((acc, emp) => {
      const type = emp.employmentType || 'UNKNOWN';
      acc[type] = (acc[type] || 0) + 1;
      return acc;
    }, {});

    // Attendance metrics
    const totalAttendanceHours = attendance.reduce((sum, a) => sum + (a.totalHours || 0), 0);
    const avgAttendanceHours = attendance.length > 0 ? totalAttendanceHours / attendance.length : 0;
    const totalOvertimeHours = attendance.reduce((sum, a) => sum + (a.overtimeHours || 0), 0);
    const avgOvertimeHours = attendance.length > 0 ? totalOvertimeHours / attendance.length : 0;

    // Payroll metrics
    const totalPayroll = payrolls.reduce((sum, p) => sum + (p.netSalary || 0), 0);
    const avgSalary = payrolls.length > 0 ? totalPayroll / payrolls.length : 0;
    const payrollStatusCounts = payrolls.reduce((acc, p) => {
      const status = p.paymentStatus || 'UNKNOWN';
      acc[status] = (acc[status] || 0) + 1;
      return acc;
    }, {});

    // Transaction metrics
    const successfulTransactions = transactions.filter(t => t.status === 'SUCCESS').length;
    const pendingTransactions = transactions.filter(t => t.status === 'PENDING').length;
    const failedTransactions = transactions.filter(t => t.status === 'FAILED').length;
    const txSuccessRate = transactions.length > 0 ? (successfulTransactions / transactions.length * 100) : 0;
    const totalTransactionAmount = transactions.reduce((sum, t) => sum + (t.amount || 0), 0);

    // Leave metrics
    const paidLeaves = leaveRecords.filter(l => l.isPaid).length;
    const unpaidLeaves = leaveRecords.filter(l => !l.isPaid).length;
    const leaveTypeCounts = leaveRecords.reduce((acc, l) => {
      const type = l.leaveType || 'UNKNOWN';
      acc[type] = (acc[type] || 0) + 1;
      return acc;
    }, {});

    // Audit log metrics
    const securityLogs = auditLogs.filter(log =>
      log.action.includes('SECURITY') || log.action.includes('LOGIN')
    );

    const errorLogs = auditLogs.filter(log =>
      log.action.includes('ERROR') ||
      log.action.includes('FAIL') ||
      (log.details && log.details.includes('error'))
    );

    const errorRate = auditLogs.length > 0 ? (errorLogs.length / auditLogs.length * 100) : 0;


    return {
      employees: {
        total: employees.length,
        active: activeEmployees,
        inactive: inactiveEmployees,
        departmentCounts,
        employmentTypeCounts
      },
      attendance: {
        totalRecords: attendance.length,
        avgHours: avgAttendanceHours,
        avgOvertime: avgOvertimeHours,
        totalOvertime: totalOvertimeHours
      },
      payroll: {
        totalAmount: totalPayroll,
        avgSalary,
        statusCounts: payrollStatusCounts,
        processedCount: payrolls.filter(p => p.paymentStatus === 'PROCESSED').length,
        pendingCount: payrolls.filter(p => p.paymentStatus === 'PENDING').length
      },
      transactions: {
        total: transactions.length,
        successful: successfulTransactions,
        pending: pendingTransactions,
        failed: failedTransactions,
        successRate: txSuccessRate,
        totalAmount: totalTransactionAmount
      },
      leaves: {
        total: leaveRecords.length,
        paid: paidLeaves,
        unpaid: unpaidLeaves,
        typeCounts: leaveTypeCounts
      },
      system: {
        totalLogs: auditLogs.length,
        errorLogs,
        errorRate,
        securityLogs: securityLogs.length,
        recentActions: auditLogs.slice(0, 5)
      }
    };
  };

  const metrics = calculateMetrics();

  if (dashboardData.loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <HeaderNavbar />
        <div className="flex justify-center items-center h-screen">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
        </div>
      </div>
    );
  }

  if (dashboardData.error) {
    return (
      <div className="min-h-screen bg-gray-50">
        <HeaderNavbar />
        <div className="flex justify-center items-center h-screen">
          <div className="text-red-500 text-lg">{dashboardData.error}</div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-[#eaeaea] min-h-screen px-8 py-6">
      <HeaderNavbar />
      <div className="p-6">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold">Admin Dashboard</h1>
          <select 
            value={timeframe}
            onChange={(e) => setTimeframe(e.target.value)}
            className="border p-2 rounded bg-white"
          >
            <option value="monthly">Monthly</option>
            <option value="quarterly">Quarterly</option>
            <option value="yearly">Yearly</option>
          </select>
        </div>

        {/* Navigation Tabs */}
        <div className="flex border-b mb-6">
          <button
            className={`px-4 py-2 font-medium ${activeTab === 'overview' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-500'}`}
            onClick={() => setActiveTab('overview')}
          >
            Overview
          </button>
          <button
            className={`px-4 py-2 font-medium ${activeTab === 'workforce' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-500'}`}
            onClick={() => setActiveTab('workforce')}
          >
            Workforce
          </button>
          <button
            className={`px-4 py-2 font-medium ${activeTab === 'financial' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-500'}`}
            onClick={() => setActiveTab('financial')}
          >
            Financial
          </button>
          <button
            className={`px-4 py-2 font-medium ${activeTab === 'system' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-500'}`}
            onClick={() => setActiveTab('system')}
          >
            System
          </button>
        </div>

        {/* Overview Tab */}
        {activeTab === 'overview' && (
          <div>
            {/* Key Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-4 mb-6">
              <MetricCard 
                icon={<FiUsers className="text-blue-500" size={24} />}
                title="Total Employees"
                value={metrics.employees.total}
                change={`${metrics.employees.active} active`}
              />
              <MetricCard 
                icon={<FiClock className="text-green-500" size={24} />}
                title="Avg Overtime"
                value={metrics.attendance.avgOvertime.toFixed(1) + " hrs"}
                change={`Total: ${metrics.attendance.totalOvertime.toFixed(1)} hrs`}
              />
              <MetricCard 
                icon={<FiDollarSign className="text-purple-500" size={24} />}
                title="Total Payroll"
                value={`₹${(metrics.payroll.totalAmount / 100000).toFixed(1)}L`}
                change={`${metrics.payroll.processedCount} processed`}
              />
              <MetricCard 
                icon={<FiShield className="text-yellow-500" size={24} />}
                title="System Health"
                value={`${(100 - metrics.system.errorRate).toFixed(0)}%`}
                change={`${metrics.system.errorLogs} errors`}
              />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
              {/* Department Distribution */}
              <DashboardCard title="Department Distribution">
                <div className="h-64">
                  <Pie
                    data={{
                      labels: Object.keys(metrics.employees.departmentCounts),
                      datasets: [{
                        data: Object.values(metrics.employees.departmentCounts),
                        backgroundColor: [
                          '#3B82F6', '#10B981', '#F59E0B', '#6366F1', '#EC4899',
                          '#14B8A6', '#F97316', '#8B5CF6', '#EF4444', '#0EA5E9'
                        ],
                        borderWidth: 1
                      }]
                    }}
                    options={{ 
                      maintainAspectRatio: false,
                      plugins: {
                        legend: { position: 'right' }
                      }
                    }}
                  />
                </div>
              </DashboardCard>

              {/* Payroll Status */}
              <DashboardCard title="Payroll Status">
                <div className="h-64">
                  <Doughnut
                    data={{
                      labels: Object.keys(metrics.payroll.statusCounts).map(s => s.charAt(0) + s.slice(1).toLowerCase()),
                      datasets: [{
                        data: Object.values(metrics.payroll.statusCounts),
                        backgroundColor: [
                          '#3B82F6', '#10B981', '#F59E0B', '#6366F1'
                        ],
                        borderWidth: 1
                      }]
                    }}
                    options={{ 
                      maintainAspectRatio: false,
                      plugins: {
                        legend: { position: 'right' }
                      }
                    }}
                  />
                </div>
              </DashboardCard>
            </div>

            {/* Recent Activity */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <DashboardCard title="Recent Payrolls">
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Employee</th>
                        <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Amount</th>
                        <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {dashboardData.payrolls.slice(0, 5).map(payroll => (
                        <tr key={payroll.id}>
                          <td className="px-3 py-2 whitespace-nowrap text-sm">
                            {payroll.employee?.firstName || 'Unknown'} {payroll.employee?.lastName || ''}
                          </td>
                          <td className="px-3 py-2 whitespace-nowrap text-sm font-medium">
                            ₹{payroll.netSalary?.toFixed(2) || '0.00'}
                          </td>
                          <td className="px-3 py-2 whitespace-nowrap">
                            <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                              payroll.paymentStatus === 'PROCESSED' ? 'bg-green-100 text-green-800' :
                              payroll.paymentStatus === 'PENDING' ? 'bg-yellow-100 text-yellow-800' :
                              'bg-red-100 text-red-800'
                            }`}>
                              {payroll.paymentStatus || 'UNKNOWN'}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </DashboardCard>

              <DashboardCard title="Recent Transactions">
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Employee</th>
                        <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Amount</th>
                        <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {dashboardData.transactions.slice(0, 5).map(tx => (
                        <tr key={tx.id}>
                          <td className="px-3 py-2 whitespace-nowrap text-sm">
                            {tx.employee?.firstName || 'Unknown'} {tx.employee?.lastName || ''}
                          </td>
                          <td className="px-3 py-2 whitespace-nowrap text-sm font-medium">
                            ₹{tx.amount?.toFixed(2) || '0.00'}
                          </td>
                          <td className="px-3 py-2 whitespace-nowrap">
                            <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                              tx.status === 'SUCCESS' ? 'bg-green-100 text-green-800' :
                              tx.status === 'PENDING' ? 'bg-yellow-100 text-yellow-800' :
                              'bg-red-100 text-red-800'
                            }`}>
                              {tx.status || 'UNKNOWN'}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </DashboardCard>
            </div>
          </div>
        )}

        {/* Workforce Tab */}
        {activeTab === 'workforce' && (
          <div>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
              <MetricCard 
                icon={<FiUsers className="text-blue-500" size={24} />}
                title="Total Employees"
                value={metrics.employees.total}
                change={`${metrics.employees.active} active`}
              />
              <MetricCard 
                icon={<FiUserCheck className="text-green-500" size={24} />}
                title="Active Employees"
                value={metrics.employees.active}
                change={`${((metrics.employees.active / metrics.employees.total) * 100).toFixed(0)}%`}
              />
              <MetricCard 
                icon={<FiUserX className="text-red-500" size={24} />}
                title="Inactive Employees"
                value={metrics.employees.inactive}
                change={`${((metrics.employees.inactive / metrics.employees.total) * 100).toFixed(0)}%`}
              />
              <MetricCard 
                icon={<FiClock className="text-purple-500" size={24} />}
                title="Avg Overtime"
                value={metrics.attendance.avgOvertime.toFixed(1) + " hrs"}
                change={`Total: ${metrics.attendance.totalOvertime.toFixed(1)} hrs`}
              />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
              <DashboardCard title="Employment Types">
                <div className="h-64">
                  <Pie
                    data={{
                      labels: Object.keys(metrics.employees.employmentTypeCounts),
                      datasets: [{
                        data: Object.values(metrics.employees.employmentTypeCounts),
                        backgroundColor: [
                          '#3B82F6', '#10B981', '#F59E0B', '#6366F1'
                        ],
                        borderWidth: 1
                      }]
                    }}
                    options={{ 
                      maintainAspectRatio: false,
                      plugins: {
                        legend: { position: 'right' }
                      }
                    }}
                  />
                </div>
              </DashboardCard>

              <DashboardCard title="Attendance Trends">
                <div className="h-64">
                  <Line
                    data={{
                      labels: dashboardData.attendance.slice(0, 7).map(a => new Date(a.workDate).toLocaleDateString()),
                      datasets: [{
                        label: 'Hours Worked',
                        data: dashboardData.attendance.slice(0, 7).map(a => a.totalHours),
                        borderColor: '#10B981',
                        backgroundColor: 'rgba(16, 185, 129, 0.1)',
                        fill: true,
                        tension: 0.3
                      }]
                    }}
                    options={{ 
                      maintainAspectRatio: false,
                      scales: { y: { beginAtZero: true } }
                    }}
                  />
                </div>
              </DashboardCard>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <DashboardCard title="Leave Distribution">
                <div className="h-64">
                  <Pie
                    data={{
                      labels: Object.keys(metrics.leaves.typeCounts),
                      datasets: [{
                        data: Object.values(metrics.leaves.typeCounts),
                        backgroundColor: [
                          '#3B82F6', '#10B981', '#F59E0B', '#6366F1'
                        ],
                        borderWidth: 1
                      }]
                    }}
                    options={{ 
                      maintainAspectRatio: false,
                      plugins: {
                        legend: { position: 'right' }
                      }
                    }}
                  />
                </div>
              </DashboardCard>

              <DashboardCard title="Recent Leaves">
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Employee</th>
                        <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
                        <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {dashboardData.leaveRecords.slice(0, 5).map(leave => (
                        <tr key={leave.id}>
                          <td className="px-3 py-2 whitespace-nowrap">
                            {leave.employee?.firstName || 'Unknown'} {leave.employee?.lastName || ''}
                          </td>
                          <td className="px-3 py-2 whitespace-nowrap">
                            {leave.leaveType || 'UNKNOWN'}
                          </td>
                          <td className="px-3 py-2 whitespace-nowrap">
                            <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                              leave.isPaid ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                            }`}>
                              {leave.isPaid ? 'Paid' : 'Unpaid'}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </DashboardCard>
            </div>
          </div>
        )}

        {/* Financial Tab */}
        {activeTab === 'financial' && (
          <div>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
              <MetricCard 
                icon={<FiDollarSign className="text-blue-500" size={24} />}
                title="Total Payroll"
                value={`₹${(metrics.payroll.totalAmount / 100000).toFixed(1)}L`}
                change={`${metrics.payroll.processedCount} processed`}
              />
              <MetricCard 
                icon={<FiCreditCard className="text-green-500" size={24} />}
                title="Avg Salary"
                value={`₹${metrics.payroll.avgSalary.toFixed(2)}`}
                change={`${metrics.employees.total} employees`}
              />
              <MetricCard 
                icon={<FiTrendingUp className="text-purple-500" size={24} />}
                title="Tx Success Rate"
                value={`${metrics.transactions.successRate.toFixed(1)}%`}
                change={`${metrics.transactions.successful} successful`}
              />
              <MetricCard 
                icon={<FiAlertCircle className="text-red-500" size={24} />}
                title="Failed Transactions"
                value={metrics.transactions.failed}
                change={`${((metrics.transactions.failed / metrics.transactions.total) * 100).toFixed(1)}%`}
              />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
              <DashboardCard title="Payroll Status Distribution">
                <div className="h-64">
                  <Bar
                    data={{
                      labels: Object.keys(metrics.payroll.statusCounts),
                      datasets: [{
                        label: 'Count',
                        data: Object.values(metrics.payroll.statusCounts),
                        backgroundColor: '#3B82F6',
                        borderRadius: 4
                      }]
                    }}
                    options={{ 
                      maintainAspectRatio: false,
                      scales: { 
                        y: { beginAtZero: true, grid: { display: false } },
                        x: { grid: { display: false } }
                      },
                      plugins: { legend: { display: false } }
                    }}
                  />
                </div>
              </DashboardCard>

              <DashboardCard title="Transaction Status">
                <div className="h-64">
                  <PolarArea
                    data={{
                      labels: ['Success', 'Pending', 'Failed'],
                      datasets: [{
                        data: [
                          metrics.transactions.successful,
                          metrics.transactions.pending,
                          metrics.transactions.failed
                        ],
                        backgroundColor: [
                          'rgba(16, 185, 129, 0.7)',
                          'rgba(245, 158, 11, 0.7)',
                          'rgba(239, 68, 68, 0.7)'
                        ]
                      }]
                    }}
                    options={{ maintainAspectRatio: false }}
                  />
                </div>
              </DashboardCard>
            </div>

            <DashboardCard title="Recent Failed Transactions">
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Employee</th>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Amount</th>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Reason</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {dashboardData.transactions
                      .filter(tx => tx.status === 'FAILED')
                      .slice(0, 5)
                      .map(tx => (
                        <tr key={tx.id}>
                          <td className="px-3 py-2 whitespace-nowrap">
                            {tx.employee?.firstName || 'Unknown'} {tx.employee?.lastName || ''}
                          </td>
                          <td className="px-3 py-2 whitespace-nowrap text-red-600">
                            -₹{tx.amount?.toFixed(2) || '0.00'}
                          </td>
                          <td className="px-3 py-2 whitespace-nowrap">
                            {tx.failureReason || 'Unknown'}
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </DashboardCard>
          </div>
        )}

        {/* System Tab */}
        {activeTab === 'system' && (
          <div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <MetricCard 
                icon={<FiDatabase className="text-blue-500" size={24} />}
                title="Total Logs"
                value={metrics.system.totalLogs}
                change={`${metrics.system.errorLogs} errors`}
              />
              <MetricCard 
                icon={<FiActivity className="text-green-500" size={24} />}
                title="Error Rate"
                value={`${metrics.system.errorRate.toFixed(1)}%`}
                change={metrics.system.errorRate < 5 ? "Good" : "Critical"}
              />
              <MetricCard 
                icon={<FiShield className="text-purple-500" size={24} />}
                title="Security Events"
                value={metrics.system.securityLogs}
                change="Last 30 days"
              />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
              <DashboardCard title="System Activity Logs">
                <div className="h-64">
                  <Bar
                    data={{
                      labels: ['Info', 'Warning', 'Error', 'Security'],
                      datasets: [{
                        label: 'Count',
                        data: [
                          metrics.system.totalLogs - metrics.system.errorLogs - metrics.system.securityLogs,
                          0, // Warnings not tracked in your backend
                          metrics.system.errorLogs,
                          metrics.system.securityLogs
                        ],
                        backgroundColor: [
                          '#3B82F6',
                          '#F59E0B',
                          '#EF4444',
                          '#8B5CF6'
                        ],
                        borderRadius: 4
                      }]
                    }}
                    options={{ 
                      maintainAspectRatio: false,
                      scales: { 
                        y: { beginAtZero: true, grid: { display: false } },
                        x: { grid: { display: false } }
                      },
                      plugins: { legend: { display: false } }
                    }}
                  />
                </div>
              </DashboardCard>

              <DashboardCard title="System Health">
                <div className="h-64 flex flex-col items-center justify-center">
                  <div className={`text-5xl font-bold mb-2 ${
                    metrics.system.errorRate < 5 ? 'text-green-500' : 
                    metrics.system.errorRate < 15 ? 'text-yellow-500' : 'text-red-500'
                  }`}>
                    {(100 - metrics.system.errorRate).toFixed(0)}%
                  </div>
                  <div className="text-lg">System Uptime</div>
                  <div className="w-full bg-gray-200 rounded-full h-2.5 mt-4">
                    <div 
                      className={`h-2.5 rounded-full ${
                        metrics.system.errorRate < 5 ? 'bg-green-500' : 
                        metrics.system.errorRate < 15 ? 'bg-yellow-500' : 'bg-red-500'
                      }`} 
                      style={{ width: `${100 - metrics.system.errorRate}%` }}
                    ></div>
                  </div>
                </div>
              </DashboardCard>
            </div>

            <DashboardCard title="Recent Security Events">
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Action</th>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">User</th>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Details</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {dashboardData.auditLogs
                      .filter(l => l.action.includes('SECURITY') || l.action.includes('LOGIN'))
                      .slice(0, 5)
                      .map(log => (
                        <tr key={log.id}>
                          <td className="px-3 py-2 whitespace-nowrap">
                            <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                              log.action.includes('FAIL') ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'
                            }`}>
                              {log.action || 'UNKNOWN'}
                            </span>
                          </td>
                          <td className="px-3 py-2 whitespace-nowrap">
                            {log.performedBy?.username || 'System'}
                          </td>
                          <td className="px-3 py-2">
                            {log.details?.substring(0, 50) || 'No details'}...
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </DashboardCard>
          </div>
        )}
      </div>
    </div>
  );
};

// Reusable Metric Card Component
const MetricCard = ({ icon, title, value, change }) => (
  <div className="bg-white p-4 rounded-lg shadow flex items-start">
    <div className="mr-3 mt-1">{icon}</div>
    <div>
      <h3 className="text-sm font-medium text-gray-500">{title}</h3>
      <p className="text-2xl font-bold">{value}</p>
      <p className="text-xs text-gray-500">{change}</p>
    </div>
  </div>
);

// Reusable Dashboard Card Component
const DashboardCard = ({ title, children, className = '' }) => (
  <div className={`bg-white p-4 rounded-lg shadow ${className}`}>
    <h2 className="font-semibold mb-3">{title}</h2>
    {children}
  </div>
);

export default AdminDashboard;