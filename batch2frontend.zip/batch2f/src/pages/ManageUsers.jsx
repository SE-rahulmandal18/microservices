import HeaderNavbar from "../component/HeaderNavbar";

const ManageUsers = () => {
    return <div className="container mt-4">
      <HeaderNavbar />
      <h3>🔧 Admin - Manage Users Page</h3>
      </div>;
  };
  export default ManageUsers;
  