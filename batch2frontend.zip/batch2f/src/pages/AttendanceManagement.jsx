// // import React, { useEffect, useState } from "react";
// // import axios from "axios";
// // import HeaderNavbar from "../component/HeaderNavbar";
// // import Footer from "../component/Footer";

// // const AttendanceManagement = () => {
// //   const [attendances, setAttendances] = useState([]);
// //   const [modalOpen, setModalOpen] = useState(false);

// //   const [form, setForm] = useState({
// //     employeeId: "",
// //     workDate: "",
// //     checkInTime: "",
// //     checkOutTime: "",
// //   });

// //   const token = localStorage.getItem("token");
// //   const config = { headers: { Authorization: `Bearer ${token}` } };

// //   useEffect(() => {
// //     fetchAttendances();
// //   }, []);

// //   const fetchAttendances = async () => {
// //     const res = await axios.get("http://localhost:8080/api/attendance", config);
// //     setAttendances(res.data);
// //   };

// //   const handleChange = (e) => {
// //     setForm({ ...form, [e.target.name]: e.target.value });
// //   };

// //   const handleSubmit = async (e) => {
// //     e.preventDefault();
// //     await axios.post("http://localhost:8080/api/attendance", form, config);
// //     fetchAttendances();
// //     closeModal();
// //   };

// //   const openModal = () => {
// //     setForm({ employeeId: "", workDate: "", checkInTime: "", checkOutTime: "" });
// //     setModalOpen(true);
// //   };

// //   const closeModal = () => {
// //     setModalOpen(false);
// //   };

// //   return (
// //     <>
// //       <HeaderNavbar />
// //       <div className="p-6">
// //         <div className="flex justify-between items-center mb-6">
// //           <h2 className="text-2xl font-bold">Attendance Management</h2>
// //           <button
// //             onClick={openModal}
// //             className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
// //           >
// //             Add Attendance
// //           </button>
// //         </div>

// //         <div className="overflow-x-auto">
// //           <table className="w-full table-auto border text-left">
// //             <thead className="bg-gray-200">
// //               <tr>
// //                 <th className="p-2 border">Employee ID</th>
// //                 <th className="p-2 border">Date</th>
// //                 <th className="p-2 border">Check In</th>
// //                 <th className="p-2 border">Check Out</th>
// //                 <th className="p-2 border">Total Hours</th>
// //                 <th className="p-2 border">Overtime</th>
// //               </tr>
// //             </thead>
// //             <tbody>
// //               {attendances.map((a) => (
// //                 <tr key={a.id} className="border-b">
// //                   <td className="p-2 border">{a.employee.id}</td>
// //                   <td className="p-2 border">{a.workDate}</td>
// //                   <td className="p-2 border">{a.checkInTime}</td>
// //                   <td className="p-2 border">{a.checkOutTime}</td>
// //                   <td className="p-2 border">{a.totalHours}</td>
// //                   <td className="p-2 border">{a.overtimeHours}</td>
// //                 </tr>
// //               ))}
// //               {attendances.length === 0 && (
// //                 <tr>
// //                   <td colSpan="6" className="p-4 text-center text-gray-500">
// //                     No attendance records found.
// //                   </td>
// //                 </tr>
// //               )}
// //             </tbody>
// //           </table>
// //         </div>

// //         {modalOpen && (
// //           <div className="fixed inset-0 z-50 backdrop-blur-sm bg-white/10 flex items-center justify-center">
// //             <div className="bg-white p-6 rounded shadow-md w-[90%] max-w-lg">
// //               <h3 className="text-xl font-semibold mb-4">Add Attendance</h3>
// //               <form onSubmit={handleSubmit} className="space-y-4">
// //                 <input
// //                   type="number"
// //                   name="employeeId"
// //                   placeholder="Employee ID"
// //                   value={form.employeeId}
// //                   onChange={handleChange}
// //                   required
// //                   className="w-full border px-3 py-2 rounded"
// //                 />
// //                 <input
// //                   type="date"
// //                   name="workDate"
// //                   value={form.workDate}
// //                   onChange={handleChange}
// //                   required
// //                   className="w-full border px-3 py-2 rounded"
// //                 />
// //                 <input
// //                   type="time"
// //                   name="checkInTime"
// //                   value={form.checkInTime}
// //                   onChange={handleChange}
// //                   required
// //                   className="w-full border px-3 py-2 rounded"
// //                 />
// //                 <input
// //                   type="time"
// //                   name="checkOutTime"
// //                   value={form.checkOutTime}
// //                   onChange={handleChange}
// //                   required
// //                   className="w-full border px-3 py-2 rounded"
// //                 />
// //                 <div className="flex justify-end gap-4">
// //                   <button
// //                     type="button"
// //                     onClick={closeModal}
// //                     className="bg-gray-300 text-black px-4 py-2 rounded hover:bg-gray-400"
// //                   >
// //                     Cancel
// //                   </button>
// //                   <button
// //                     type="submit"
// //                     className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
// //                   >
// //                     Add
// //                   </button>
// //                 </div>
// //               </form>
// //             </div>
// //           </div>
// //         )}
// //       </div>
// //       <Footer />
// //     </>
// //   );
// // };

// // export default AttendanceManagement;

// // import React, { useEffect, useState } from "react";
// // import axios from "axios";
// // import HeaderNavbar from "../component/HeaderNavbar";
// // import Footer from "../component/Footer";

// // const AttendanceManagement = () => {
// //   const [attendances, setAttendances] = useState([]);
// //   const [modalOpen, setModalOpen] = useState(false);
// //   const [filterId, setFilterId] = useState("");

// //   const [form, setForm] = useState({
// //     employeeId: "",
// //     workDate: "",
// //     checkInTime: "",
// //     checkOutTime: "",
// //   });

// //   const token = localStorage.getItem("token");
// //   const config = { headers: { Authorization: `Bearer ${token}` } };

// //   useEffect(() => {
// //     fetchAttendances();
// //   }, []);

// //   const fetchAttendances = async () => {
// //     const res = await axios.get("http://localhost:8080/api/attendance", config);
// //     setAttendances(res.data);
// //   };

// //   const handleChange = (e) => {
// //     setForm({ ...form, [e.target.name]: e.target.value });
// //   };

// //   const handleSubmit = async (e) => {
// //     e.preventDefault();
// //     await axios.post("http://localhost:8080/api/attendance", form, config);
// //     fetchAttendances();
// //     closeModal();
// //   };

// //   const openModal = () => {
// //     setForm({ employeeId: "", workDate: "", checkInTime: "", checkOutTime: "" });
// //     setModalOpen(true);
// //   };

// //   const closeModal = () => {
// //     setModalOpen(false);
// //   };

// //   return (
// //     <>
// //       <HeaderNavbar />
// //       <div className="p-6">
// //         <div className="flex justify-between items-center mb-6">
// //           <h2 className="text-2xl font-bold">Attendance Management</h2>
// //           <div className="flex items-center gap-4">
// //             <input
// //               type="text"
// //               placeholder="Filter by Employee ID"
// //               value={filterId}
// //               onChange={(e) => setFilterId(e.target.value)}
// //               className="border px-3 py-2 rounded"
// //             />
// //             <button
// //               onClick={openModal}
// //               className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
// //             >
// //               Add Attendance
// //             </button>
// //           </div>
// //         </div>

// //         <div className="overflow-x-auto">
// //           <table className="w-full table-auto border text-left">
// //             <thead className="bg-gray-200">
// //               <tr>
// //                 <th className="p-2 border">Employee ID</th>
// //                 <th className="p-2 border">Date</th>
// //                 <th className="p-2 border">Check In</th>
// //                 <th className="p-2 border">Check Out</th>
// //                 <th className="p-2 border">Total Hours</th>
// //                 <th className="p-2 border">Overtime</th>
// //               </tr>
// //             </thead>
// //             <tbody>
// //               {attendances
// //                 .filter((a) =>
// //                   filterId === "" || a.employee.id.toString().includes(filterId)
// //                 )
// //                 .map((a) => (
// //                   <tr key={a.id} className="border-b">
// //                     <td className="p-2 border">{a.employee.id}</td>
// //                     <td className="p-2 border">{a.workDate}</td>
// //                     <td className="p-2 border">{a.checkInTime}</td>
// //                     <td className="p-2 border">{a.checkOutTime}</td>
// //                     <td className="p-2 border">{a.totalHours}</td>
// //                     <td className="p-2 border">{a.overtimeHours}</td>
// //                   </tr>
// //                 ))}
// //               {attendances.filter((a) =>
// //                 filterId === "" || a.employee.id.toString().includes(filterId)
// //               ).length === 0 && (
// //                 <tr>
// //                   <td colSpan="6" className="p-4 text-center text-gray-500">
// //                     No attendance records found.
// //                   </td>
// //                 </tr>
// //               )}
// //             </tbody>
// //           </table>
// //         </div>

// //         {modalOpen && (
// //           <div className="fixed inset-0 z-50 backdrop-blur-sm bg-white/10 flex items-center justify-center">
// //             <div className="bg-white p-6 rounded shadow-md w-[90%] max-w-lg">
// //               <h3 className="text-xl font-semibold mb-4">Add Attendance</h3>
// //               <form onSubmit={handleSubmit} className="space-y-4">
// //                 <input
// //                   type="number"
// //                   name="employeeId"
// //                   placeholder="Employee ID"
// //                   value={form.employeeId}
// //                   onChange={handleChange}
// //                   required
// //                   className="w-full border px-3 py-2 rounded"
// //                 />
// //                 <input
// //                   type="date"
// //                   name="workDate"
// //                   value={form.workDate}
// //                   onChange={handleChange}
// //                   required
// //                   className="w-full border px-3 py-2 rounded"
// //                 />
// //                 <input
// //                   type="time"
// //                   name="checkInTime"
// //                   value={form.checkInTime}
// //                   onChange={handleChange}
// //                   required
// //                   className="w-full border px-3 py-2 rounded"
// //                 />
// //                 <input
// //                   type="time"
// //                   name="checkOutTime"
// //                   value={form.checkOutTime}
// //                   onChange={handleChange}
// //                   required
// //                   className="w-full border px-3 py-2 rounded"
// //                 />
// //                 <div className="flex justify-end gap-4">
// //                   <button
// //                     type="button"
// //                     onClick={closeModal}
// //                     className="bg-gray-300 text-black px-4 py-2 rounded hover:bg-gray-400"
// //                   >
// //                     Cancel
// //                   </button>
// //                   <button
// //                     type="submit"
// //                     className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
// //                   >
// //                     Add
// //                   </button>
// //                 </div>
// //               </form>
// //             </div>
// //           </div>
// //         )}
// //       </div>
// //       <Footer />
// //     </>
// //   );
// // };

// // export default AttendanceManagement;


// // import React, { useEffect, useState } from "react";
// // import axios from "axios";
// // import HeaderNavbar from "../component/HeaderNavbar";
// // import Footer from "../component/Footer";
// // import { FaChartLine } from "react-icons/fa";
// // import { motion } from "framer-motion";
// // import { Bar, Line } from "react-chartjs-2";
// // import { Chart, registerables } from "chart.js";

// // // Register Chart.js components
// // Chart.register(...registerables);

// // const AttendanceManagement = () => {
// //   const [attendances, setAttendances] = useState([]);
// //   const [modalOpen, setModalOpen] = useState(false);
// //   const [filterId, setFilterId] = useState("");
// //   const [showInsights, setShowInsights] = useState(false);
// //   const [employeeId, setEmployeeId] = useState(null);
// //   const [timeRange, setTimeRange] = useState("month");

// //   const [form, setForm] = useState({
// //     employeeId: "",
// //     workDate: "",
// //     checkInTime: "",
// //     checkOutTime: "",
// //   });

// //   const token = localStorage.getItem("token");
// //   const config = { headers: { Authorization: `Bearer ${token}` } };

// //   useEffect(() => {
// //     fetchAttendances();
// //     fetchEmployeeId();
// //   }, []);

// //   const fetchEmployeeId = async () => {
// //     try {
// //       const res = await axios.get("http://localhost:8080/api/employees/me", config);
// //       setEmployeeId(res.data.id);
// //     } catch (err) {
// //       console.error("Error fetching employee ID", err);
// //     }
// //   };

// //   const fetchAttendances = async () => {
// //     const res = await axios.get("http://localhost:8080/api/attendance", config);
// //     setAttendances(res.data);
// //   };

// //   const handleChange = (e) => {
// //     setForm({ ...form, [e.target.name]: e.target.value });
// //   };

// //   const handleSubmit = async (e) => {
// //     e.preventDefault();
// //     await axios.post("http://localhost:8080/api/attendance", form, config);
// //     fetchAttendances();
// //     closeModal();
// //   };

// //   const openModal = () => {
// //     setForm({ employeeId: "", workDate: "", checkInTime: "", checkOutTime: "" });
// //     setModalOpen(true);
// //   };

// //   const closeModal = () => {
// //     setModalOpen(false);
// //   };

// //   const toggleInsights = () => {
// //     setShowInsights(!showInsights);
// //   };

// //   // Process data for charts
// //   const processChartData = () => {
// //     if (!employeeId) return { labels: [], presentData: [], overtimeData: [] };

// //     // Filter attendances for current employee
// //     const employeeAttendances = attendances.filter(
// //       (a) => a.employee && a.employee.id === employeeId
// //     );

// //     const now = new Date();
// //     let labels = [];
// //     let presentData = [];
// //     let overtimeData = [];

// //     // Generate labels and empty datasets based on time range
// //     if (timeRange === "week") {
// //       labels = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
// //       presentData = Array(7).fill(0);
// //       overtimeData = Array(7).fill(0);
// //     } else if (timeRange === "month") {
// //       const daysInMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();
// //       labels = Array.from({ length: daysInMonth }, (_, i) => i + 1);
// //       presentData = Array(daysInMonth).fill(0);
// //       overtimeData = Array(daysInMonth).fill(0);
// //     } else {
// //       // year
// //       labels = [
// //         "Jan", "Feb", "Mar", "Apr", "May", "Jun", 
// //         "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
// //       ];
// //       presentData = Array(12).fill(0);
// //       overtimeData = Array(12).fill(0);
// //     }

// //     // Process attendance data
// //     employeeAttendances.forEach((record) => {
// //       const date = new Date(record.workDate);
// //       let index;

// //       if (timeRange === "week") {
// //         index = date.getDay(); // 0=Sun, 1=Mon, etc.
// //         // Adjust to our label array (Mon=0 to Sun=6)
// //         index = index === 0 ? 6 : index - 1;
// //       } else if (timeRange === "month") {
// //         // Only process if it's the current month
// //         if (
// //           date.getMonth() === now.getMonth() &&
// //           date.getFullYear() === now.getFullYear()
// //         ) {
// //           index = date.getDate() - 1;
// //         } else {
// //           return;
// //         }
// //       } else {
// //         // year
// //         // Only process if it's the current year
// //         if (date.getFullYear() === now.getFullYear()) {
// //           index = date.getMonth();
// //         } else {
// //           return;
// //         }
// //       }

// //       if (index >= 0 && index < presentData.length) {
// //         presentData[index] = 1;
// //         overtimeData[index] = parseFloat(record.overtimeHours) || 0;
// //       }
// //     });

// //     return { labels, presentData, overtimeData };
// //   };

// //   const { labels, presentData, overtimeData } = processChartData();

// //   // Calculate insights
// //   const calculateInsights = () => {
// //     if (!employeeId) return {};

// //     const employeeAttendances = attendances.filter(
// //       (a) => a.employee && a.employee.id === employeeId
// //     );

// //     const totalWorkDays = employeeAttendances.length;
// //     const totalOvertime = employeeAttendances.reduce(
// //       (sum, a) => sum + (a.overtimeHours || 0),
// //       0
// //     );
// //     const avgOvertime = totalWorkDays > 0 ? totalOvertime / totalWorkDays : 0;

// //     // Current streak calculation
// //     let currentStreak = 0;
// //     const sortedAttendance = [...employeeAttendances].sort(
// //       (a, b) => new Date(b.workDate) - new Date(a.workDate)
// //     );
// //     const yesterday = new Date();
// //     yesterday.setDate(yesterday.getDate() - 1);

// //     for (let i = 0; i < sortedAttendance.length; i++) {
// //       const attDate = new Date(sortedAttendance[i].workDate);
// //       if (i === 0 && attDate.toDateString() === yesterday.toDateString()) {
// //         currentStreak = 1;
// //       } else if (i > 0) {
// //         const prevDate = new Date(sortedAttendance[i - 1].workDate);
// //         const dayDiff = (prevDate - attDate) / (1000 * 60 * 60 * 24);
// //         if (dayDiff === 1) {
// //           currentStreak++;
// //         } else {
// //           break;
// //         }
// //       }
// //     }

// //     return {
// //       totalWorkDays,
// //       totalOvertime,
// //       avgOvertime,
// //       currentStreak,
// //     };
// //   };

// //   const insights = calculateInsights();

// //   // Chart data configurations
// //   const attendanceChartData = {
// //     labels,
// //     datasets: [
// //       {
// //         label: "Work Days",
// //         data: presentData,
// //         backgroundColor: "rgba(54, 162, 235, 0.7)",
// //         borderColor: "rgba(54, 162, 235, 1)",
// //         borderWidth: 1,
// //       },
// //     ],
// //   };

// //   const overtimeChartData = {
// //     labels,
// //     datasets: [
// //       {
// //         label: "Overtime Hours",
// //         data: overtimeData,
// //         backgroundColor: "rgba(255, 206, 86, 0.7)",
// //         borderColor: "rgba(255, 206, 86, 1)",
// //         borderWidth: 1,
// //         tension: 0.1,
// //       },
// //     ],
// //   };

// //   return (
// //     <>
// //       <HeaderNavbar />
// //       <div className="p-6">
// //         <div className="flex justify-between items-center mb-6">
// //           <h2 className="text-2xl font-bold">Attendance Management</h2>
// //           <div className="flex items-center gap-4">
// //             <input
// //               type="text"
// //               placeholder="Filter by Employee ID"
// //               value={filterId}
// //               onChange={(e) => setFilterId(e.target.value)}
// //               className="border px-3 py-2 rounded"
// //             />
// //             <button
// //               onClick={openModal}
// //               className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
// //             >
// //               Add Attendance
// //             </button>
// //             <button
// //               onClick={toggleInsights}
// //               className="p-2 text-blue-600 hover:text-blue-800"
// //               title="View Insights"
// //             >
// //               <FaChartLine size={24} />
// //             </button>
// //           </div>
// //         </div>

// //         <div className="overflow-x-auto">
// //           <table className="w-full table-auto border text-left">
// //             <thead className="bg-gray-200">
// //               <tr>
// //                 <th className="p-2 border">Employee ID</th>
// //                 <th className="p-2 border">Date</th>
// //                 <th className="p-2 border">Check In</th>
// //                 <th className="p-2 border">Check Out</th>
// //                 <th className="p-2 border">Total Hours</th>
// //                 <th className="p-2 border">Overtime</th>
// //               </tr>
// //             </thead>
// //             <tbody>
// //               {attendances
// //                 .filter((a) =>
// //                   filterId === "" || a.employee.id.toString().includes(filterId)
// //                 )
// //                 .map((a) => (
// //                   <tr key={a.id} className="border-b">
// //                     <td className="p-2 border">{a.employee.id}</td>
// //                     <td className="p-2 border">{a.workDate}</td>
// //                     <td className="p-2 border">{a.checkInTime}</td>
// //                     <td className="p-2 border">{a.checkOutTime}</td>
// //                     <td className="p-2 border">{a.totalHours}</td>
// //                     <td className="p-2 border">{a.overtimeHours}</td>
// //                   </tr>
// //                 ))}
// //               {attendances.filter((a) =>
// //                 filterId === "" || a.employee.id.toString().includes(filterId)
// //               ).length === 0 && (
// //                 <tr>
// //                   <td colSpan="6" className="p-4 text-center text-gray-500">
// //                     No attendance records found.
// //                   </td>
// //                 </tr>
// //               )}
// //             </tbody>
// //           </table>
// //         </div>

// //         {modalOpen && (
// //           <div className="fixed inset-0 z-50 backdrop-blur-sm bg-white/10 flex items-center justify-center">
// //             <div className="bg-white p-6 rounded shadow-md w-[90%] max-w-lg">
// //               <h3 className="text-xl font-semibold mb-4">Add Attendance</h3>
// //               <form onSubmit={handleSubmit} className="space-y-4">
// //                 <input
// //                   type="number"
// //                   name="employeeId"
// //                   placeholder="Employee ID"
// //                   value={form.employeeId}
// //                   onChange={handleChange}
// //                   required
// //                   className="w-full border px-3 py-2 rounded"
// //                 />
// //                 <input
// //                   type="date"
// //                   name="workDate"
// //                   value={form.workDate}
// //                   onChange={handleChange}
// //                   required
// //                   className="w-full border px-3 py-2 rounded"
// //                 />
// //                 <input
// //                   type="time"
// //                   name="checkInTime"
// //                   value={form.checkInTime}
// //                   onChange={handleChange}
// //                   required
// //                   className="w-full border px-3 py-2 rounded"
// //                 />
// //                 <input
// //                   type="time"
// //                   name="checkOutTime"
// //                   value={form.checkOutTime}
// //                   onChange={handleChange}
// //                   required
// //                   className="w-full border px-3 py-2 rounded"
// //                 />
// //                 <div className="flex justify-end gap-4">
// //                   <button
// //                     type="button"
// //                     onClick={closeModal}
// //                     className="bg-gray-300 text-black px-4 py-2 rounded hover:bg-gray-400"
// //                   >
// //                     Cancel
// //                   </button>
// //                   <button
// //                     type="submit"
// //                     className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
// //                   >
// //                     Add
// //                   </button>
// //                 </div>
// //               </form>
// //             </div>
// //           </div>
// //         )}

// //         {/* Insights Panel */}
// //         {showInsights && (
// //           <div className="fixed inset-0 z-50 bg-black bg-opacity-50 flex items-center justify-center p-4">
// //             <motion.div
// //               initial={{ opacity: 0, scale: 0.9 }}
// //               animate={{ opacity: 1, scale: 1 }}
// //               exit={{ opacity: 0, scale: 0.9 }}
// //               className="bg-white rounded-lg shadow-xl w-full max-w-4xl max-h-[90vh] overflow-y-auto"
// //             >
// //               <div className="p-6">
// //                 <div className="flex justify-between items-center mb-6">
// //                   <h2 className="text-2xl font-bold">Your Attendance Insights</h2>
// //                   <button
// //                     onClick={toggleInsights}
// //                     className="text-gray-500 hover:text-gray-700"
// //                   >
// //                     ✕
// //                   </button>
// //                 </div>

// //                 <div className="mb-4">
// //                   <select
// //                     value={timeRange}
// //                     onChange={(e) => setTimeRange(e.target.value)}
// //                     className="border rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-400"
// //                   >
// //                     <option value="week">Weekly View</option>
// //                     <option value="month">Monthly View</option>
// //                     <option value="year">Yearly View</option>
// //                   </select>
// //                 </div>

// //                 {/* Key Metrics */}
// //                 <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
// //                   <div className="bg-blue-50 p-4 rounded-lg">
// //                     <h3 className="text-sm font-medium text-blue-800">Total Work Days</h3>
// //                     <p className="text-2xl font-bold text-blue-600">
// //                       {insights.totalWorkDays || 0}
// //                     </p>
// //                   </div>
// //                   <div className="bg-green-50 p-4 rounded-lg">
// //                     <h3 className="text-sm font-medium text-green-800">Current Streak</h3>
// //                     <p className="text-2xl font-bold text-green-600">
// //                       {insights.currentStreak || 0} days
// //                     </p>
// //                   </div>
// //                   <div className="bg-yellow-50 p-4 rounded-lg">
// //                     <h3 className="text-sm font-medium text-yellow-800">Total Overtime</h3>
// //                     <p className="text-2xl font-bold text-yellow-600">
// //                       {(insights.totalOvertime || 0).toFixed(2)} hours
// //                     </p>
// //                   </div>
// //                   <div className="bg-orange-50 p-4 rounded-lg">
// //                     <h3 className="text-sm font-medium text-orange-800">Avg. Overtime</h3>
// //                     <p className="text-2xl font-bold text-orange-600">
// //                       {(insights.avgOvertime || 0).toFixed(2)} hours/day
// //                     </p>
// //                   </div>
// //                 </div>

// //                 {/* Charts */}
// //                 <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
// //                   <div className="bg-white p-4 rounded-lg border">
// //                     <h3 className="text-lg font-semibold mb-4">Attendance Pattern</h3>
// //                     <div className="h-64">
// //                       <Bar
// //                         data={attendanceChartData}
// //                         options={{
// //                           responsive: true,
// //                           maintainAspectRatio: false,
// //                           scales: {
// //                             y: {
// //                               beginAtZero: true,
// //                               max: 1,
// //                               ticks: {
// //                                 callback: (value) =>
// //                                   value === 1 ? "Present" : value === 0 ? "Absent" : "",
// //                               },
// //                             },
// //                           },
// //                         }}
// //                       />
// //                     </div>
// //                   </div>
// //                   <div className="bg-white p-4 rounded-lg border">
// //                     <h3 className="text-lg font-semibold mb-4">Overtime Trend</h3>
// //                     <div className="h-64">
// //                       <Line
// //                         data={overtimeChartData}
// //                         options={{
// //                           responsive: true,
// //                           maintainAspectRatio: false,
// //                           scales: {
// //                             y: {
// //                               beginAtZero: true,
// //                               title: {
// //                                 display: true,
// //                                 text: "Hours",
// //                               },
// //                             },
// //                           },
// //                         }}
// //                       />
// //                     </div>
// //                   </div>
// //                 </div>

// //                 {/* Recent Records */}
// //                 <div className="bg-white p-4 rounded-lg border">
// //                   <h3 className="text-lg font-semibold mb-4">Recent Attendance</h3>
// //                   <div className="overflow-x-auto">
// //                     <table className="min-w-full border text-sm">
// //                       <thead className="bg-gray-100 text-left">
// //                         <tr>
// //                           <th className="p-2 border">Date</th>
// //                           <th className="p-2 border">Check In</th>
// //                           <th className="p-2 border">Check Out</th>
// //                           <th className="p-2 border">Total Hours</th>
// //                           <th className="p-2 border">Overtime</th>
// //                         </tr>
// //                       </thead>
// //                       <tbody>
// //                         {attendances
// //                           .filter((a) => a.employee && a.employee.id === employeeId)
// //                           .slice(0, 5)
// //                           .map((record, index) => (
// //                             <tr key={index} className="border-t hover:bg-gray-50">
// //                               <td className="p-2 border">{record.workDate}</td>
// //                               <td className="p-2 border">{record.checkInTime}</td>
// //                               <td className="p-2 border">{record.checkOutTime}</td>
// //                               <td className="p-2 border">{record.totalHours} hrs</td>
// //                               <td className="p-2 border">
// //                                 {record.overtimeHours || 0} hrs
// //                               </td>
// //                             </tr>
// //                           ))}
// //                         {attendances.filter((a) => a.employee && a.employee.id === employeeId)
// //                           .length === 0 && (
// //                           <tr>
// //                             <td colSpan="5" className="p-4 text-center text-gray-500">
// //                               No attendance records found
// //                             </td>
// //                           </tr>
// //                         )}
// //                       </tbody>
// //                     </table>
// //                   </div>
// //                 </div>
// //               </div>
// //             </motion.div>
// //           </div>
// //         )}
// //       </div>
// //       <Footer />
// //     </>
// //   );
// // };

// // export default AttendanceManagement;


// import React, { useEffect, useState } from "react";
// import axios from "axios";
// import HeaderNavbar from "../component/HeaderNavbar";
// import Footer from "../component/Footer";
// import { FaChartLine, FaClock, FaCalendarAlt, FaUserClock } from "react-icons/fa";
// import { motion } from "framer-motion";
// import { Bar, Line, Pie } from "react-chartjs-2";
// import { Chart, registerables } from "chart.js";

// // Register Chart.js components
// Chart.register(...registerables);

// const AttendanceManagement = () => {
//   const [attendances, setAttendances] = useState([]);
//   const [modalOpen, setModalOpen] = useState(false);
//   const [filterId, setFilterId] = useState("");
//   const [showInsights, setShowInsights] = useState(false);
//   const [employeeId, setEmployeeId] = useState(null);
//   const [employeeDetails, setEmployeeDetails] = useState(null);
//   const [timeRange, setTimeRange] = useState("month");
//   const [selectedDate, setSelectedDate] = useState(null);

//   const [form, setForm] = useState({
//     employeeId: "",
//     workDate: "",
//     checkInTime: "",
//     checkOutTime: "",
//   });

//   const token = localStorage.getItem("token");
//   const config = { headers: { Authorization: `Bearer ${token}` } };

//   useEffect(() => {
//     fetchAttendances();
//     fetchEmployeeDetails();
//   }, []);

//   const fetchEmployeeDetails = async () => {
//     try {
//       const res = await axios.get("http://localhost:8080/api/employees/me", config);
//       setEmployeeId(res.data.id);
//       setEmployeeDetails(res.data);
//     } catch (err) {
//       console.error("Error fetching employee details", err);
//     }
//   };

//   const fetchAttendances = async () => {
//     const res = await axios.get("http://localhost:8080/api/attendance", config);
//     setAttendances(res.data);
//   };

//   const handleChange = (e) => {
//     setForm({ ...form, [e.target.name]: e.target.value });
//   };

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     await axios.post("http://localhost:8080/api/attendance", form, config);
//     fetchAttendances();
//     closeModal();
//   };

//   const openModal = () => {
//     setForm({ employeeId: "", workDate: "", checkInTime: "", checkOutTime: "" });
//     setModalOpen(true);
//   };

//   const closeModal = () => {
//     setModalOpen(false);
//   };

//   const toggleInsights = () => {
//     setShowInsights(!showInsights);
//     if (!showInsights) {
//       setSelectedDate(null);
//     }
//   };

//   // Filter attendances for current employee
//   const getEmployeeAttendances = () => {
//     if (!employeeId) return [];
//     return attendances.filter((a) => a.employee && a.employee.id === employeeId);
//   };

//   // Process data for charts and insights
//   const processAttendanceData = () => {
//     const employeeAttendances = getEmployeeAttendances();
//     const now = new Date();
//     let labels = [];
//     let presentData = [];
//     let overtimeData = [];
//     let detailedRecords = [];

//     if (timeRange === "week") {
//       // Weekly view
//       labels = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
//       presentData = Array(7).fill(0);
//       overtimeData = Array(7).fill(0);
      
//       // Get current week dates
//       const currentDate = new Date();
//       const currentDay = currentDate.getDay();
//       const startDate = new Date(currentDate);
//       startDate.setDate(currentDate.getDate() - currentDay + (currentDay === 0 ? -6 : 1));
      
//       for (let i = 0; i < 7; i++) {
//         const date = new Date(startDate);
//         date.setDate(startDate.getDate() + i);
        
//         const formattedDate = date.toISOString().split('T')[0];
//         const attendance = employeeAttendances.find(a => a.workDate === formattedDate);
        
//         if (attendance) {
//           presentData[i] = 1;
//           overtimeData[i] = parseFloat(attendance.overtimeHours) || 0;
//           detailedRecords.push({
//             date: formattedDate,
//             day: labels[i],
//             checkIn: attendance.checkInTime,
//             checkOut: attendance.checkOutTime,
//             totalHours: attendance.totalHours,
//             overtime: attendance.overtimeHours
//           });
//         } else {
//           detailedRecords.push({
//             date: formattedDate,
//             day: labels[i],
//             checkIn: "Absent",
//             checkOut: "Absent",
//             totalHours: 0,
//             overtime: 0
//           });
//         }
//       }
//     } else if (timeRange === "month") {
//       // Monthly view
//       const daysInMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();
//       labels = Array.from({ length: daysInMonth }, (_, i) => i + 1);
//       presentData = Array(daysInMonth).fill(0);
//       overtimeData = Array(daysInMonth).fill(0);
      
//       for (let day = 1; day <= daysInMonth; day++) {
//         const date = new Date(now.getFullYear(), now.getMonth(), day);
//         const formattedDate = date.toISOString().split('T')[0];
//         const attendance = employeeAttendances.find(a => a.workDate === formattedDate);
        
//         if (attendance) {
//           presentData[day - 1] = 1;
//           overtimeData[day - 1] = parseFloat(attendance.overtimeHours) || 0;
//           detailedRecords.push({
//             date: formattedDate,
//             day: `Day ${day}`,
//             checkIn: attendance.checkInTime,
//             checkOut: attendance.checkOutTime,
//             totalHours: attendance.totalHours,
//             overtime: attendance.overtimeHours
//           });
//         }
//       }
//     } else {
//       // Yearly view
//       labels = [
//         "Jan", "Feb", "Mar", "Apr", "May", "Jun", 
//         "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
//       ];
//       presentData = Array(12).fill(0);
//       overtimeData = Array(12).fill(0);
      
//       for (let month = 0; month < 12; month++) {
//         const monthAttendances = employeeAttendances.filter(a => {
//           const date = new Date(a.workDate);
//           return date.getMonth() === month && date.getFullYear() === now.getFullYear();
//         });
        
//         if (monthAttendances.length > 0) {
//           presentData[month] = monthAttendances.length;
//           overtimeData[month] = monthAttendances.reduce(
//             (sum, a) => sum + (parseFloat(a.overtimeHours) || 0), 0
//           );
//         }
//       }
//     }

//     return { labels, presentData, overtimeData, detailedRecords };
//   };

//   const { labels, presentData, overtimeData, detailedRecords } = processAttendanceData();

//   // Calculate comprehensive insights
//   const calculateInsights = () => {
//     const employeeAttendances = getEmployeeAttendances();
//     if (employeeAttendances.length === 0) return {};

//     // Basic stats
//     const totalWorkDays = employeeAttendances.length;

//     const totalOvertime = employeeAttendances.reduce(
//       (sum, a) => sum + (parseFloat(a.overtimeHours) || 0),
//       0
//     );

//     const avgOvertime = totalWorkDays > 0 ? totalOvertime / totalWorkDays : 0;

//     const avgWorkingHours = totalWorkDays > 0
//       ? employeeAttendances.reduce(
//           (sum, a) => sum + (parseFloat(a.totalHours) || 0),
//           0
//         ) / totalWorkDays
//       : 0;


//     // Current streak calculation
//     let currentStreak = 0;
//     const sortedAttendance = [...employeeAttendances].sort(
//       (a, b) => new Date(b.workDate) - new Date(a.workDate)
//     );
//     const yesterday = new Date();
//     yesterday.setDate(yesterday.getDate() - 1);

//     for (let i = 0; i < sortedAttendance.length; i++) {
//       const attDate = new Date(sortedAttendance[i].workDate);
//       if (i === 0 && attDate.toDateString() === yesterday.toDateString()) {
//         currentStreak = 1;
//       } else if (i > 0) {
//         const prevDate = new Date(sortedAttendance[i - 1].workDate);
//         const dayDiff = (prevDate - attDate) / (1000 * 60 * 60 * 24);
//         if (dayDiff === 1) {
//           currentStreak++;
//         } else {
//           break;
//         }
//       }
//     }

//     // Early/late arrival analysis
//     const arrivalTimes = employeeAttendances.map(a => {
//       const [hours, minutes] = a.checkInTime.split(':').map(Number);
//       return hours * 60 + minutes; // Convert to minutes since midnight
//     });
//     const avgArrivalTime = arrivalTimes.reduce((a, b) => a + b, 0) / arrivalTimes.length;
//     const avgArrivalStr = `${Math.floor(avgArrivalTime / 60)}:${(avgArrivalTime % 60).toString().padStart(2, '0')}`;

//     // Find earliest and latest check-ins
//     const minArrival = Math.min(...arrivalTimes);
//     const maxArrival = Math.max(...arrivalTimes);
//     const minArrivalStr = `${Math.floor(minArrival / 60)}:${(minArrival % 60).toString().padStart(2, '0')}`;
//     const maxArrivalStr = `${Math.floor(maxArrival / 60)}:${(maxArrival % 60).toString().padStart(2, '0')}`;

//     return {
//       totalWorkDays,
//       totalOvertime,
//       avgOvertime,
//       avgWorkingHours,
//       currentStreak,
//       avgArrivalTime: avgArrivalStr,
//       earliestCheckIn: minArrivalStr,
//       latestCheckIn: maxArrivalStr,
//       lastAttendance: sortedAttendance[0] ? new Date(sortedAttendance[0].workDate).toLocaleDateString() : "Never"
//     };
//   };

//   const insights = calculateInsights();

//   // Chart data configurations
//   const attendanceChartData = {
//     labels,
//     datasets: [
//       {
//         label: "Work Days",
//         data: presentData,
//         backgroundColor: "rgba(54, 162, 235, 0.7)",
//         borderColor: "rgba(54, 162, 235, 1)",
//         borderWidth: 1,
//       },
//     ],
//   };

//   const overtimeChartData = {
//     labels,
//     datasets: [
//       {
//         label: "Overtime Hours",
//         data: overtimeData,
//         backgroundColor: "rgba(255, 206, 86, 0.7)",
//         borderColor: "rgba(255, 206, 86, 1)",
//         borderWidth: 1,
//         tension: 0.1,
//       },
//     ],
//   };

//   const workingHoursDistribution = {
//     labels: ["0-4 hrs", "4-6 hrs", "6-8 hrs", "8+ hrs"],
//     datasets: [
//       {
//         data: [
//           getEmployeeAttendances().filter(a => parseFloat(a.totalHours) < 4).length,
//           getEmployeeAttendances().filter(a => parseFloat(a.totalHours) >= 4 && parseFloat(a.totalHours) < 6).length,
//           getEmployeeAttendances().filter(a => parseFloat(a.totalHours) >= 6 && parseFloat(a.totalHours) < 8).length,
//           getEmployeeAttendances().filter(a => parseFloat(a.totalHours) >= 8).length,
//         ],
//         backgroundColor: [
//           "rgba(255, 99, 132, 0.7)",
//           "rgba(54, 162, 235, 0.7)",
//           "rgba(255, 206, 86, 0.7)",
//           "rgba(75, 192, 192, 0.7)",
//         ],
//         borderColor: [
//           "rgba(255, 99, 132, 1)",
//           "rgba(54, 162, 235, 1)",
//           "rgba(255, 206, 86, 1)",
//           "rgba(75, 192, 192, 1)",
//         ],
//         borderWidth: 1,
//       },
//     ],
//   };

//   // Get detailed records for selected date
//   const getDateDetails = () => {
//     if (!selectedDate) return null;
    
//     if (timeRange === "week") {
//       return detailedRecords.find(r => r.date === selectedDate);
//     } else if (timeRange === "month") {
//       return detailedRecords.find(r => r.date === selectedDate);
//     }
//     return null;
//   };

//   const dateDetails = getDateDetails();

//   return (
//     <>
//       <HeaderNavbar />
//       <div className="p-6 min-h-screen bg-[#eaeaea]" >
//         <div className="flex justify-between items-center mb-6">
//           <h2 className="text-2xl font-bold">Attendance Management</h2>
//           <div className="flex items-center gap-4">
//             <input
//               type="text"
//               placeholder="Filter by Employee ID"
//               value={filterId}
//               onChange={(e) => setFilterId(e.target.value)}
//               className="border px-3 py-2 rounded"
//             />
//             <button
//               onClick={openModal}
//               className="bg-gradient-to-r from-[#1f3b57] via-[#476b8c] to-[#1c2e44] text-white px-4 py-2 rounded hover:bg-blue-700"
//             >
//               Add Attendance
//             </button>
//             <button
//               onClick={toggleInsights}
//               className="p-2 text-blue-600 hover:text-blue-800 flex items-center gap-2"
//               title="View Insights"
//             >
//               <FaChartLine size={20} />
//               <span>My Insights</span>
//             </button>
//           </div>
//         </div>

//         <div className="overflow-x-auto">
//           <table className="w-full table-auto bg-gradient-to-br from-blue-100 to-blue-200 border text-left">
//             <thead className="bg-gradient-to-br from-[#1f3b57] via-[#476b8c] to-[#1c2e44] text-white">
//               <tr>
//                 <th className="p-2 border">Employee ID</th>
//                 <th className="p-2 border">Date</th>
//                 <th className="p-2 border">Check In</th>
//                 <th className="p-2 border">Check Out</th>
//                 <th className="p-2 border">Total Hours</th>
//                 <th className="p-2 border">Overtime</th>
//               </tr>
//             </thead>
//             <tbody>
//               {attendances
//                 .filter((a) =>
//                   filterId === "" || a.employee.id.toString().includes(filterId)
//                 )
//                 .map((a) => (
//                   <tr key={a.id} className="border-b">
//                     <td className="p-2 border">{a.employee.id}</td>
//                     <td className="p-2 border">{a.workDate}</td>
//                     <td className="p-2 border">{a.checkInTime}</td>
//                     <td className="p-2 border">{a.checkOutTime}</td>
//                     <td className="p-2 border">{a.totalHours}</td>
//                     <td className="p-2 border">{a.overtimeHours}</td>
//                   </tr>
//                 ))}
//               {attendances.filter((a) =>
//                 filterId === "" || a.employee.id.toString().includes(filterId)
//               ).length === 0 && (
//                 <tr>
//                   <td colSpan="6" className="p-4 text-center text-gray-500">
//                     No attendance records found.
//                   </td>
//                 </tr>
//               )}
//             </tbody>
//           </table>
//         </div>

//         {modalOpen && (
//           <div className="fixed inset-0 z-50 backdrop-blur-sm bg-white/10 flex items-center justify-center">
//             <div className="bg-white p-6 rounded shadow-md w-[90%] max-w-lg">
//               <h3 className="text-xl font-semibold mb-4">Add Attendance</h3>
//               <form onSubmit={handleSubmit} className="space-y-4">
//                 <input
//                   type="number"
//                   name="employeeId"
//                   placeholder="Employee ID"
//                   value={form.employeeId}
//                   onChange={handleChange}
//                   required
//                   className="w-full border px-3 py-2 rounded"
//                 />
//                 <input
//                   type="date"
//                   name="workDate"
//                   value={form.workDate}
//                   onChange={handleChange}
//                   required
//                   className="w-full border px-3 py-2 rounded"
//                 />
//                 <input
//                   type="time"
//                   name="checkInTime"
//                   value={form.checkInTime}
//                   onChange={handleChange}
//                   required
//                   className="w-full border px-3 py-2 rounded"
//                 />
//                 <input
//                   type="time"
//                   name="checkOutTime"
//                   value={form.checkOutTime}
//                   onChange={handleChange}
//                   required
//                   className="w-full border px-3 py-2 rounded"
//                 />
//                 <div className="flex justify-end gap-4">
//                   <button
//                     type="button"
//                     onClick={closeModal}
//                     className="bg-gray-300 text-black px-4 py-2 rounded hover:bg-gray-400"
//                   >
//                     Cancel
//                   </button>
//                   <button
//                     type="submit"
//                     className="bg-gradient-to-r from-[#1f3b57] via-[#476b8c] to-[#1c2e44] text-white px-4 py-2 rounded hover:bg-blue-700"
//                   >
//                     Add
//                   </button>
//                 </div>
//               </form>
//             </div>
//           </div>
//         )}

//         {/* Enhanced Insights Panel */}
//         {showInsights && (
//           <div className="fixed inset-0 z-50 bg-black bg-opacity-50 flex items-center justify-center p-4">
//             <motion.div
//               initial={{ opacity: 0, scale: 0.9 }}
//               animate={{ opacity: 1, scale: 1 }}
//               exit={{ opacity: 0, scale: 0.9 }}
//               className="bg-white rounded-lg shadow-xl w-full max-w-6xl h-[90vh] overflow-y-auto"
//             >
//               <div className="p-8">
//                 <div className="flex justify-between items-start mb-6">
//                   <div>
//                     <h2 className="text-3xl font-bold">Attendance Analytics Dashboard</h2>
//                     {employeeDetails && (
//                       <p className="text-lg text-gray-600 mt-2">
//                         {employeeDetails.firstName} {employeeDetails.lastName} • {employeeDetails.department}
//                       </p>
//                     )}
//                   </div>
//                   <button
//                     onClick={toggleInsights}
//                     className="text-gray-500 hover:text-gray-700 text-2xl"
//                   >
//                     ✕
//                   </button>
//                 </div>

//                 {/* Time Range Selector */}
//                 <div className="mb-6 flex justify-between items-center">
//                   <div className="flex gap-4">
//                     <button
//                       onClick={() => setTimeRange("week")}
//                       className={`px-4 py-2 rounded ${timeRange === "week" ? 'bg-blue-600 text-white' : 'bg-gray-200'}`}
//                     >
//                       Weekly
//                     </button>
//                     <button
//                       onClick={() => setTimeRange("month")}
//                       className={`px-4 py-2 rounded ${timeRange === "month" ? 'bg-blue-600 text-white' : 'bg-gray-200'}`}
//                     >
//                       Monthly
//                     </button>
//                     <button
//                       onClick={() => setTimeRange("year")}
//                       className={`px-4 py-2 rounded ${timeRange === "year" ? 'bg-blue-600 text-white' : 'bg-gray-200'}`}
//                     >
//                       Yearly
//                     </button>
//                   </div>
//                   <div className="text-gray-600">
//                     {timeRange === "week" ? "This Week" : 
//                      timeRange === "month" ? "This Month" : "This Year"}
//                   </div>
//                 </div>

//                 {/* Key Metrics Grid */}
//                 <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
//                   <div className="bg-blue-50 p-6 rounded-xl border border-blue-100">
//                     <div className="flex items-center gap-4">
//                       <div className="bg-blue-100 p-3 rounded-full">
//                         <FaCalendarAlt className="text-blue-600 text-xl" />
//                       </div>
//                       <div>
//                         <p className="text-sm text-blue-800">Total Work Days</p>
//                         <p className="text-2xl font-bold text-blue-600">
//                           {insights.totalWorkDays || 0}
//                         </p>
//                       </div>
//                     </div>
//                   </div>

//                   <div className="bg-green-50 p-6 rounded-xl border border-green-100">
//                     <div className="flex items-center gap-4">
//                       <div className="bg-green-100 p-3 rounded-full">
//                         <FaUserClock className="text-green-600 text-xl" />
//                       </div>
//                       <div>
//                         <p className="text-sm text-green-800">Current Streak</p>
//                         <p className="text-2xl font-bold text-green-600">
//                           {insights.currentStreak || 0} days
//                         </p>
//                       </div>
//                     </div>
//                   </div>

//                   <div className="bg-yellow-50 p-6 rounded-xl border border-yellow-100">
//                     <div className="flex items-center gap-4">
//                       <div className="bg-yellow-100 p-3 rounded-full">
//                         <FaClock className="text-yellow-600 text-xl" />
//                       </div>
//                       <div>
//                         <p className="text-sm text-yellow-800">Total Overtime</p>
//                         <p className="text-2xl font-bold text-yellow-600">
//                           {(insights.totalOvertime || 0).toFixed(2)} hours
//                         </p>
//                       </div>
//                     </div>
//                   </div>

//                   <div className="bg-purple-50 p-6 rounded-xl border border-purple-100">
//                     <div className="flex items-center gap-4">
//                       <div className="bg-purple-100 p-3 rounded-full">
//                         <FaChartLine className="text-purple-600 text-xl" />
//                       </div>
//                       <div>
//                         <p className="text-sm text-purple-800">Avg. Working Hours</p>
//                         <p className="text-2xl font-bold text-purple-600">
//                           {(insights.avgWorkingHours || 0).toFixed(2)} hrs/day
//                         </p>
//                       </div>
//                     </div>
//                   </div>
//                 </div>

//                 {/* Charts Section */}
//                 <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
//                   <div className="bg-white p-6 rounded-xl border shadow-sm">
//                     <h3 className="text-xl font-semibold mb-4">
//                       {timeRange === "week" ? "Daily Attendance" : 
//                        timeRange === "month" ? "Monthly Attendance Pattern" : "Yearly Attendance Overview"}
//                     </h3>
//                     <div className="h-80">
//                       <Bar
//                         data={attendanceChartData}
//                         options={{
//                           responsive: true,
//                           maintainAspectRatio: false,
//                           onClick: (e, elements) => {
//                             if (elements.length > 0 && (timeRange === "week" || timeRange === "month")) {
//                               const index = elements[0].index;
//                               setSelectedDate(detailedRecords[index].date);
//                             }
//                           },
//                           scales: {
//                             y: {
//                               beginAtZero: true,
//                               max: timeRange === "year" ? undefined : 1,
//                               ticks: {
//                                 callback: timeRange === "year" ? undefined : 
//                                   (value) => value === 1 ? "Present" : value === 0 ? "Absent" : ""
//                               },
//                             },
//                           },
//                         }}
//                       />
//                     </div>
//                   </div>

//                   <div className="bg-white p-6 rounded-xl border shadow-sm">
//                     <h3 className="text-xl font-semibold mb-4">
//                       {timeRange === "week" ? "Daily Overtime" : 
//                        timeRange === "month" ? "Monthly Overtime Trend" : "Yearly Overtime Summary"}
//                     </h3>
//                     <div className="h-80">
//                       <Line
//                         data={overtimeChartData}
//                         options={{
//                           responsive: true,
//                           maintainAspectRatio: false,
//                           onClick: (e, elements) => {
//                             if (elements.length > 0 && (timeRange === "week" || timeRange === "month")) {
//                               const index = elements[0].index;
//                               setSelectedDate(detailedRecords[index].date);
//                             }
//                           },
//                           scales: {
//                             y: {
//                               beginAtZero: true,
//                               title: {
//                                 display: true,
//                                 text: "Hours",
//                               },
//                             },
//                           },
//                         }}
//                       />
//                     </div>
//                   </div>
//                 </div>

//                 {/* Detailed Analysis Section */}
//                 <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
//                   <div className="bg-white p-6 rounded-xl border shadow-sm">
//                     <h3 className="text-xl font-semibold mb-4">Working Hours Distribution</h3>
//                     <div className="h-64">
//                       <Pie
//                         data={workingHoursDistribution}
//                         options={{
//                           responsive: true,
//                           maintainAspectRatio: false,
//                           plugins: {
//                             legend: {
//                               position: "bottom",
//                             },
//                           },
//                         }}
//                       />
//                     </div>
//                   </div>

//                   <div className="bg-white p-6 rounded-xl border shadow-sm lg:col-span-2">
//                     <h3 className="text-xl font-semibold mb-4">Detailed Time Analysis</h3>
//                     <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
//                       <div>
//                         <h4 className="font-medium text-gray-700 mb-3">Arrival Patterns</h4>
//                         <div className="space-y-3">
//                           <div className="flex justify-between">
//                             <span className="text-gray-600">Average Check-in:</span>
//                             <span className="font-medium">{insights.avgArrivalTime || "N/A"}</span>
//                           </div>
//                           <div className="flex justify-between">
//                             <span className="text-gray-600">Earliest Check-in:</span>
//                             <span className="font-medium">{insights.earliestCheckIn || "N/A"}</span>
//                           </div>
//                           <div className="flex justify-between">
//                             <span className="text-gray-600">Latest Check-in:</span>
//                             <span className="font-medium">{insights.latestCheckIn || "N/A"}</span>
//                           </div>
//                         </div>
//                       </div>
//                       <div>
//                         <h4 className="font-medium text-gray-700 mb-3">Recent Activity</h4>
//                         <div className="space-y-3">
//                           <div className="flex justify-between">
//                             <span className="text-gray-600">Last Recorded Attendance:</span>
//                             <span className="font-medium">{insights.lastAttendance || "N/A"}</span>
//                           </div>
//                           <div className="flex justify-between">
//                             <span className="text-gray-600">Average Overtime:</span>
//                             <span className="font-medium">{(insights.avgOvertime || 0).toFixed(2)} hrs/day</span>
//                           </div>
//                           <div className="flex justify-between">
//                             <span className="text-gray-600">Current Streak:</span>
//                             <span className="font-medium">{insights.currentStreak || 0} days</span>
//                           </div>
//                         </div>
//                       </div>
//                     </div>
//                   </div>
//                 </div>

//                 {/* Date Details and Records */}
//                 <div className="bg-white p-6 rounded-xl border shadow-sm">
//                   <div className="flex justify-between items-center mb-4">
//                     <h3 className="text-xl font-semibold">
//                       {selectedDate ? "Attendance Details" : "Recent Records"}
//                     </h3>
//                     {selectedDate && (
//                       <button 
//                         onClick={() => setSelectedDate(null)}
//                         className="text-sm text-blue-600 hover:underline"
//                       >
//                         Back to overview
//                       </button>
//                     )}
//                   </div>

//                   {selectedDate ? (
//                     <div className="space-y-4">
//                       <div className="bg-blue-50 p-4 rounded-lg">
//                         <h4 className="font-medium text-blue-800 mb-2">
//                           {new Date(selectedDate).toLocaleDateString('en-US', { 
//                             weekday: 'long', 
//                             year: 'numeric', 
//                             month: 'long', 
//                             day: 'numeric' 
//                           })}
//                         </h4>
//                         {dateDetails ? (
//                           <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
//                             <div className="bg-white p-3 rounded border">
//                               <p className="text-sm text-gray-500">Check-in Time</p>
//                               <p className="font-medium">{dateDetails.checkIn}</p>
//                             </div>
//                             <div className="bg-white p-3 rounded border">
//                               <p className="text-sm text-gray-500">Check-out Time</p>
//                               <p className="font-medium">{dateDetails.checkOut}</p>
//                             </div>
//                             <div className="bg-white p-3 rounded border">
//                               <p className="text-sm text-gray-500">Total Hours</p>
//                               <p className="font-medium">{dateDetails.totalHours} hrs</p>
//                             </div>
//                             {dateDetails.overtime > 0 && (
//                               <div className="bg-white p-3 rounded border md:col-span-3">
//                                 <p className="text-sm text-gray-500">Overtime</p>
//                                 <p className="font-medium text-yellow-600">
//                                   {dateDetails.overtime} hours
//                                 </p>
//                               </div>
//                             )}
//                           </div>
//                         ) : (
//                           <p className="text-gray-500">No attendance record for this date</p>
//                         )}
//                       </div>
//                     </div>
//                   ) : (
//                     <div className="overflow-x-auto">
//                       <table className="min-w-full border text-sm">
//                         <thead className="bg-gray-100 text-left">
//                           <tr>
//                             <th className="p-3 border">Date</th>
//                             <th className="p-3 border">Day</th>
//                             <th className="p-3 border">Check In</th>
//                             <th className="p-3 border">Check Out</th>
//                             <th className="p-3 border">Total Hours</th>
//                             <th className="p-3 border">Overtime</th>
//                           </tr>
//                         </thead>
//                         <tbody>
//                           {detailedRecords.slice(0, 10).map((record, index) => (
//                             <tr 
//                               key={index} 
//                               className="border-t hover:bg-gray-50 cursor-pointer"
//                               onClick={() => setSelectedDate(record.date)}
//                             >
//                               <td className="p-3 border">{record.date}</td>
//                               <td className="p-3 border">{record.day}</td>
//                               <td className="p-3 border">{record.checkIn}</td>
//                               <td className="p-3 border">{record.checkOut}</td>
//                               <td className="p-3 border">{record.totalHours} hrs</td>
//                               <td className="p-3 border">{record.overtime || 0} hrs</td>
//                             </tr>
//                           ))}
//                           {detailedRecords.length === 0 && (
//                             <tr>
//                               <td colSpan="6" className="p-4 text-center text-gray-500">
//                                 No attendance records found
//                               </td>
//                             </tr>
//                           )}
//                         </tbody>
//                       </table>
//                     </div>
//                   )}
//                 </div>
//               </div>
//             </motion.div>
//           </div>
//         )}
//       </div>
     
//     </>
//   );
// };

// export default AttendanceManagement;

import React, { useEffect, useState } from "react";
import axios from "axios";
import HeaderNavbar from "../component/HeaderNavbar";
import Footer from "../component/Footer";
import { FaChartLine, FaClock, FaCalendarAlt, FaUserClock } from "react-icons/fa";
import { motion } from "framer-motion";
import { Bar, Line, Pie } from "react-chartjs-2";
import { Chart, registerables } from "chart.js";

// Register Chart.js components
Chart.register(...registerables);

const AttendanceManagement = () => {
  const [attendances, setAttendances] = useState([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [filterId, setFilterId] = useState("");
  const [showInsights, setShowInsights] = useState(false);
  const [employeeId, setEmployeeId] = useState(null);
  const [employeeDetails, setEmployeeDetails] = useState(null);
  const [timeRange, setTimeRange] = useState("week");
  const [selectedDate, setSelectedDate] = useState(null);
  const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth());
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());

  const [form, setForm] = useState({
    employeeId: "",
    workDate: "",
    checkInTime: "",
    checkOutTime: "",
  });

  const token = localStorage.getItem("token");
  const config = { headers: { Authorization: `Bearer ${token}` } };

  useEffect(() => {
    fetchAttendances();
    fetchEmployeeDetails();
  }, []);

  const fetchEmployeeDetails = async () => {
    try {
      const res = await axios.get("http://localhost:8080/api/employees/me", config);
      setEmployeeId(res.data.id);
      setEmployeeDetails(res.data);
    } catch (err) {
      console.error("Error fetching employee details", err);
    }
  };

  const fetchAttendances = async () => {
    const res = await axios.get("http://localhost:8080/api/attendance", config);
    setAttendances(res.data);
  };

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    await axios.post("http://localhost:8080/api/attendance", form, config);
    fetchAttendances();
    closeModal();
  };

  const openModal = () => {
    setForm({ employeeId: "", workDate: "", checkInTime: "", checkOutTime: "" });
    setModalOpen(true);
  };

  const closeModal = () => {
    setModalOpen(false);
  };

  const toggleInsights = () => {
    setShowInsights(!showInsights);
    if (!showInsights) {
      setSelectedDate(null);
      setTimeRange("week");
      setSelectedMonth(new Date().getMonth());
      setSelectedYear(new Date().getFullYear());
    }
  };

  // Filter attendances for current employee
  const getEmployeeAttendances = () => {
    if (!employeeId) return [];
    return attendances.filter((a) => a.employee && a.employee.id === employeeId);
  };

  // Get all available years from attendance data
  const getAvailableYears = () => {
    const years = new Set();
    getEmployeeAttendances().forEach(att => {
      const year = new Date(att.workDate).getFullYear();
      years.add(year);
    });
    return Array.from(years).sort((a, b) => b - a);
  };

  // Process data for charts and insights
  const processAttendanceData = () => {
    const employeeAttendances = getEmployeeAttendances();
    const now = new Date();
    let labels = [];
    let presentData = [];
    let absentData = [];
    let overtimeData = [];
    let detailedRecords = [];

    if (timeRange === "week") {
      // Weekly view - current week
      labels = ["Mon", "Tue", "Wed", "Thu", "Fri"];
      presentData = Array(5).fill(0);
      absentData = Array(5).fill(0);
      overtimeData = Array(5).fill(0);
      
      // Get current week dates (Monday to Friday)
      const currentDate = new Date();
      const currentDay = currentDate.getDay();
      const startDate = new Date(currentDate);
      startDate.setDate(currentDate.getDate() - currentDay + (currentDay === 0 ? -6 : 1)); // Monday
      
      for (let i = 0; i < 5; i++) {
        const date = new Date(startDate);
        date.setDate(startDate.getDate() + i);
        
        const formattedDate = date.toISOString().split('T')[0];
        const attendance = employeeAttendances.find(a => a.workDate === formattedDate);
        
        if (attendance) {
          presentData[i] = 1;
          overtimeData[i] = parseFloat(attendance.overtimeHours) || 0;
          detailedRecords.push({
            date: formattedDate,
            day: labels[i],
            checkIn: attendance.checkInTime,
            checkOut: attendance.checkOutTime,
            totalHours: attendance.totalHours,
            overtime: attendance.overtimeHours
          });
        } else {
          absentData[i] = 1;
          detailedRecords.push({
            date: formattedDate,
            day: labels[i],
            checkIn: "Absent",
            checkOut: "Absent",
            totalHours: 0,
            overtime: 0
          });
        }
      }
    } else if (timeRange === "month") {
      // Monthly view - selected month and year
      const daysInMonth = new Date(selectedYear, selectedMonth + 1, 0).getDate();
      labels = [];
      presentData = [];
      absentData = [];
      overtimeData = [];
      
      for (let day = 1; day <= daysInMonth; day++) {
        const date = new Date(selectedYear, selectedMonth, day);
        const dayOfWeek = date.getDay();
        
        // Skip weekends (Sat=6, Sun=0)
        if (dayOfWeek === 0 || dayOfWeek === 6) continue;
        
        const formattedDate = date.toISOString().split('T')[0];
        const attendance = employeeAttendances.find(a => a.workDate === formattedDate);
        
        labels.push(day);
        
        if (attendance) {
          presentData.push(1);
          absentData.push(0);
          overtimeData.push(parseFloat(attendance.overtimeHours) || 0);
          detailedRecords.push({
            date: formattedDate,
            day: `Day ${day}`,
            checkIn: attendance.checkInTime,
            checkOut: attendance.checkOutTime,
            totalHours: attendance.totalHours,
            overtime: attendance.overtimeHours
          });
        } else {
          presentData.push(0);
          absentData.push(1);
          overtimeData.push(0);
          detailedRecords.push({
            date: formattedDate,
            day: `Day ${day}`,
            checkIn: "Absent",
            checkOut: "Absent",
            totalHours: 0,
            overtime: 0
          });
        }
      }
    } else {
      // Yearly view - selected year
      labels = [
        "Jan", "Feb", "Mar", "Apr", "May", "Jun", 
        "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
      ];
      presentData = Array(12).fill(0);
      overtimeData = Array(12).fill(0);
      
      for (let month = 0; month < 12; month++) {
        const monthAttendances = employeeAttendances.filter(a => {
          const date = new Date(a.workDate);
          return date.getMonth() === month && date.getFullYear() === selectedYear;
        });
        
        if (monthAttendances.length > 0) {
          presentData[month] = monthAttendances.length;
          overtimeData[month] = monthAttendances.reduce(
            (sum, a) => sum + (parseFloat(a.overtimeHours) || 0), 0
          );
        }
      }
    }

    return { labels, presentData, absentData, overtimeData, detailedRecords };
  };

  const { labels, presentData, absentData, overtimeData, detailedRecords } = processAttendanceData();

  // Calculate comprehensive insights
  const calculateInsights = () => {
    const employeeAttendances = getEmployeeAttendances();
    if (employeeAttendances.length === 0) return {};

    // Basic stats
    const totalWorkDays = employeeAttendances.length;

    const totalOvertime = employeeAttendances.reduce(
      (sum, a) => sum + (parseFloat(a.overtimeHours) || 0),
      0
    );

    const avgOvertime = totalWorkDays > 0 ? totalOvertime / totalWorkDays : 0;

    const avgWorkingHours = totalWorkDays > 0
      ? employeeAttendances.reduce(
          (sum, a) => sum + (parseFloat(a.totalHours) || 0),
          0
        ) / totalWorkDays
      : 0;

    // Current streak calculation
    let currentStreak = 0;
    const sortedAttendance = [...employeeAttendances].sort(
      (a, b) => new Date(b.workDate) - new Date(a.workDate)
    );
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);

    for (let i = 0; i < sortedAttendance.length; i++) {
      const attDate = new Date(sortedAttendance[i].workDate);
      if (i === 0 && attDate.toDateString() === yesterday.toDateString()) {
        currentStreak = 1;
      } else if (i > 0) {
        const prevDate = new Date(sortedAttendance[i - 1].workDate);
        const dayDiff = (prevDate - attDate) / (1000 * 60 * 60 * 24);
        if (dayDiff === 1) {
          currentStreak++;
        } else {
          break;
        }
      }
    }

    // Early/late arrival analysis
    const arrivalTimes = employeeAttendances.map(a => {
      const [hours, minutes] = a.checkInTime.split(':').map(Number);
      return hours * 60 + minutes; // Convert to minutes since midnight
    });
    
    const minArrival = arrivalTimes.length > 0 ? Math.min(...arrivalTimes) : 0;
    const maxArrival = arrivalTimes.length > 0 ? Math.max(...arrivalTimes) : 0;
    
    const minArrivalStr = minArrival > 0 
      ? `${Math.floor(minArrival / 60).toString().padStart(2, '0')}:${(minArrival % 60).toString().padStart(2, '0')}`
      : "N/A";
      
    const maxArrivalStr = maxArrival > 0
      ? `${Math.floor(maxArrival / 60).toString().padStart(2, '0')}:${(maxArrival % 60).toString().padStart(2, '0')}`
      : "N/A";

    return {
      totalWorkDays,
      totalOvertime,
      avgOvertime,
      avgWorkingHours,
      currentStreak,
      earliestCheckIn: minArrivalStr,
      latestCheckIn: maxArrivalStr,
      lastAttendance: sortedAttendance[0] ? new Date(sortedAttendance[0].workDate).toLocaleDateString() : "Never"
    };
  };

  const insights = calculateInsights();

  // Chart data configurations
  const attendanceChartData = {
    labels,
    datasets: [
      {
        label: "Present",
        data: presentData,
        backgroundColor: "rgba(54, 162, 235, 0.7)",
        borderColor: "rgba(54, 162, 235, 1)",
        borderWidth: 1,
      },
      {
        label: "Absent",
        data: absentData,
        backgroundColor: "rgba(255, 99, 132, 0.7)",
        borderColor: "rgba(255, 99, 132, 1)",
        borderWidth: 1,
      }
    ],
  };

  const overtimeChartData = {
    labels,
    datasets: [
      {
        label: "Overtime Hours",
        data: overtimeData,
        backgroundColor: "rgba(255, 206, 86, 0.7)",
        borderColor: "rgba(255, 206, 86, 1)",
        borderWidth: 1,
        tension: 0.1,
      },
    ],
  };

  const workingHoursDistribution = {
    labels: ["0-4 hrs", "4-6 hrs", "6-8 hrs", "8+ hrs"],
    datasets: [
      {
        data: [
          getEmployeeAttendances().filter(a => parseFloat(a.totalHours) < 4).length,
          getEmployeeAttendances().filter(a => parseFloat(a.totalHours) >= 4 && parseFloat(a.totalHours) < 6).length,
          getEmployeeAttendances().filter(a => parseFloat(a.totalHours) >= 6 && parseFloat(a.totalHours) < 8).length,
          getEmployeeAttendances().filter(a => parseFloat(a.totalHours) >= 8).length,
        ],
        backgroundColor: [
          "rgba(255, 99, 132, 0.7)",
          "rgba(54, 162, 235, 0.7)",
          "rgba(255, 206, 86, 0.7)",
          "rgba(75, 192, 192, 0.7)",
        ],
        borderColor: [
          "rgba(255, 99, 132, 1)",
          "rgba(54, 162, 235, 1)",
          "rgba(255, 206, 86, 1)",
          "rgba(75, 192, 192, 1)",
        ],
        borderWidth: 1,
      },
    ],
  };

  // Get detailed records for selected date
  const getDateDetails = () => {
    if (!selectedDate) return null;
    
    if (timeRange === "week" || timeRange === "month") {
      return detailedRecords.find(r => r.date === selectedDate);
    }
    return null;
  };

  const dateDetails = getDateDetails();

  // Get available months for the selected year
  const getAvailableMonths = () => {
    const months = new Set();
    getEmployeeAttendances().forEach(att => {
      const date = new Date(att.workDate);
      if (date.getFullYear() === selectedYear) {
        months.add(date.getMonth());
      }
    });
    return Array.from(months).sort((a, b) => a - b);
  };

  const availableYears = getAvailableYears();
  const availableMonths = getAvailableMonths();

  return (
    <>
      <HeaderNavbar />
      <div className="p-6 bg-[#eaeaea]" >
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">Attendance Management</h2>
          <div className="flex items-center gap-4">
            <input
              type="text"
              placeholder="Filter by Employee ID"
              value={filterId}
              onChange={(e) => setFilterId(e.target.value)}
              className="border px-3 py-2 rounded"
            />
            <button
              onClick={openModal}
              className="bg-gradient-to-r from-[#1f3b57] via-[#476b8c] to-[#1c2e44] text-white px-4 py-2 rounded hover:bg-blue-700"
            >
              Add Attendance
            </button>
            <button
              onClick={toggleInsights}
              className="p-2 text-blue-600 hover:text-blue-800 flex items-center gap-2"
              title="View Insights"
            >
              <FaChartLine size={20} />
              <span>My Insights</span>
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full table-auto border text-left">
            <thead className="bg-gradient-to-br from-[#1f3b57] via-[#476b8c] to-[#1c2e44] text-white">
              <tr>
                <th className="p-2 border">Employee ID</th>
                <th className="p-2 border">Date</th>
                <th className="p-2 border">Check In</th>
                <th className="p-2 border">Check Out</th>
                <th className="p-2 border">Total Hours</th>
                <th className="p-2 border">Overtime</th>
              </tr>
            </thead>
            <tbody>
              {attendances
                .filter((a) =>
                  filterId === "" || a.employee.id.toString().includes(filterId)
                )
                .map((a) => (
                  <tr key={a.id} className="border-b">
                    <td className="p-2 border">{a.employee.id}</td>
                    <td className="p-2 border">{a.workDate}</td>
                    <td className="p-2 border">{a.checkInTime}</td>
                    <td className="p-2 border">{a.checkOutTime}</td>
                    <td className="p-2 border">{a.totalHours}</td>
                    <td className="p-2 border">{a.overtimeHours}</td>
                  </tr>
                ))}
              {attendances.filter((a) =>
                filterId === "" || a.employee.id.toString().includes(filterId)
              ).length === 0 && (
                <tr>
                  <td colSpan="6" className="p-4 text-center text-gray-500">
                    No attendance records found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {modalOpen && (
          <div className="fixed inset-0 z-50 backdrop-blur-sm bg-white/10 flex items-center justify-center">
            <div className="bg-white p-6 rounded shadow-md w-[90%] max-w-lg">
              <h3 className="text-xl font-semibold mb-4">Add Attendance</h3>
              <form onSubmit={handleSubmit} className="space-y-4">
                <input
                  type="number"
                  name="employeeId"
                  placeholder="Employee ID"
                  value={form.employeeId}
                  onChange={handleChange}
                  required
                  className="w-full border px-3 py-2 rounded"
                />
                <input
                  type="date"
                  name="workDate"
                  value={form.workDate}
                  onChange={handleChange}
                  required
                  className="w-full border px-3 py-2 rounded"
                />
                <input
                  type="time"
                  name="checkInTime"
                  value={form.checkInTime}
                  onChange={handleChange}
                  required
                  className="w-full border px-3 py-2 rounded"
                />
                <input
                  type="time"
                  name="checkOutTime"
                  value={form.checkOutTime}
                  onChange={handleChange}
                  required
                  className="w-full border px-3 py-2 rounded"
                />
                <div className="flex justify-end gap-4">
                  <button
                    type="button"
                    onClick={closeModal}
                    className="bg-gray-300 text-black px-4 py-2 rounded hover:bg-gray-400"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="bg-gradient-to-r from-[#1f3b57] via-[#476b8c] to-[#1c2e44] text-white px-4 py-2 rounded hover:bg-blue-700"
                  >
                    Add
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Enhanced Insights Panel */}
        {showInsights && (
          <div className="fixed inset-0 z-50 bg-black bg-opacity-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="bg-white rounded-lg shadow-xl w-full max-w-6xl h-[90vh] overflow-y-auto"
            >
              <div className="p-8">
                <div className="flex justify-between items-start mb-6">
                  <div>
                    <h2 className="text-3xl font-bold">Attendance Analytics Dashboard</h2>
                    {employeeDetails && (
                      <p className="text-lg text-gray-600 mt-2">
                        {employeeDetails.firstName} {employeeDetails.lastName} • {employeeDetails.department}
                      </p>
                    )}
                  </div>
                  <button
                    onClick={toggleInsights}
                    className="text-gray-500 hover:text-gray-700 text-2xl"
                  >
                    ✕
                  </button>
                </div>

                {/* Time Range Selector */}
                <div className="mb-6 flex justify-between items-center">
                  <div className="flex gap-4">
                    <button
                      onClick={() => {
                        setTimeRange("week");
                        setSelectedDate(null);
                      }}
                      className={`px-4 py-2 rounded ${timeRange === "week" ? 'bg-blue-600 text-white' : 'bg-gray-200'}`}
                    >
                      Weekly
                    </button>
                    <button
                      onClick={() => {
                        setTimeRange("month");
                        setSelectedDate(null);
                      }}
                      className={`px-4 py-2 rounded ${timeRange === "month" ? 'bg-blue-600 text-white' : 'bg-gray-200'}`}
                    >
                      Monthly
                    </button>
                    <button
                      onClick={() => {
                        setTimeRange("year");
                        setSelectedDate(null);
                      }}
                      className={`px-4 py-2 rounded ${timeRange === "year" ? 'bg-blue-600 text-white' : 'bg-gray-200'}`}
                    >
                      Yearly
                    </button>
                  </div>
                  
                  {timeRange === "month" && (
                    <div className="flex gap-4">
                      <select
                        value={selectedMonth}
                        onChange={(e) => setSelectedMonth(parseInt(e.target.value))}
                        className="border px-3 py-2 rounded"
                      >
                        {availableMonths.map(month => (
                          <option key={month} value={month}>
                            {new Date(0, month).toLocaleString('default', { month: 'long' })}
                          </option>
                        ))}
                      </select>
                      <select
                        value={selectedYear}
                        onChange={(e) => setSelectedYear(parseInt(e.target.value))}
                        className="border px-3 py-2 rounded"
                      >
                        {availableYears.map(year => (
                          <option key={year} value={year}>{year}</option>
                        ))}
                      </select>
                    </div>
                  )}
                  
                  {timeRange === "year" && (
                    <select
                      value={selectedYear}
                      onChange={(e) => setSelectedYear(parseInt(e.target.value))}
                      className="border px-3 py-2 rounded"
                    >
                      {availableYears.map(year => (
                        <option key={year} value={year}>{year}</option>
                      ))}
                    </select>
                  )}
                </div>

                {/* Key Metrics Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                  <div className="bg-blue-50 p-6 rounded-xl border border-blue-100">
                    <div className="flex items-center gap-4">
                      <div className="bg-blue-100 p-3 rounded-full">
                        <FaCalendarAlt className="text-blue-600 text-xl" />
                      </div>
                      <div>
                        <p className="text-sm text-blue-800">Total Work Days</p>
                        <p className="text-2xl font-bold text-blue-600">
                          {insights.totalWorkDays || 0}
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="bg-green-50 p-6 rounded-xl border border-green-100">
                    <div className="flex items-center gap-4">
                      <div className="bg-green-100 p-3 rounded-full">
                        <FaUserClock className="text-green-600 text-xl" />
                      </div>
                      <div>
                        <p className="text-sm text-green-800">Current Streak</p>
                        <p className="text-2xl font-bold text-green-600">
                          {insights.currentStreak || 0} days
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="bg-yellow-50 p-6 rounded-xl border border-yellow-100">
                    <div className="flex items-center gap-4">
                      <div className="bg-yellow-100 p-3 rounded-full">
                        <FaClock className="text-yellow-600 text-xl" />
                      </div>
                      <div>
                        <p className="text-sm text-yellow-800">Total Overtime</p>
                        <p className="text-2xl font-bold text-yellow-600">
                          {(insights.totalOvertime || 0).toFixed(2)} hours
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="bg-purple-50 p-6 rounded-xl border border-purple-100">
                    <div className="flex items-center gap-4">
                      <div className="bg-purple-100 p-3 rounded-full">
                        <FaChartLine className="text-purple-600 text-xl" />
                      </div>
                      <div>
                        <p className="text-sm text-purple-800">Avg. Working Hours</p>
                        <p className="text-2xl font-bold text-purple-600">
                          {(insights.avgWorkingHours || 0).toFixed(2)} hrs/day
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Charts Section */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
                  <div className="bg-white p-6 rounded-xl border shadow-sm">
                    <h3 className="text-xl font-semibold mb-4">
                      {timeRange === "week" ? "Weekly Attendance" : 
                       timeRange === "month" ? "Monthly Attendance" : "Yearly Attendance Overview"}
                    </h3>
                    <div className="h-80">
                      <Bar
                        data={attendanceChartData}
                        options={{
                          responsive: true,
                          maintainAspectRatio: false,
                          onClick: (e, elements) => {
                            if (elements.length > 0 && (timeRange === "week" || timeRange === "month")) {
                              const index = elements[0].index;
                              setSelectedDate(detailedRecords[index].date);
                            }
                          },
                          scales: {
                            y: {
                              beginAtZero: true,
                              max: timeRange === "year" ? undefined : 1,
                              ticks: {
                                callback: timeRange === "year" ? undefined : 
                                  (value) => value === 1 ? "Present" : value === 0 ? "Absent" : ""
                              },
                            },
                          },
                        }}
                      />
                    </div>
                  </div>

                  <div className="bg-white p-6 rounded-xl border shadow-sm">
                    <h3 className="text-xl font-semibold mb-4">
                      {timeRange === "week" ? "Weekly Overtime" : 
                       timeRange === "month" ? "Monthly Overtime" : "Yearly Overtime Summary"}
                    </h3>
                    <div className="h-80">
                      <Line
                        data={overtimeChartData}
                        options={{
                          responsive: true,
                          maintainAspectRatio: false,
                          onClick: (e, elements) => {
                            if (elements.length > 0 && (timeRange === "week" || timeRange === "month")) {
                              const index = elements[0].index;
                              setSelectedDate(detailedRecords[index].date);
                            }
                          },
                          scales: {
                            y: {
                              beginAtZero: true,
                              title: {
                                display: true,
                                text: "Hours",
                              },
                            },
                          },
                        }}
                      />
                    </div>
                  </div>
                </div>

                {/* Detailed Analysis Section */}
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
                  <div className="bg-white p-6 rounded-xl border shadow-sm">
                    <h3 className="text-xl font-semibold mb-4">Working Hours Distribution</h3>
                    <div className="h-64">
                      <Pie
                        data={workingHoursDistribution}
                        options={{
                          responsive: true,
                          maintainAspectRatio: false,
                          plugins: {
                            legend: {
                              position: "bottom",
                            },
                          },
                        }}
                      />
                    </div>
                  </div>

                  <div className="bg-white p-6 rounded-xl border shadow-sm lg:col-span-2">
                    <h3 className="text-xl font-semibold mb-4">Detailed Time Analysis</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <h4 className="font-medium text-gray-700 mb-3">Arrival Patterns</h4>
                        <div className="space-y-3">
                          <div className="flex justify-between">
                            <span className="text-gray-600">Earliest Check-in:</span>
                            <span className="font-medium">{insights.earliestCheckIn || "N/A"}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600">Latest Check-in:</span>
                            <span className="font-medium">{insights.latestCheckIn || "N/A"}</span>
                          </div>
                        </div>
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-700 mb-3">Recent Activity</h4>
                        <div className="space-y-3">
                          <div className="flex justify-between">
                            <span className="text-gray-600">Last Recorded Attendance:</span>
                            <span className="font-medium">{insights.lastAttendance || "N/A"}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600">Average Overtime:</span>
                            <span className="font-medium">{(insights.avgOvertime || 0).toFixed(2)} hrs/day</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600">Current Streak:</span>
                            <span className="font-medium">{insights.currentStreak || 0} days</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Date Details and Records */}
                <div className="bg-white p-6 rounded-xl border shadow-sm">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="text-xl font-semibold">
                      {selectedDate ? "Attendance Details" : "Recent Records"}
                    </h3>
                    {selectedDate && (
                      <button 
                        onClick={() => setSelectedDate(null)}
                        className="text-sm text-blue-600 hover:underline"
                      >
                        Back to overview
                      </button>
                    )}
                  </div>

                  {selectedDate ? (
                    <div className="space-y-4">
                      <div className="bg-blue-50 p-4 rounded-lg">
                        <h4 className="font-medium text-blue-800 mb-2">
                          {new Date(selectedDate).toLocaleDateString('en-US', { 
                            weekday: 'long', 
                            year: 'numeric', 
                            month: 'long', 
                            day: 'numeric' 
                          })}
                        </h4>
                        {dateDetails ? (
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div className="bg-white p-3 rounded border">
                              <p className="text-sm text-gray-500">Check-in Time</p>
                              <p className="font-medium">{dateDetails.checkIn}</p>
                            </div>
                            <div className="bg-white p-3 rounded border">
                              <p className="text-sm text-gray-500">Check-out Time</p>
                              <p className="font-medium">{dateDetails.checkOut}</p>
                            </div>
                            <div className="bg-white p-3 rounded border">
                              <p className="text-sm text-gray-500">Total Hours</p>
                              <p className="font-medium">{dateDetails.totalHours} hrs</p>
                            </div>
                            {dateDetails.overtime > 0 && (
                              <div className="bg-white p-3 rounded border md:col-span-3">
                                <p className="text-sm text-gray-500">Overtime</p>
                                <p className="font-medium text-yellow-600">
                                  {dateDetails.overtime} hours
                                </p>
                              </div>
                            )}
                          </div>
                        ) : (
                          <p className="text-gray-500">No attendance record for this date</p>
                        )}
                      </div>
                    </div>
                  ) : (
                    <div className="overflow-x-auto">
                      <table className="min-w-full border text-sm">
                        <thead className="bg-gray-100 text-left">
                          <tr>
                            <th className="p-3 border">Date</th>
                            <th className="p-3 border">Day</th>
                            <th className="p-3 border">Check In</th>
                            <th className="p-3 border">Check Out</th>
                            <th className="p-3 border">Total Hours</th>
                            <th className="p-3 border">Overtime</th>
                          </tr>
                        </thead>
                        <tbody>
                          {detailedRecords.slice(0, 10).map((record, index) => (
                            <tr 
                              key={index} 
                              className="border-t hover:bg-gray-50 cursor-pointer"
                              onClick={() => setSelectedDate(record.date)}
                            >
                              <td className="p-3 border">{record.date}</td>
                              <td className="p-3 border">{record.day}</td>
                              <td className="p-3 border">{record.checkIn}</td>
                              <td className="p-3 border">{record.checkOut}</td>
                              <td className="p-3 border">{record.totalHours} hrs</td>
                              <td className="p-3 border">{record.overtime || 0} hrs</td>
                            </tr>
                          ))}
                          {detailedRecords.length === 0 && (
                            <tr>
                              <td colSpan="6" className="p-4 text-center text-gray-500">
                                No attendance records found
                              </td>
                            </tr>
                          )}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </div>
      <Footer />
    </>
  );
};

export default AttendanceManagement;

