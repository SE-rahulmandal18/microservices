import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import RegisterPage from './pages/RegisterPage';
import LoginPage from './pages/LoginPage';
import ForgotPassword from "./pages/ForgotPassword";
import Dashboard from "./pages/Dashboard";
import ManageUsers from "./pages/ManageUsers";
import Reports from "./pages/Reports";
import EmployeeManagement from "./pages/EmployeeManagement";
import PayrollProcessing from "./pages/PayrollProcessing";
import PayrollHistory from "./pages/PayrollHistory";
import Profile from "./pages/Profile";
import LandingPage from "./pages/LandingPage";
import AboutPage from "./pages/AboutPage";
import TransactionStatus from "./pages/TransactionStatus";
import PrivateRoute from "./component/PrivateRoute";
import AttendanceManagement from "./pages/AttendanceManagement";
import LeaveForm from "./pages/LeaveManagement";
import AuditLogManagement from "./pages/AuditLogManagement";
import LeaveRecordsManagement from "./pages/LeaveRecordsManagement";
import HeaderNavbar from "./component/HeaderNavbar"; 
import Chatbot from './component/Chatbot';

function AppLayout() {
  const path = window.location.pathname;

  const isPublicRoute = ["/login", "/register", "/forgot-password"].includes(path);
  return (
    <>
     {!isPublicRoute && <HeaderNavbar />}
     <div className="pt-16">
      <Routes>
      <Route path="/" element={<LandingPage />} />
        <Route path="/register" element={<RegisterPage />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="/dashboard" element={<PrivateRoute><Dashboard /></PrivateRoute>} />
        <Route path="/about" element={<AboutPage />} />
        <Route path="*" element={<LoginPage />} />
        
        {/* ADMIN */}
        <Route path="/manage-users" element={<PrivateRoute><ManageUsers /></PrivateRoute>} />
        <Route path="/reports" element={<PrivateRoute><Reports /></PrivateRoute>} />
        <Route path="/transaction-status" element={<PrivateRoute><TransactionStatus /></PrivateRoute>} />
        <Route path="/audit-logs" element={<PrivateRoute><AuditLogManagement /></PrivateRoute>} />

        {/* HR */}
        <Route path="/employee-management" element={<PrivateRoute><EmployeeManagement /></PrivateRoute>} />
        <Route path="/payroll" element={<PrivateRoute><PayrollProcessing /></PrivateRoute>} />
        <Route path="/leave-records" element={<PrivateRoute><LeaveRecordsManagement /></PrivateRoute>} />


        {/* EMPLOYEE */}
        <Route path="/payslips" element={<PrivateRoute><PayrollHistory /></PrivateRoute>} />
        <Route path="/profile" element={<PrivateRoute><Profile /></PrivateRoute>} />
        <Route path="/attendance-management" element={<PrivateRoute><AttendanceManagement /></PrivateRoute>} />
        <Route path="/leave-management" element={<PrivateRoute><LeaveForm /></PrivateRoute>} />
      </Routes>
      </div>
    </>
  );
}

function App() {
  return (
    <Router>
      <AppLayout />
      <ToastContainer position="top-right" autoClose={3000} hideProgressBar />
      <Chatbot/>
    </Router>
  );
}

export default App;
