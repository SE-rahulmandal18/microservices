import React, { useEffect, useState } from "react";
import axios from "axios";
import Footer from '../component/Footer';
import HeaderNavbar from "../component/HeaderNavbar";

const TransactionStatus = () => {
  const [transactions, setTransactions] = useState([]);
  const token = localStorage.getItem("token");

  const fetchTransactions = async () => {
    try {
      const res = await axios.get("http://localhost:8080/api/transactions", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      setTransactions(res.data);
    } catch (err) {
      console.error("Failed to fetch transactions", err);
    }
  };

  const retryTransaction = async (id) => {
    try {
      await axios.post(
        `http://localhost:8080/api/transactions/${id}/retry`,
        {},
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      fetchTransactions(); // Refresh the list
    } catch (err) {
      console.error("Retry failed", err);
    }
  };

  useEffect(() => {
    fetchTransactions();
  }, []);

  return (
    <>
    <HeaderNavbar />
    <div className="max-w-6xl mx-auto p-6">
      <h2 className="text-2xl font-bold mb-4">Bank Transaction Status</h2>

      <div className="overflow-x-auto">
        <table className="min-w-full text-sm border border-gray-300">
          <thead className="bg-gray-100 text-left">
            <tr>
              <th className="p-2 border">#</th>
              <th className="p-2 border">Payroll ID</th>
              <th className="p-2 border">Bank Account</th>
              <th className="p-2 border">Amount ($)</th>
              <th className="p-2 border">Status</th>
              <th className="p-2 border">Action</th>
            </tr>
          </thead>
          <tbody>
            {transactions.map((tx, index) => (
              <tr key={tx.id} className="border-t">
                <td className="p-2 border">{index + 1}</td>
                <td className="p-2 border">{tx.payroll?.id}</td>
                <td className="p-2 border">{tx.bankAccount}</td>
                <td className="p-2 border font-semibold">${tx.amount}</td>
                <td className="p-2 border">
                  <span
                    className={`px-2 py-1 rounded text-xs font-medium ${
                      tx.status === "SUCCESS"
                        ? "bg-green-100 text-green-700"
                        : tx.status === "FAILED"
                        ? "bg-red-100 text-red-700"
                        : "bg-yellow-100 text-yellow-700"
                    }`}
                  >
                    {tx.status}
                  </span>
                </td>
                <td className="p-2 border">
                  {tx.status === "FAILED" && (
                    <button
                      className="bg-yellow-500 text-white text-xs px-3 py-1 rounded hover:bg-yellow-600 transition"
                      onClick={() => retryTransaction(tx.id)}
                    >
                      🔄 Retry
                    </button>
                  )}
                </td>
              </tr>
            ))}
            {transactions.length === 0 && (
              <tr>
                <td colSpan="6" className="text-center py-4 text-gray-500">
                  No transactions found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  
    </>
  );
};

export default TransactionStatus;
