import React, { useEffect, useState } from "react";
import axios from "axios";
import { saveAs } from "file-saver";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import HeaderNavbar from "../component/HeaderNavbar";

const AuditLogManagement = () => {
  const [logs, setLogs] = useState([]);
  const [filteredLogs, setFilteredLogs] = useState([]);
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");

  useEffect(() => {
    fetchAuditLogs();
  }, []);

  const token = localStorage.getItem("token");

  const config = { headers: { Authorization: `Bearer ${token}` } };

  const fetchAuditLogs = async () => {
    try {
      const response = await axios.get("http://localhost:8080/api/audit-logs", config);
      setLogs(response.data);
      setFilteredLogs(response.data);
    } catch (error) {
      console.error("Failed to fetch audit logs", error);
    }
  };

  const handleFilter = () => {
    const from = new Date(fromDate);
    const to = new Date(toDate);
    const filtered = logs.filter(log => {
      const performedAt = new Date(log.performedAt);
      return performedAt >= from && performedAt <= to;
    });
    setFilteredLogs(filtered);
  };

  const exportCSV = () => {
    const csv = [
      ["Action", "Performed By", "Performed At", "Details"],
      ...filteredLogs.map(log => [
        log.action,
        log.performedBy?.username,
        log.performedAt,
        log.details
      ])
    ];
    const csvContent = "data:text/csv;charset=utf-8," + csv.map(e => e.join(",")).join("\n");
    const blob = new Blob([csvContent], { type: "text/csv" });
    saveAs(blob, "audit_logs.csv");
  };

  const exportPDF = () => {
    const doc = new jsPDF();
    doc.text("Audit Logs", 14, 10);
    autoTable(doc, {
      head: [["Action", "Performed By", "Performed At", "Details"]],
      body: filteredLogs.map(log => [
        log.action,
        log.performedBy?.username,
        new Date(log.performedAt).toLocaleString(),
        log.details,
      ])
    });
    doc.save("audit_logs.pdf");
  };

  return (
    <div className="px-8 py-6">
        <HeaderNavbar />
      <h2 className="text-2xl font-bold mb-4">Audit Log Management</h2>

      <div className="flex flex-wrap gap-4 items-center mb-6">
        <input
          type="date"
          className="border px-3 py-2 rounded"
          value={fromDate}
          onChange={e => setFromDate(e.target.value)}
        />
        <input
          type="date"
          className="border px-3 py-2 rounded"
          value={toDate}
          onChange={e => setToDate(e.target.value)}
        />
        <button
          className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
          onClick={handleFilter}
        >
          Filter
        </button>
        <button
          className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700"
          onClick={exportCSV}
        >
          Export CSV
        </button>
        <button
          className="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700"
          onClick={exportPDF}
        >
          Export PDF
        </button>
      </div>

      <div className="overflow-auto">
        <table className="min-w-full bg-white border border-gray-200">
          <thead className="bg-gray-100">
            <tr>
              <th className="text-left p-2 border">Action</th>
              <th className="text-left p-2 border">Performed By</th>
              <th className="text-left p-2 border">Performed At</th>
              <th className="text-left p-2 border">Details</th>
            </tr>
          </thead>
          <tbody>
            {filteredLogs.map((log, index) => (
              <tr key={index} className="border-t">
                <td className="p-2">{log.action}</td>
                <td className="p-2">{log.performedBy?.username}</td>
                <td className="p-2">{new Date(log.performedAt).toLocaleString()}</td>
                <td className="p-2">{log.details}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default AuditLogManagement;
