import React, { useState } from "react";
import HeaderNavbar from "../component/HeaderNavbar";
import { useNavigate } from "react-router-dom";
import { Mail, Lock, KeyRound } from "lucide-react";

const ForgotPassword = () => {
  const navigate = useNavigate(); 

  const [step, setStep] = useState(1);
  const [email, setEmail] = useState("");
  const [otp, setOtp] = useState("");
  const [generatedOtp, setGeneratedOtp] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSendOtp = async (e) => {
    e.preventDefault();
    setMessage("");
    if (!/\S+@\S+\.\S+/.test(email)) {
      setMessage("⚠️ Please enter a valid email address.");
      return;
    }

    try {
      setLoading(true);
      const response = await fetch("http://localhost:8080/api/auth/forgot-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Failed to send OTP.");
      setGeneratedOtp(data.otp);
      setMessage(`✅ OTP sent! (For debug: ${data.otp})`);
      setStep(2);
    } catch (error) {
      setMessage(`❌ ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyOtp = async (e) => {
    e.preventDefault();
    setMessage("");

    if (otp !== generatedOtp) {
      setMessage("❌ Invalid OTP.");
      return;
    }
    if (newPassword.length < 8) {
      setMessage("⚠️ Password must be at least 8 characters.");
      return;
    }

    try {
      setLoading(true);
      const response = await fetch("http://localhost:8080/api/auth/reset-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, otp, newPassword }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.message || "Password reset failed.");

      setMessage("✅ Password reset successfully! Redirecting to login...");
      setEmail("");
      setOtp("");
      setNewPassword("");
      setGeneratedOtp("");

      // ✅ Redirect after short delay
      setTimeout(() => {
        navigate("/login");
      }, 2000);
    } catch (error) {
      setMessage(`❌ ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <HeaderNavbar />
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-100 to-blue-200 px-4">
        <div className="bg-white shadow-xl rounded-2xl p-8 w-full max-w-md transition-all">
          <h2 className="text-2xl font-bold text-blue-700 mb-6 text-center">
            {step === 1 ? "Forgot Password 🔐" : "Reset Your Password 🔄"}
          </h2>

          {message && (
            <div className="mb-4 text-sm p-3 rounded-lg border bg-blue-50 border-blue-300 text-blue-800">
              {message}
            </div>
          )}

          {step === 1 ? (
            <form onSubmit={handleSendOtp} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">Email Address</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-2.5 text-blue-500" size={20} />
                  <input
                    type="email"
                    className="pl-10 pr-3 py-2 w-full border rounded-md focus:outline-none focus:ring focus:ring-blue-300"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                </div>
              </div>
              <button
                type="submit"
                disabled={loading}
                className={`w-full py-2 rounded-md text-white font-semibold transition ${
                  loading ? "bg-blue-400 cursor-not-allowed" : "bg-blue-600 hover:bg-blue-700"
                }`}
              >
                {loading ? "Sending OTP..." : "Send OTP"}
              </button>
            </form>
          ) : (
            <form onSubmit={handleVerifyOtp} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">Enter OTP</label>
                <div className="relative">
                  <KeyRound className="absolute left-3 top-2.5 text-blue-500" size={20} />
                  <input
                    type="text"
                    className="pl-10 pr-3 py-2 w-full border rounded-md focus:outline-none focus:ring focus:ring-blue-300"
                    required
                    value={otp}
                    onChange={(e) => setOtp(e.target.value)}
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">New Password</label>
                <div className="relative">
                  <Lock className="absolute left-3 top-2.5 text-blue-500" size={20} />
                  <input
                    type="password"
                    className="pl-10 pr-3 py-2 w-full border rounded-md focus:outline-none focus:ring focus:ring-blue-300"
                    required
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                  />
                </div>
              </div>
              <button
                type="submit"
                disabled={loading}
                className={`w-full py-2 rounded-md text-white font-semibold transition ${
                  loading ? "bg-green-400 cursor-not-allowed" : "bg-green-600 hover:bg-green-700"
                }`}
              >
                {loading ? "Resetting..." : "Reset Password"}
              </button>
            </form>
          )}
        </div>
      </div>
    </>
  );
};

export default ForgotPassword;
