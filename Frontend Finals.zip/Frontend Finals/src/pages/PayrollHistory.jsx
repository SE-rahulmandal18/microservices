import React, { useEffect, useState } from "react";
import axios from "axios";
import "jspdf-autotable";
import { format } from "date-fns";
import html2pdf from "html2pdf.js";
import JSZip from "jszip";
import { saveAs } from "file-saver";
import HeaderNavbar from "../component/HeaderNavbar";
import { FiDownload } from "react-icons/fi";

const PayrollHistory = () => {
  const [payrolls, setPayrolls] = useState([]);
  const [filterMonth, setFilterMonth] = useState("");
  const [filterName, setFilterName] = useState("");

  const token = localStorage.getItem("token");

  const fetchPayrolls = async () => {
    try {
      const res = await axios.get("http://localhost:8080/api/payrolls", {
        headers: { Authorization: `Bearer ${token}` },
      });
      const processedPayrolls = res.data.filter(
        (p) => p.paymentStatus === "PROCESSED"
      );
      setPayrolls(processedPayrolls);
    } catch (err) {
      console.error("Failed to fetch payrolls", err);
    }
  };

  useEffect(() => {
    fetchPayrolls();
  }, []);

  const filteredPayrolls = payrolls.filter((p) => {
    const matchesMonth = filterMonth
      ? p.processedAt?.toLowerCase().includes(filterMonth.toLowerCase())
      : true;
    const matchesName = filterName
      ? p.employeeName?.toLowerCase().includes(filterName.toLowerCase())
      : true;
    return matchesMonth && matchesName;
  });

  const generatePayslipBlob = async (payroll) => {
    return new Promise((resolve) => {
      const element = document.getElementById("payslip-template");
      if (!element) return;

      element.querySelector("#empId").textContent = `${payroll.employeeId}`;
      element.querySelector("#empName").textContent = payroll.employeeName;
      element.querySelector("#basicSalary").textContent = `$${payroll.basicSalary}`;
      element.querySelector("#allowances").textContent = `$${payroll.allowances}`;
      element.querySelector("#overtime").textContent = payroll.overtime;
      element.querySelector("#bonuses").textContent = `$${payroll.bonuses}`;
      element.querySelector("#deductions").textContent = `$${payroll.deductions}`;
      element.querySelector("#lopDays").textContent = payroll.lopDays;
      element.querySelector("#lopDeduction").textContent = `$${payroll.lopDeduction}`;
      element.querySelector("#netSalary").textContent = `$${payroll.netSalary}`;
      element.querySelector("#status").textContent = payroll.paymentStatus;
      element.querySelector("#processedAt").textContent = payroll.processedAt
        ? format(new Date(payroll.processedAt), "dd MMM yyyy, hh:mm a")
        : "-";

      element.style.position = "static";
      element.style.visibility = "visible";

      setTimeout(() => {
        html2pdf()
          .set({
            margin: 0.5,
            image: { type: "jpeg", quality: 0.98 },
            html2canvas: { scale: 2, useCORS: true },
            jsPDF: { unit: "in", format: "a4", orientation: "portrait" },
          })
          .from(element)
          .outputPdf("blob")
          .then((blob) => {
            const date = new Date(payroll.processedAt).toISOString().split("T")[0];
            const filename = `Payslip_${payroll.employeeName.replace(" ", "_")}_${payroll.id}_${date}.pdf`;
            resolve({ blob, filename });

            element.style.position = "absolute";
            element.style.left = "-9999px";
            element.style.visibility = "hidden";
          });
      }, 400);
    });
  };

  const handleBulkDownload = async () => {
    const zip = new JSZip();
    for (const payroll of filteredPayrolls) {
      const { blob, filename } = await generatePayslipBlob(payroll);
      zip.file(filename, blob);
    }
    zip.generateAsync({ type: "blob" }).then((content) => {
      saveAs(content, "Payslips_Bulk_Download.zip");
    });
  };

  return (
    <>
      <HeaderNavbar />
      <div className="max-w-6xl mx-auto p-6">
        <h2 className="text-2xl font-bold mb-4">Payroll History</h2>

        <div className="flex flex-col sm:flex-row gap-4 mb-4">
          <input
            type="text"
            placeholder="Filter by Month (e.g. 2024-12)"
            className="p-2 border rounded w-full sm:w-1/3"
            value={filterMonth}
            onChange={(e) => setFilterMonth(e.target.value)}
          />
          <input
            type="text"
            placeholder="Filter by Employee Name"
            className="p-2 border rounded w-full sm:w-1/3"
            value={filterName}
            onChange={(e) => setFilterName(e.target.value)}
          />
        </div>

        {filteredPayrolls.length > 0 && (
          <button
            onClick={handleBulkDownload}
            className="mb-4 px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700"
          >
            Download All Payslips (ZIP)
          </button>
        )}

        <div className="overflow-x-auto">
          <table className="min-w-full border">
            <thead className="bg-gray-100 text-sm text-left">
              <tr>
                <th className="p-2 border">#</th>
                <th className="p-2 border">Employee</th>
                <th className="p-2 border">Net Salary</th>
                <th className="p-2 border">Processed At</th>
                <th className="p-2 border">Status</th>
              </tr>
            </thead>
            <tbody>
              {filteredPayrolls.map((p, index) => (
                <tr key={p.id} className="text-sm text-gray-700">
                  <td className="p-2 border">
                    <div className="flex items-center space-x-2">
                      <span>{index + 1}</span>
                      <span
                        onClick={() =>
                          generatePayslipBlob(p).then(({ blob, filename }) =>
                            saveAs(blob, filename)
                          )
                        }
                        className="text-blue-600 cursor-pointer text-lg hover:text-blue-800"
                        title="Download Payslip"
                      >
                        <FiDownload />
                      </span>
                    </div>
                  </td>
                  <td className="p-2 border">{p.employeeName}</td>
                  <td className="p-2 border font-semibold">${p.netSalary}</td>
                  <td className="p-2 border">
                    {p.processedAt
                      ? format(new Date(p.processedAt), "yyyy-MM-dd HH:mm")
                      : "-"}
                  </td>
                  <td className="p-2 border">
                    <span className="px-2 py-1 rounded bg-green-100 text-green-700 text-xs">
                      {p.paymentStatus}
                    </span>
                  </td>
                </tr>
              ))}
              {filteredPayrolls.length === 0 && (
                <tr>
                  <td colSpan="6" className="text-center py-4 text-gray-500">
                    No payrolls found for this filter.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Hidden Payslip Template */}
        <div
          id="payslip-template"
          style={{
            position: "absolute",
            left: "-9999px",
            top: "0",
            fontFamily: "Arial, sans-serif",
            padding: "2rem",
            border: "1px solid #ccc",
            boxShadow: "0 0 10px rgba(0,0,0,0.1)",
            maxWidth: "600px",
            backgroundColor: "#fff",
            visibility: "hidden",
          }}
        >
          <h2 style={{ textAlign: "center", fontSize: "20px", fontWeight: "bold", borderBottom: "1px solid #ccc", paddingBottom: "10px", marginBottom: "20px" }}>
            Employee Payslip
          </h2>
          <table style={{ width: "100%", fontSize: "14px", borderCollapse: "collapse" }}>
            <tbody>
              <tr><td style={{ fontWeight: "bold", padding: "4px" }}>Employee ID:</td><td id="empId" style={{ padding: "4px" }}></td></tr>
              <tr><td style={{ fontWeight: "bold", padding: "4px" }}>Employee Name:</td><td id="empName" style={{ padding: "4px" }}></td></tr>
              <tr><td style={{ padding: "4px" }}>Basic Salary:</td><td id="basicSalary" style={{ padding: "4px" }}></td></tr>
              <tr><td style={{ padding: "4px" }}>Allowances:</td><td id="allowances" style={{ padding: "4px" }}></td></tr>
              <tr><td style={{ padding: "4px" }}>Overtime:</td><td id="overtime" style={{ padding: "4px" }}></td></tr>
              <tr><td style={{ padding: "4px" }}>Bonuses:</td><td id="bonuses" style={{ padding: "4px" }}></td></tr>
              <tr><td style={{ padding: "4px" }}>Deductions:</td><td id="deductions" style={{ padding: "4px" }}></td></tr>
              <tr><td style={{ padding: "4px" }}>LOP Days:</td><td id="lopDays" style={{ padding: "4px" }}></td></tr>
              <tr><td style={{ padding: "4px" }}>LOP Deduction:</td><td id="lopDeduction" style={{ padding: "4px" }}></td></tr>
              <tr><td style={{ fontWeight: "bold", padding: "4px", borderTop: "1px solid #ccc" }}>Net Salary:</td><td id="netSalary" style={{ padding: "4px", borderTop: "1px solid #ccc" }}></td></tr>
              <tr><td style={{ padding: "4px" }}>Status:</td><td id="status" style={{ padding: "4px" }}></td></tr>
              <tr><td style={{ padding: "4px" }}>Processed At:</td><td id="processedAt" style={{ padding: "4px" }}></td></tr>
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
};

export default PayrollHistory;
