// import React, { useEffect, useState } from "react";
// import axios from "axios";
// import HeaderNavbar from "../component/HeaderNavbar";
// import Footer from "../component/Footer";

// const AttendanceManagement = () => {
//   const [attendances, setAttendances] = useState([]);
//   const [modalOpen, setModalOpen] = useState(false);

//   const [form, setForm] = useState({
//     employeeId: "",
//     workDate: "",
//     checkInTime: "",
//     checkOutTime: "",
//   });

//   const token = localStorage.getItem("token");
//   const config = { headers: { Authorization: `Bearer ${token}` } };

//   useEffect(() => {
//     fetchAttendances();
//   }, []);

//   const fetchAttendances = async () => {
//     const res = await axios.get("http://localhost:8080/api/attendance", config);
//     setAttendances(res.data);
//   };

//   const handleChange = (e) => {
//     setForm({ ...form, [e.target.name]: e.target.value });
//   };

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     await axios.post("http://localhost:8080/api/attendance", form, config);
//     fetchAttendances();
//     closeModal();
//   };

//   const openModal = () => {
//     setForm({ employeeId: "", workDate: "", checkInTime: "", checkOutTime: "" });
//     setModalOpen(true);
//   };

//   const closeModal = () => {
//     setModalOpen(false);
//   };

//   return (
//     <>
//       <HeaderNavbar />
//       <div className="p-6">
//         <div className="flex justify-between items-center mb-6">
//           <h2 className="text-2xl font-bold">Attendance Management</h2>
//           <button
//             onClick={openModal}
//             className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
//           >
//             Add Attendance
//           </button>
//         </div>

//         <div className="overflow-x-auto">
//           <table className="w-full table-auto border text-left">
//             <thead className="bg-gray-200">
//               <tr>
//                 <th className="p-2 border">Employee ID</th>
//                 <th className="p-2 border">Date</th>
//                 <th className="p-2 border">Check In</th>
//                 <th className="p-2 border">Check Out</th>
//                 <th className="p-2 border">Total Hours</th>
//                 <th className="p-2 border">Overtime</th>
//               </tr>
//             </thead>
//             <tbody>
//               {attendances.map((a) => (
//                 <tr key={a.id} className="border-b">
//                   <td className="p-2 border">{a.employee.id}</td>
//                   <td className="p-2 border">{a.workDate}</td>
//                   <td className="p-2 border">{a.checkInTime}</td>
//                   <td className="p-2 border">{a.checkOutTime}</td>
//                   <td className="p-2 border">{a.totalHours}</td>
//                   <td className="p-2 border">{a.overtimeHours}</td>
//                 </tr>
//               ))}
//               {attendances.length === 0 && (
//                 <tr>
//                   <td colSpan="6" className="p-4 text-center text-gray-500">
//                     No attendance records found.
//                   </td>
//                 </tr>
//               )}
//             </tbody>
//           </table>
//         </div>

//         {modalOpen && (
//           <div className="fixed inset-0 z-50 backdrop-blur-sm bg-white/10 flex items-center justify-center">
//             <div className="bg-white p-6 rounded shadow-md w-[90%] max-w-lg">
//               <h3 className="text-xl font-semibold mb-4">Add Attendance</h3>
//               <form onSubmit={handleSubmit} className="space-y-4">
//                 <input
//                   type="number"
//                   name="employeeId"
//                   placeholder="Employee ID"
//                   value={form.employeeId}
//                   onChange={handleChange}
//                   required
//                   className="w-full border px-3 py-2 rounded"
//                 />
//                 <input
//                   type="date"
//                   name="workDate"
//                   value={form.workDate}
//                   onChange={handleChange}
//                   required
//                   className="w-full border px-3 py-2 rounded"
//                 />
//                 <input
//                   type="time"
//                   name="checkInTime"
//                   value={form.checkInTime}
//                   onChange={handleChange}
//                   required
//                   className="w-full border px-3 py-2 rounded"
//                 />
//                 <input
//                   type="time"
//                   name="checkOutTime"
//                   value={form.checkOutTime}
//                   onChange={handleChange}
//                   required
//                   className="w-full border px-3 py-2 rounded"
//                 />
//                 <div className="flex justify-end gap-4">
//                   <button
//                     type="button"
//                     onClick={closeModal}
//                     className="bg-gray-300 text-black px-4 py-2 rounded hover:bg-gray-400"
//                   >
//                     Cancel
//                   </button>
//                   <button
//                     type="submit"
//                     className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
//                   >
//                     Add
//                   </button>
//                 </div>
//               </form>
//             </div>
//           </div>
//         )}
//       </div>
//       <Footer />
//     </>
//   );
// };

// export default AttendanceManagement;

import React, { useEffect, useState } from "react";
import axios from "axios";
import HeaderNavbar from "../component/HeaderNavbar";
import Footer from "../component/Footer";

const AttendanceManagement = () => {
  const [attendances, setAttendances] = useState([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [filterId, setFilterId] = useState("");

  const [form, setForm] = useState({
    employeeId: "",
    workDate: "",
    checkInTime: "",
    checkOutTime: "",
  });

  const token = localStorage.getItem("token");
  const config = { headers: { Authorization: `Bearer ${token}` } };

  useEffect(() => {
    fetchAttendances();
  }, []);

  const fetchAttendances = async () => {
    const res = await axios.get("http://localhost:8080/api/attendance", config);
    setAttendances(res.data);
  };

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    await axios.post("http://localhost:8080/api/attendance", form, config);
    fetchAttendances();
    closeModal();
  };

  const openModal = () => {
    setForm({ employeeId: "", workDate: "", checkInTime: "", checkOutTime: "" });
    setModalOpen(true);
  };

  const closeModal = () => {
    setModalOpen(false);
  };

  return (
    <>
      <HeaderNavbar />
      <div className="p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">Attendance Management</h2>
          <div className="flex items-center gap-4">
            <input
              type="text"
              placeholder="Filter by Employee ID"
              value={filterId}
              onChange={(e) => setFilterId(e.target.value)}
              className="border px-3 py-2 rounded"
            />
            <button
              onClick={openModal}
              className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
            >
              Add Attendance
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full table-auto border text-left">
            <thead className="bg-gray-200">
              <tr>
                <th className="p-2 border">Employee ID</th>
                <th className="p-2 border">Date</th>
                <th className="p-2 border">Check In</th>
                <th className="p-2 border">Check Out</th>
                <th className="p-2 border">Total Hours</th>
                <th className="p-2 border">Overtime</th>
              </tr>
            </thead>
            <tbody>
              {attendances
                .filter((a) =>
                  filterId === "" || a.employee.id.toString().includes(filterId)
                )
                .map((a) => (
                  <tr key={a.id} className="border-b">
                    <td className="p-2 border">{a.employee.id}</td>
                    <td className="p-2 border">{a.workDate}</td>
                    <td className="p-2 border">{a.checkInTime}</td>
                    <td className="p-2 border">{a.checkOutTime}</td>
                    <td className="p-2 border">{a.totalHours}</td>
                    <td className="p-2 border">{a.overtimeHours}</td>
                  </tr>
                ))}
              {attendances.filter((a) =>
                filterId === "" || a.employee.id.toString().includes(filterId)
              ).length === 0 && (
                <tr>
                  <td colSpan="6" className="p-4 text-center text-gray-500">
                    No attendance records found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {modalOpen && (
          <div className="fixed inset-0 z-50 backdrop-blur-sm bg-white/10 flex items-center justify-center">
            <div className="bg-white p-6 rounded shadow-md w-[90%] max-w-lg">
              <h3 className="text-xl font-semibold mb-4">Add Attendance</h3>
              <form onSubmit={handleSubmit} className="space-y-4">
                <input
                  type="number"
                  name="employeeId"
                  placeholder="Employee ID"
                  value={form.employeeId}
                  onChange={handleChange}
                  required
                  className="w-full border px-3 py-2 rounded"
                />
                <input
                  type="date"
                  name="workDate"
                  value={form.workDate}
                  onChange={handleChange}
                  required
                  className="w-full border px-3 py-2 rounded"
                />
                <input
                  type="time"
                  name="checkInTime"
                  value={form.checkInTime}
                  onChange={handleChange}
                  required
                  className="w-full border px-3 py-2 rounded"
                />
                <input
                  type="time"
                  name="checkOutTime"
                  value={form.checkOutTime}
                  onChange={handleChange}
                  required
                  className="w-full border px-3 py-2 rounded"
                />
                <div className="flex justify-end gap-4">
                  <button
                    type="button"
                    onClick={closeModal}
                    className="bg-gray-300 text-black px-4 py-2 rounded hover:bg-gray-400"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
                  >
                    Add
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
      <Footer />
    </>
  );
};

export default AttendanceManagement;
