import React, { useState, useEffect } from "react";
import axios from "axios";
import Calendar from "react-calendar";
import "react-calendar/dist/Calendar.css";
import "../App.css";
import HeaderNavbar from "../component/HeaderNavbar";

const LeaveRecordsManagement = () => {
  const [leaveRecords, setLeaveRecords] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [leavesForSelectedDate, setLeavesForSelectedDate] = useState([]);
  const token = localStorage.getItem("token");

  useEffect(() => {
    const fetchLeaveRecords = async () => {
      try {
        const res = await axios.get("http://localhost:8080/api/leaves", {
          headers: { Authorization: `Bearer ${token}` },
        });
        setLeaveRecords(res.data);
      } catch (err) {
        console.error("Error fetching leave records", err);
        setError("Failed to fetch leave records.");
      } finally {
        setLoading(false);
      }
    };

    fetchLeaveRecords();
  }, [token]);

  const fetchEmployeeDetails = async (employeeId) => {
    try {
      const res = await axios.get(`http://localhost:8080/api/employees/${employeeId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      return res.data;
    } catch (err) {
      console.error("Error fetching employee details", err);
      return null;
    }
  };

  const calculateBusinessDays = (start, end) => {
    let count = 0;
    let current = new Date(start);
    const endDate = new Date(end);

    while (current <= endDate) {
      const day = current.getDay();
      if (day !== 0 && day !== 6) count++;
      current.setDate(current.getDate() + 1);
    }

    return count;
  };

  const filterLeavesForDate = async (date) => {
    const leavesOnDate = [];
    for (let leave of leaveRecords) {
      if (new Date(leave.startDate) <= date && new Date(leave.endDate) >= date) {
        const employeeDetails = await fetchEmployeeDetails(leave.employee.id);
        const days = calculateBusinessDays(leave.startDate, leave.endDate);
        leavesOnDate.push({ ...leave, employeeDetails, numberOfDays: days });
      }
    }
    setLeavesForSelectedDate(leavesOnDate);
  };

  const handleDateChange = (date) => {
    setSelectedDate(date);
    filterLeavesForDate(date);
  };

  const tileClassName = ({ date, view }) => {
    if (view === "month") {
      const hasLeave = leaveRecords.some(
        (leave) =>
          new Date(leave.startDate) <= date && new Date(leave.endDate) >= date
      );
      return hasLeave ? "highlight-leave" : "";
    }
  };

  if (loading) return <div>Loading...</div>;
  if (error) return <div>{error}</div>;

  return (
    <>
      <HeaderNavbar />
      <div className="bg-gradient-to-br from-blue-100 p-4">
        <h1 className="text-3xl font-bold mb-4 text-center">Leave Records</h1>

        {/* Calendar in center */}
        <div className="flex justify-center my-6">
          <Calendar
            onChange={handleDateChange}
            value={selectedDate}
            tileClassName={tileClassName}
          />
        </div>

        {/* Leave records for selected date */}
        <div className="mt-8">
          <h2 className="text-xl font-semibold mb-2">
            Leave Records for {selectedDate.toLocaleDateString()}
          </h2>
          {leavesForSelectedDate.length > 0 ? (
            <table className="min-w-full mt-4 border text-sm">
              <thead className="bg-gray-100 text-left">
                <tr>
                  <th className="border px-3 py-2">#</th>
                  <th className="border px-3 py-2">Employee ID</th>
                  <th className="border px-3 py-2">Name</th>
                  <th className="border px-3 py-2">Leave Type</th>
                  <th className="border px-3 py-2">Start Date</th>
                  <th className="border px-3 py-2">End Date</th>
                  <th className="border px-3 py-2">Days</th>
                </tr>
              </thead>
              <tbody>
                {leavesForSelectedDate.map((leave, index) => (
                  <tr key={leave.id} className="hover:bg-gray-50">
                    <td className="border px-3 py-2">{index + 1}</td>
                    <td className="border px-3 py-2">{leave.employeeDetails.id}</td>
                    <td className="border px-3 py-2">
                      {leave.employeeDetails.firstName} {leave.employeeDetails.lastName}
                    </td>
                    <td className="border px-3 py-2">{leave.leaveType}</td>
                    <td className="border px-3 py-2">
                      {new Date(leave.startDate).toLocaleDateString()}
                    </td>
                    <td className="border px-3 py-2">
                      {new Date(leave.endDate).toLocaleDateString()}
                    </td>
                    <td className="border px-3 py-2">{leave.numberOfDays}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <p className="text-gray-600">No leave records for this date.</p>
          )}
        </div>
      </div>
    </>
  );
};

export default LeaveRecordsManagement;
