import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import HeaderNavbar from "../component/HeaderNavbar";

const Dashboard = () => {
  const [username, setUsername] = useState("");
  const [role, setRole] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    const storedUsername = localStorage.getItem("username");
    const storedRole = localStorage.getItem("role");

    if (!storedUsername || !storedRole) {
      navigate("/login");
    } else {
      setUsername(storedUsername);
      setRole(storedRole);
    }
  }, [navigate]);

  return (
    <>
    <HeaderNavbar />
    <div className="min-h-screen bg-gradient-to-br from-blue-100 to-blue-200">
      <div className="max-w-4xl mx-auto mt-10 bg-white shadow-lg rounded-lg p-6">
        <h2 className="text-2xl font-bold text-gray-800 mb-2">Welcome, {username}!</h2>
        <p className="text-gray-600 mb-4">
          You are logged in as: <span className="font-semibold text-blue-600">{role}</span>
        </p>

        {role === "ADMIN" && (
          <p className="text-blue-700 bg-blue-100 px-4 py-2 rounded-md">
            🔧 You can manage users and the payroll system.
          </p>
        )}
        {role === "HR" && (
          <p className="text-green-700 bg-green-100 px-4 py-2 rounded-md">
            👥 You can manage employees and process payrolls.
          </p>
        )}
        {role === "EMPLOYEE" && (
          <p className="text-purple-700 bg-purple-100 px-4 py-2 rounded-md">
            💼 You can view your payslips and profile.
          </p>
        )}
      </div>
    </div>
  
    </>
  );
};

export default Dashboard;
