import React, { useEffect, useState } from "react";
import axios from "axios";
import Footer from "../component/Footer";
import HeaderNavbar from "../component/HeaderNavbar";

const LeaveForm = () => {
  const [form, setForm] = useState({
    employeeId: "",
    leaveType: "CASUAL",
    startDate: "",
    endDate: "",
    durationPerDay: "FULL", 
    isPaid: true,        
  });
  

  const [leaveTypeBalances, setLeaveTypeBalances] = useState({});
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [lopNotice, setLopNotice] = useState("");
  const [loading, setLoading] = useState(true);

  const leaveTypes = ["CASUAL", "SICK", "UNPAID", "ANNUAL"];

  const token = localStorage.getItem("token");

  const config = { headers: { Authorization: `Bearer ${token}` } };

  const fetchEmployeeId = async () => {
    try {
      const res = await axios.get("http://localhost:8080/api/employees/me", config);
      const id = res.data.id;
      setForm((prev) => ({ ...prev, employeeId: id }));
      fetchLeaveTypeBalances(id);
    } catch (err) {
      console.error("Error fetching employee ID", err);
      setError("Failed to fetch employee information.");
    } finally {
      setLoading(false);
    }
  };

  const fetchLeaveTypeBalances = async (id) => {
    const balances = {};
    for (const type of leaveTypes) {
      try {
        const res = await axios.get(`http://localhost:8080/api/leave-balances/employee/${id}/type/${type}`, config);
        balances[type] = res.data || 0;
      } catch (err) {
        console.error(`Error fetching balance for ${type}`, err);
        balances[type] = 0;
      }
    }
    setLeaveTypeBalances(balances);
  };

  useEffect(() => {
    fetchEmployeeId();
  }, []);

  useEffect(() => {
    console.log("Employee ID set in form: ", form.employeeId);
  }, [form.employeeId]);

  const calculateNumberOfDays = () => {
    const start = new Date(form.startDate);
    const end = new Date(form.endDate);
    let count = 0;

    for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
      const day = d.getDay(); // 0 = Sunday, 6 = Saturday
      if (day !== 0 && day !== 6) {
        count += 1;
      }
    } 

    return form.duration === "HALF_DAY" ? 0.5 : count;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setSuccess("");
    setLopNotice("");
  
    const requestedDays = calculateNumberOfDays();
    const balance = leaveTypeBalances[form.leaveType] || 0;
  
    if (requestedDays === 0) {
      setError("Invalid date selection.");
      return;
    }
  
    if (requestedDays > balance && form.leaveType !== "UNPAID") {
      const lop = requestedDays - balance;
      setLopNotice(`Note: ${lop} day(s) will be treated as LOP (Loss of Pay).`);
    }
  
    const isPaid = form.leaveType !== "UNPAID";
  
    const payload = {
      employeeId: form.employeeId,
      startDate: form.startDate,
      endDate: form.endDate,
      leaveType: form.leaveType,
      isPaid,
      durationPerDay: form.durationPerDay,
    };
  
    try {
      await axios.post("http://localhost:8080/api/leaves", payload, config);
      setSuccess("Leave applied successfully!");
      setForm((prev) => ({
        ...prev,
        startDate: "",
        endDate: "",
        durationPerDay: "FULL",
      }));
      fetchLeaveTypeBalances(form.employeeId);
    } catch (err) {
      console.error(err);
      setError("Failed to apply leave.");
    }
  };
  

  if (loading) return <p>Loading employee data...</p>;

  return (
    <>
    <HeaderNavbar />
    <form
      onSubmit={handleSubmit}
      className="bg-white p-6 rounded-2xl shadow-md max-w-xl mx-auto mt-6 space-y-4"
    >
      <h2 className="text-xl font-bold">Apply for Leave</h2>

      {error && <p className="text-red-600">{error}</p>}
      {success && <p className="text-green-600">{success}</p>}
      {lopNotice && <p className="text-orange-600">{lopNotice}</p>}

      <div>
        <label className="block font-medium">Leave Type</label>
        <select
          value={form.leaveType}
          onChange={(e) => setForm({ ...form, leaveType: e.target.value })}
          className="border p-2 rounded w-full"
        >
          {leaveTypes.map((type) => (
            <option key={type} value={type}>
              {type}
            </option>
          ))}
        </select>
        <p className="text-sm text-green-700 mt-1">
          Remaining Balance:{" "}
          <strong>{leaveTypeBalances[form.leaveType] ?? 0}</strong> days
        </p>
      </div>

      <div>
        <label className="block font-medium">Start Date</label>
        <input
          type="date"
          value={form.startDate}
          onChange={(e) => setForm({ ...form, startDate: e.target.value })}
          className="border p-2 rounded w-full"
          required
        />
      </div>

      <div>
        <label className="block font-medium">End Date</label>
        <input
          type="date"
          value={form.endDate}
          onChange={(e) => setForm({ ...form, endDate: e.target.value })}
          className="border p-2 rounded w-full"
          required
        />
      </div>

      <div>
        <label className="block font-medium">Duration</label>
        <select
  value={form.durationPerDay}
  onChange={(e) => setForm({ ...form, durationPerDay: e.target.value})}
  className="border p-2 rounded w-full"
>
  <option value="FULL">Full Day</option>
  <option value="HALF">Half Day</option>
</select>

      </div>
      <div className="text-sm text-gray-600">
        Total Requested Days: <strong>{calculateNumberOfDays()}</strong>
      </div>

      <button
        type="submit"
        className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
      >
        Submit Leave Request
      </button>
    </form>
  
    </>
  );
};

export default LeaveForm;

