import React, { useState, useEffect } from "react";
import axios from "axios";
import Footer from "../component/Footer";
import HeaderNavbar from "../component/HeaderNavbar";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const Profile = () => {
  const [profile, setProfile] = useState({
    employeeId: "",
    username: "",
    email: "",
    firstName: "",
    lastName: "",
    phone: "",
    department: "",
    designation: "",
    joinDate: "",
    bankAccount: "",
    employmentType: "",
    status: "",
    createdAt: "",
  });

  const [editMode, setEditMode] = useState(false);
  const [validationErrors, setValidationErrors] = useState({});
  const token = localStorage.getItem("token");

  useEffect(() => {
    fetchProfile();
  }, []);

  const fetchProfile = async () => {
    try {
      const res = await axios.get("http://localhost:8080/api/users/me", {
        headers: { Authorization: `Bearer ${token}` },
      });
      setProfile(res.data);
    } catch (err) {
      toast.error("Failed to load profile.", {
        position: "top-center",
        autoClose: 3000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        theme: "colored",
      });
    }
  };

  const handleChange = (e) => {
    setProfile({ ...profile, [e.target.name]: e.target.value });
    setValidationErrors({ ...validationErrors, [e.target.name]: "" });
  };

  const validateProfile = () => {
    const errors = {};
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const phoneRegex = /^[0-9]{10}$/;
    const nameRegex = /^[A-Za-z]+$/;
    const noQuotesRegex = /^[^'"]*$/;

    if (!profile.firstName.trim()) {
      errors.firstName = "First name is required.";
    } else if (!nameRegex.test(profile.firstName)) {
      errors.firstName = "First name must contain only letters.";
    } else if (!noQuotesRegex.test(profile.firstName)) {
      errors.firstName = "Quotes are not allowed in first name.";
    }

    if (!profile.lastName.trim()) {
      errors.lastName = "Last name is required.";
    } else if (!nameRegex.test(profile.lastName)) {
      errors.lastName = "Last name must contain only letters.";
    } else if (!noQuotesRegex.test(profile.lastName)) {
      errors.lastName = "Quotes are not allowed in last name.";
    }

    if (!profile.email.trim()) {
      errors.email = "Email is required.";
    } else if (!emailRegex.test(profile.email)) {
      errors.email = "Invalid email address.";
    } else if (!noQuotesRegex.test(profile.email)) {
      errors.email = "Quotes are not allowed in email.";
    }

    if (!profile.phone.trim()) {
      errors.phone = "Phone number is required.";
    } else if (!phoneRegex.test(profile.phone)) {
      errors.phone = "Phone number must be exactly 10 digits.";
    }

    const stringFields = ["department", "designation", "bankAccount", "status"];
    stringFields.forEach((field) => {
      if (!profile[field].trim()) {
        errors[field] = `${field} is required.`;
      } else if (!noQuotesRegex.test(profile[field])) {
        errors[field] = "Quotes are not allowed.";
      }
    });

    return errors;
  };

  const handleUpdate = async () => {
    const errors = validateProfile();
    if (Object.keys(errors).length > 0) {
      setValidationErrors(errors);
      toast.error("Please fix the validation errors!", {
        position: "top-center",
        autoClose: 3000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        theme: "colored",
      });
      return;
    }

    try {
      await axios.put("http://localhost:8080/api/users/me", profile, {
        headers: { Authorization: `Bearer ${token}` },
      });

      toast.success("Profile updated successfully!", {
        position: "top-center",
        autoClose: 3000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        theme: "colored",
      });

      setValidationErrors({});
      setEditMode(false);
    } catch (err) {
      toast.error("Failed to update profile!", {
        position: "top-center",
        autoClose: 3000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        theme: "colored",
      });
    }
  };

  return (
    <>
      <HeaderNavbar />
      <div className="max-w-5xl mx-auto px-6 py-8">
        <h2 className="text-3xl font-semibold text-gray-800 mb-6">
          Employee Profile
        </h2>

        <div className="bg-gradient-to-br from-blue-100 to-blue-200 shadow rounded-lg p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {Object.entries(profile).map(([key, value]) => (
              <div key={key}>
                <label className="block font-medium text-gray-700 capitalize text-sm">
                  {key.replace(/([A-Z])/g, " $1")}
                </label>
                <input
                  type={key.toLowerCase().includes("date") ? "date" : "text"}
                  name={key}
                  value={
                    key.includes("Date") ? value?.split("T")[0] : value || ""
                  }
                  onChange={handleChange}
                  className={`w-full border text-sm px-3 py-1.5 rounded-md mt-1 bg-white ${
                    validationErrors[key] ? "border-red-500" : ""
                  }`}
                  disabled={
                    !editMode ||
                    key === "employeeId" ||
                    key === "createdAt" ||
                    key === "employmentType" ||
                    key === "username" ||
                    key === "joinDate"
                  }
                />
                {validationErrors[key] && (
                  <p className="text-red-600 text-xs mt-1">
                    {validationErrors[key]}
                  </p>
                )}
              </div>
            ))}
          </div>

          <div className="flex justify-end gap-4 mt-6">
            {editMode ? (
              <>
                <button
                  onClick={handleUpdate}
                  className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700 text-sm"
                >
                  Save Changes
                </button>
                <button
                  onClick={() => {
                    setEditMode(false);
                    setValidationErrors({});
                  }}
                  className="bg-gray-400 text-white px-4 py-2 rounded hover:bg-gray-500 text-sm"
                >
                  Cancel
                </button>
              </>
            ) : (
              <button
                onClick={() => setEditMode(true)}
                className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 text-sm"
              >
                Edit Profile
              </button>
            )}
          </div>
        </div>
      </div>
      <Footer />
      <ToastContainer />
    </>
  );
};

export default Profile;
