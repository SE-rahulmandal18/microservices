import React, { useEffect, useState } from "react";
import axios from "axios";
import { confirmAlert } from "react-confirm-alert";
import "react-confirm-alert/src/react-confirm-alert.css";
import { toast } from "react-toastify";
import HeaderNavbar from "../component/HeaderNavbar";

const EmployeeManagement = () => {
  const [employees, setEmployees] = useState([]);
  const [allEmployees, setAllEmployees] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [currentEmployee, setCurrentEmployee] = useState({
    id: "",
    userId: "",
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    department: "",
    designation: "",
    joinDate: "",
    employmentType: "",
    bankAccount: "",
    status: "",
  });

  const fetchEmployees = async () => {
    try {
      const token = localStorage.getItem("token");
      const res = await axios.get("http://localhost:8080/api/employees", {
        headers: { Authorization: `Bearer ${token}` },
      });
      setEmployees(res.data || []);
      setAllEmployees(res.data || []);
    } catch (error) {
      console.error("Failed to fetch employees:", error);
      toast.error("Failed to load employee data.", {
        position: "top-center",
        autoClose: 3000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        theme: "colored",
      });
      setEmployees([]);
    }
  };

  useEffect(() => {
    fetchEmployees();
  }, []);

  const handleShowModal = (employee = null) => {
    if (employee) {
      setEditMode(true);
      setCurrentEmployee(employee);
    } else {
      setEditMode(false);
      setCurrentEmployee({
        userId: "",
        firstName: "",
        lastName: "",
        email: "",
        phone: "",
        department: "",
        designation: "",
        joinDate: "",
        employmentType: "",
        bankAccount: "",
        status: "",
      });
    }
    setShowModal(true);
  };

  const handleCloseModal = () => setShowModal(false);

  const sanitizeInput = (value) => value.replace(/['"]/g, "");

  const handleChange = (e) => {
    const { name, value } = e.target;
    setCurrentEmployee((prev) => ({
      ...prev,
      [name]: sanitizeInput(value),
    }));
  };

  const validateInputs = () => {
    const { firstName, lastName, email, phone } = currentEmployee;

    const nameRegex = /^[a-zA-Z]+$/;
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const phoneRegex = /^[0-9]{10}$/;

    if (!nameRegex.test(firstName)) {
      toast.error("First name should contain only letters.", { position: "top-center" });
      return false;
    }

    if (!nameRegex.test(lastName)) {
      toast.error("Last name should contain only letters.", { position: "top-center" });
      return false;
    }

    if (!emailRegex.test(email)) {
      toast.error("Invalid email address.", { position: "top-center" });
      return false;
    }

    if (!phoneRegex.test(phone)) {
      toast.error("Phone number must be exactly 10 digits.", { position: "top-center" });
      return false;
    }

    return true;
  };

  const handleSubmit = async () => {
    if (!validateInputs()) return;

    try {
      const token = localStorage.getItem("token");
      const url = editMode
        ? `http://localhost:8080/api/employees/${currentEmployee.id}`
        : "http://localhost:8080/api/employees";
      const method = editMode ? axios.patch : axios.post;

      await method(url, currentEmployee, {
        headers: { Authorization: `Bearer ${token}` },
      });

      toast.success(
        editMode ? "Employee updated successfully!" : "Employee added successfully!",
        {
          position: "top-center",
          autoClose: 3000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          theme: "colored",
        }
      );
      handleCloseModal();
      fetchEmployees();
    } catch (error) {
      console.error("Error saving employee:", error);
      toast.error("Failed to save employee.", {
        position: "top-center",
        autoClose: 3000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        theme: "colored",
      });
    }
  };

  const handleDelete = (id) => {
    confirmAlert({
      title: "Confirm Deletion",
      message: "Are you sure you want to delete this employee?",
      buttons: [
        {
          label: "Yes",
          onClick: async () => {
            try {
              const token = localStorage.getItem("token");
              await axios.delete(`http://localhost:8080/api/employees/${id}`, {
                headers: { Authorization: `Bearer ${token}` },
              });
              fetchEmployees();
              toast.success("Employee deleted successfully.", { position: "top-center" });
            } catch (error) {
              console.error("Failed to delete employee:", error);
              toast.error("Error deleting employee.", { position: "top-center" });
            }
          },
        },
        { label: "No" },
      ],
    });
  };

  return (
    <>
      <HeaderNavbar />
      <div className="p-6 max-w-7xl mx-auto ">
        <h2 className="text-2xl font-semibold mb-4">Employee Management</h2>

        <input
          type="text"
          placeholder="Search by name or email..."
          className="border px-3 py-1 rounded mb-4"
          onChange={(e) => {
            const value = e.target.value.toLowerCase();
            setEmployees(
              allEmployees.filter(
                (emp) =>
                  emp.firstName.toLowerCase().includes(value) ||
                  emp.email.toLowerCase().includes(value)
              )
            );
          }}
        />

        <button
          className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 mb-4"
          onClick={() => handleShowModal()}
        >
          ➕ Add Employee
        </button>

        <div className="overflow-auto">
          <table className="w-full border-collapse border border-gray-300">
            <thead className="bg-gray-100 text-sm text-left">
              <tr>
                <th className="p-2 border">#</th>
                <th className="p-2 border">First Name</th>
                <th className="p-2 border">Last Name</th>
                <th className="p-2 border">Email</th>
                <th className="p-2 border">Phone</th>
                <th className="p-2 border">Department</th>
                <th className="p-2 border">Designation</th>
                <th className="p-2 border">Join Date</th>
                <th className="p-2 border">Type</th>
                <th className="p-2 border">Bank</th>
                <th className="p-2 border">Status</th>
                <th className="p-2 border">Actions</th>
              </tr>
            </thead>
            <tbody>
              {employees.length > 0 ? (
                employees.map((emp) => (
                  <tr key={emp.id} className="bg-gradient-to-br from-blue-100 to-blue-200 text-sm">
                    <td className="p-2 border">{emp.id}</td>
                    <td className="p-2 border">{emp.firstName}</td>
                    <td className="p-2 border">{emp.lastName}</td>
                    <td className="p-2 border">{emp.email}</td>
                    <td className="p-2 border">{emp.phone}</td>
                    <td className="p-2 border">{emp.department}</td>
                    <td className="p-2 border">{emp.designation}</td>
                    <td className="p-2 border">{emp.joinDate}</td>
                    <td className="p-2 border">{emp.employmentType}</td>
                    <td className="p-2 border">{emp.bankAccount}</td>
                    <td className="p-2 border">{emp.status}</td>
                    <td className="p-2 border space-x-2">
                      <button
                        onClick={() => handleShowModal(emp)}
                        className="px-3 py-1 rounded hover:bg-yellow-200"
                      >
                        ✏️ Edit
                      </button>
                      <button
                        onClick={() => handleDelete(emp.id)}
                        className="px-3 py-1 rounded hover:bg-red-200"
                      >
                        🗑️ Delete
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="12" className="text-center p-4">
                    No employees available.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 backdrop-blur-sm bg-white/10 flex items-center justify-center">
          <div className="bg-white p-6 rounded-lg shadow-md w-full max-w-2xl">
            <h3 className="text-xl font-semibold mb-4">
              {editMode ? "Edit Employee" : "Add Employee"}
            </h3>

            <div className="grid grid-cols-2 gap-4">
              {[
                { name: "userId", label: "User ID", type: "number", required: true, readOnly: editMode },
                {
                  name: "firstName",
                  label: "First Name",
                  required: true,
                  pattern: "^[a-zA-Z]+$",
                  title: "Only letters allowed",
                },
                {
                  name: "lastName",
                  label: "Last Name",
                  required: true,
                  pattern: "^[a-zA-Z]+$",
                  title: "Only letters allowed",
                },
                {
                  name: "email",
                  label: "Email",
                  type: "email",
                  required: true,
                  pattern: "^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$",
                  title: "Enter a valid email address",
                },
                {
                  name: "phone",
                  label: "Phone",
                  type: "tel",
                  required: true,
                  pattern: "^[0-9]{10}$",
                  title: "Enter a valid 10-digit phone number",
                },
                { name: "department", label: "Department", required: true },
                { name: "designation", label: "Designation", required: true },
                { name: "joinDate", label: "Join Date", type: "date", required: true },
                { name: "bankAccount", label: "Bank Account", type: "number", required: true },
              ].map(({ name, label, type = "text", required, pattern, title }) => (
                <div key={name}>
                  <label className="block text-sm font-medium mb-1">{label}</label>
                  <input
                    type={type}
                    name={name}
                    value={currentEmployee[name] || ""}
                    onChange={handleChange}
                    className="w-full border rounded px-2 py-1"
                    required={required}
                    pattern={pattern}
                    title={title}
                    readOnly={name === "userId" && editMode}
                  />
                </div>
              ))}

              <div>
                <label className="block text-sm font-medium mb-1">Employment Type</label>
                <select
                  name="employmentType"
                  value={currentEmployee.employmentType}
                  onChange={handleChange}
                  className="w-full border rounded px-2 py-1"
                  required
                >
                  <option value="">-- Select --</option>
                  <option value="FULL_TIME">Full-Time</option>
                  <option value="PART_TIME">Part-Time</option>
                  <option value="CONTRACT">Contract</option>
                  <option value="INTERN">Intern</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium mb-1">Status</label>
                <select
                  name="status"
                  value={currentEmployee.status}
                  onChange={handleChange}
                  className="w-full border rounded px-2 py-1"
                  required
                >
                  <option value="">-- Select --</option>
                  <option value="ACTIVE">Active</option>
                  <option value="INACTIVE">Inactive</option>
                  <option value="TERMINATED">Terminated</option>
                </select>
              </div>
            </div>

            <div className="flex justify-end mt-6 gap-3">
              <button
                onClick={handleSubmit}
                className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700"
              >
                {editMode ? "Update" : "Save"}
              </button>
              <button
                onClick={handleCloseModal}
                className="bg-gray-400 text-white px-4 py-2 rounded hover:bg-gray-500"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default EmployeeManagement;
