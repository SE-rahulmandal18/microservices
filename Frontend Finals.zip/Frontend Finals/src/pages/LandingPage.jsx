import React from 'react';
import Card from '../component/Card';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import Footer from '../component/Footer';
import HeaderNavbar from '../component/HeaderNavbar';

const LandingPage = () => {
    const navigate = useNavigate();

    return (
        <div className="flex flex-col min-h-screen">
            {/* Header - Full width */}
            <div className="w-full">
                <HeaderNavbar />
            </div>

            <div className="flex flex-col items-center justify-between gap-8 pt-16 lg:flex-row lg:py-5 lg:gap-10 flex-1 lg:px-14 sm:px-8 px-4">
                <div className="flex-1">
                    <motion.h1
                        initial={{ opacity: 0, y: -80 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        viewport={{ once: true }}
                        transition={{ duration: 0.8 }}
                        className="font-bold font-roboto text-slate-800 md:text-5xl sm:text-4xl text-3xl md:leading-[55px] sm:leading-[45px] leading-10 lg:w-full md:w-[70%] w-full"
                    >
                        Payroll Software  
                        Fully-Automated Payroll & Compliance Software
                    </motion.h1>

                    <p className="max-w-screen-lg mt-4 text-center text-gray-400">
                        Automate your payroll with precision– disburse salaries, file & pay taxes, like TDS, PF, PT & ESIC from a single dashboard on your payroll software.
                    </p>

                    {/* Buttons */}
                    <div className="flex items-center gap-3">
                        <motion.button
                            initial={{ opacity: 0, y: 80 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true }}
                            transition={{ duration: 0.8 }}
                            onClick={() => navigate("/login")}
                            className="w-40 py-2 text-white rounded-md bg-gradient-to-r from-blue-500 to-green-500"
                        >
                            Start Now
                        </motion.button>

                        <motion.button
                            initial={{ opacity: 0, y: 80 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true }}
                            transition={{ duration: 0.8 }}
                            onClick={() => navigate("/about")}
                            className="w-40 py-2 text-white rounded-md bg-gradient-to-r from-blue-500 to-green-500"
                        >
                            About Us
                        </motion.button>
                    </div>
                </div>

                {/* Image */}
                <div className="flex justify-center flex-1 w-full">
                    <motion.img
                        initial={{ opacity: 0 }}
                        whileInView={{ opacity: 1 }}
                        viewport={{ once: true }}
                        transition={{ duration: 0.8 }}
                        className="sm:w-[480px] w-[400px] object-cover rounded-md"
                        src="https://razorpay.com/build/browser/static/hero.adf3ca09.svg"
                        alt="Payroll Software"
                    />
                </div>
            </div>

            {/* Trusted by Companies */}
            <div className="sm:pt-12 pt-7">
                <motion.p
                    initial={{ opacity: 0, y: 50 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.8 }}
                    className="text-slate-800 font-roboto font-bold lg:w-[60%] md:w-[70%] sm:w-[80%] mx-auto text-3xl text-center"
                >
                    Trusted by individuals and teams at the world’s best companies
                </motion.p>

                {/* Feature Cards */}
                <div className="grid grid-cols-1 gap-4 pt-4 mt-4 pb-7 lg:gap-7 xl:grid-cols-4 lg:grid-cols-3 sm:grid-cols-2">
                    <Card title="Seamless Payroll Processing" desc="Automate salary calculations, tax deductions, and payouts with ease. Ensure accurate and timely payroll processing every month." />
                    <Card title="Employee Management" desc="Keep track of employee records, attendance, and salary structures in one unified platform, making HR management effortless." />
                    <Card title="Tax Compliance & Reports" desc="Stay compliant with automated tax calculations and generate reports for audits, filings, and financial insights without hassle." />
                    <Card title="Secure & Reliable" desc="Protect sensitive payroll data with industry-grade encryption and secure access controls, ensuring confidentiality and reliability." />
                </div>
            </div>

            {/* Footer - Full width */}
            <div className="w-full">
                <Footer />
            </div>
        </div>
    );
};

export default LandingPage;
