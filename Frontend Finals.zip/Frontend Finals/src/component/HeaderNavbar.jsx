import React, { useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { IoIosMenu } from "react-icons/io";
import { RxCross2 } from "react-icons/rx";

const HeaderNavbar = () => {
  const role = localStorage.getItem("role");
  const username = localStorage.getItem("username");
  const navigate = useNavigate();
  const path = useLocation().pathname;
  const [menuOpen, setMenuOpen] = useState(false);

  const handleLogout = () => {
    localStorage.clear();
    navigate("/login");
  };

  const toggleMenu = () => setMenuOpen(!menuOpen);

  const renderLinks = () => {
    if (!role) {
      return (
        <>
          <li><Link to="/login" onClick={toggleMenu} className="hover:text-gray-300">Login</Link></li>
          <li><Link to="/about" onClick={toggleMenu} className="hover:text-gray-300">About</Link></li>
          <li><Link to="/register" onClick={toggleMenu} className="hover:text-gray-300">Sign Up</Link></li>
        </>
      );
    }

    switch (role) {
      case "ADMIN":
        return (
          <>
            <li><Link to="/employee-management" onClick={toggleMenu}>Employees</Link></li>
            <li><Link to="/transaction-status" onClick={toggleMenu}>Transactions</Link></li>
            <li><Link to="/reports" onClick={toggleMenu}>Reports</Link></li>
            <li><Link to="/audit-logs" onClick={toggleMenu}>Logs</Link></li>
          </>
        );
      case "HR":
        return (
          <>
            <li><Link to="/employee-management" onClick={toggleMenu}>Employees</Link></li>
            <li><Link to="/payroll" onClick={toggleMenu}>Payroll</Link></li>
            <li><Link to="/payslips" onClick={toggleMenu}>Payslips</Link></li>
            <li><Link to="/reports" onClick={toggleMenu}>Reports</Link></li>
            <li><Link to="/leave-records" onClick={toggleMenu}>Leave Records</Link></li>
          </>
        );
      case "EMPLOYEE":
        return (
          <>
            <li><Link to="/payslips" onClick={toggleMenu}>My Payslips</Link></li>
            <li><Link to="/attendance-management" onClick={toggleMenu}>My Attendance</Link></li>
            <li><Link to="/leave-management" onClick={toggleMenu}>My Leaves</Link></li>
            <li><Link to="/profile" onClick={toggleMenu}>My Profile</Link></li>
          </>
        );
      default:
        return null;
    }
  };

  return (
    <header className="fixed top-0 left-0 w-full bg-indigo-600 text-white z-50 shadow">
      <div className="flex justify-between items-center px-4 py-3">
        <Link to="/" className="text-xl font-bold italic">
          Payroll Management System
        </Link>
        <button onClick={toggleMenu} className="text-3xl focus:outline-none">
          {menuOpen ? <RxCross2 /> : <IoIosMenu />}
        </button>
      </div>

      {/* Dropdown aligned to top right corner */}
      {menuOpen && (
        <div className="absolute right-4 top-16 w-72 bg-indigo-700 rounded-md shadow-lg px-6 py-4">
          <ul className="flex flex-col space-y-3 text-white font-medium">
            {renderLinks()}
          </ul>

          {role && (
            <div className="mt-4 border-t border-indigo-500 pt-3 flex flex-col space-y-2">
              <span className="text-sm">
                Logged in as: <strong>{username}</strong> ({role})
              </span>
              <button
                onClick={() => {
                  handleLogout();
                  toggleMenu();
                }}
                className="bg-red-500 hover:bg-red-600 text-white px-4 py-1 rounded"
              >
                Logout
              </button>
            </div>
          )}
        </div>
      )}
    </header>
  );
};

export default HeaderNavbar;
