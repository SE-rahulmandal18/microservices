package com.example.reviewms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReviewmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
