package com.payroll_app.demo.controller;

import com.payroll_app.demo.dto.*;
import com.payroll_app.demo.model.User;
import com.payroll_app.demo.security.JwtUtil;
import com.payroll_app.demo.service.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.Map;
import java.util.Optional;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

class AuthControllerTest {

    @InjectMocks
    private AuthController authController;

    @Mock
    private AuthenticationManager authManager;

    @Mock
    private JwtUtil jwtUtil;

    @Mock
    private UserDetailsService userDetailsService;

    @Mock
    private UserService userService;

    private MockMvc mockMvc;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(authController).build();
    }

    @Test
    void testLogin_Success() throws Exception {
        LoginRequest loginRequest = new LoginRequest();
        loginRequest.setUsername("testuser");
        loginRequest.setPassword("password");

        Authentication authentication = mock(Authentication.class);
        UserDetails userDetails = mock(UserDetails.class);
        User user = new User();
        user.setUsername("testuser");
        user.setRole(User.Role.ADMIN);

        when(authManager.authenticate(any(UsernamePasswordAuthenticationToken.class))).thenReturn(authentication);
        when(userDetailsService.loadUserByUsername("testuser")).thenReturn(userDetails);
        when(userService.getUserByUsername("testuser")).thenReturn(Optional.of(user));
        when(jwtUtil.generateToken(eq("testuser"), eq("ADMIN"))).thenReturn("mocked-jwt-token");
        when(userDetails.getUsername()).thenReturn("testuser");

        mockMvc.perform(post("/api/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"testuser\",\"password\":\"password\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.token").value("mocked-jwt-token"))
                .andExpect(jsonPath("$.username").value("testuser"))
                .andExpect(jsonPath("$.role").value("ADMIN"));

        verify(authManager).authenticate(any(UsernamePasswordAuthenticationToken.class));
        verify(userService).getUserByUsername("testuser");
        verify(jwtUtil).generateToken("testuser", "ADMIN");
    }

    @Test
    void testRegister_Success() throws Exception {
        RegisterRequest registerRequest = new RegisterRequest();
        registerRequest.setUsername("newuser");
        registerRequest.setEmail("newuser@example.com");
        registerRequest.setPassword("pass123");
        registerRequest.setRole("USER");

        when(userService.getUserByUsername("newuser")).thenReturn(Optional.empty());

        mockMvc.perform(post("/api/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"newuser\",\"email\":\"newuser@example.com\",\"password\":\"pass123\",\"role\":\"USER\"}"))
                .andExpect(status().isOk())
                .andExpect(content().string("User registered successfully!"));

        verify(userService).createUser(any(User.class));
    }

    @Test
    void testRegister_UsernameExists() throws Exception {
        when(userService.getUserByUsername("existinguser")).thenReturn(Optional.of(new User()));

        mockMvc.perform(post("/api/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"existinguser\",\"email\":\"exists@example.com\",\"password\":\"pass\",\"role\":\"USER\"}"))
                .andExpect(status().isBadRequest())
                .andExpect(content().string("Username already exists!"));

        verify(userService, never()).createUser(any(User.class));
    }

    @Test
    void testSendOtp_Success() throws Exception {
        when(userService.sendOtp("email@example.com")).thenReturn("123456");

        mockMvc.perform(post("/api/auth/forgot-password")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"email\":\"email@example.com\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("OTP generated successfully (shown on screen for simulation)."))
                .andExpect(jsonPath("$.otp").value("123456"));

        verify(userService).sendOtp("email@example.com");
    }

    @Test
    void testVerifyOtp_Success() throws Exception {
        doNothing().when(userService).verifyOtpAndReset("email@example.com", "123456", "newpass");

        mockMvc.perform(post("/api/auth/verify-otp")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"email\":\"email@example.com\", \"otp\":\"123456\", \"newPassword\":\"newpass\"}"))
                .andExpect(status().isOk())
                .andExpect(content().string("Password reset successful."));

        verify(userService).verifyOtpAndReset("email@example.com", "123456", "newpass");
    }

    @Test
    void testResetPassword_Success() throws Exception {
        User user = new User();
        user.setEmail("email@example.com");

        when(userService.getUserByEmail("email@example.com")).thenReturn(Optional.of(user));
        when(userService.validateSimulatedOtp("email@example.com", "123456")).thenReturn(true);

        mockMvc.perform(post("/api/auth/reset-password")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"email\":\"email@example.com\", \"otp\":\"123456\", \"newPassword\":\"newpass\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("Password has been reset successfully!"));

        verify(userService).resetPassword(user, "newpass");
    }

    @Test
    void testResetPassword_InvalidOtp() throws Exception {
        User user = new User();
        user.setEmail("email@example.com");

        when(userService.getUserByEmail("email@example.com")).thenReturn(Optional.of(user));
        when(userService.validateSimulatedOtp("email@example.com", "wrongOtp")).thenReturn(false);

        mockMvc.perform(post("/api/auth/reset-password")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"email\":\"email@example.com\", \"otp\":\"wrongOtp\", \"newPassword\":\"newpass\"}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value("Invalid OTP."));

        verify(userService, never()).resetPassword(any(User.class), anyString());
    }
}
