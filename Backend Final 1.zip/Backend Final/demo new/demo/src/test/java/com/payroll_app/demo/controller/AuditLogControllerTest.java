package com.payroll_app.demo.controller;

import com.payroll_app.demo.dto.AuditLogRequest;
import com.payroll_app.demo.model.AuditLog;
import com.payroll_app.demo.service.AuditLogService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.Arrays;
import java.util.List;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

class AuditLogControllerTest {

    @InjectMocks
    private AuditLogController auditLogController;

    @Mock
    private AuditLogService auditLogService;

    private MockMvc mockMvc;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(auditLogController).build();
    }

    @Test
    void testCreateLog() throws Exception {
        AuditLogRequest request = new AuditLogRequest();
        AuditLog auditLog = new AuditLog();
        auditLog.setId(1L);
        auditLog.setAction("CREATE");

        when(auditLogService.createLog(any(AuditLogRequest.class))).thenReturn(auditLog);

        mockMvc.perform(post("/api/audit-logs")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"action\":\"CREATE\", \"description\":\"Test log\"}")) // replace with actual request fields
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.action").value("CREATE"));

        verify(auditLogService, times(1)).createLog(any(AuditLogRequest.class));
    }

    @Test
    void testGetAllLogs() throws Exception {
        AuditLog log1 = new AuditLog();
        log1.setId(1L);
        AuditLog log2 = new AuditLog();
        log2.setId(2L);
        List<AuditLog> logs = Arrays.asList(log1, log2);

        when(auditLogService.getAllLogs()).thenReturn(logs);

        mockMvc.perform(get("/api/audit-logs"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.size()").value(2));

        verify(auditLogService, times(1)).getAllLogs();
    }

    @Test
    void testGetLogById() throws Exception {
        AuditLog log = new AuditLog();
        log.setId(1L);
        log.setAction("VIEW");

        when(auditLogService.getLogById(1L)).thenReturn(log);

        mockMvc.perform(get("/api/audit-logs/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.action").value("VIEW"));

        verify(auditLogService, times(1)).getLogById(1L);
    }

    @Test
    void testDeleteLog() throws Exception {
        doNothing().when(auditLogService).deleteLog(1L);

        mockMvc.perform(delete("/api/audit-logs/1"))
                .andExpect(status().isOk());

        verify(auditLogService, times(1)).deleteLog(1L);
    }
}
