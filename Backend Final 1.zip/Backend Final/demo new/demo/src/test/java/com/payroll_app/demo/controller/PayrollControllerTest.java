package com.payroll_app.demo.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.payroll_app.demo.dto.PayrollRequest;
import com.payroll_app.demo.dto.PayrollResponse;
import com.payroll_app.demo.model.Payroll;
import com.payroll_app.demo.model.User;
import com.payroll_app.demo.service.PayrollService;
import com.payroll_app.demo.service.UserService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.core.Authentication;
import org.springframework.test.web.servlet.MockMvc;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(PayrollController.class)
class PayrollControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private PayrollService payrollService;

    @MockBean
    private UserService userService;

    @MockBean
    private Authentication authentication;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void testGetAllPayrolls_AdminRole() throws Exception {
        User adminUser = new User();
        adminUser.setRole(User.Role.ADMIN);
        when(userService.getUserByUsername("admin")).thenReturn(Optional.of(adminUser));
        when(authentication.getName()).thenReturn("admin");

        List<PayrollResponse> payrolls = List.of(
                PayrollResponse.builder()
                        .id(1L)
                        .employeeId(101L)
                        .employeeName("John Doe")
                        .basicSalary(BigDecimal.valueOf(5000))
                        .allowances(BigDecimal.valueOf(1000))
                        .netSalary(BigDecimal.valueOf(6000))
                        .processedAt(LocalDateTime.now())
                        .paymentStatus(Payroll.PaymentStatus.PROCESSED)
                        .build()
        );

        when(payrollService.getAllPayrolls()).thenReturn(payrolls);

        mockMvc.perform(get("/api/payrolls")
                        .principal(authentication))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].employeeId").value(101))
                .andExpect(jsonPath("$[0].netSalary").value(6000));
    }

    @Test
    void testCreatePayroll() throws Exception {
        PayrollRequest request = new PayrollRequest();
        request.setEmployeeId(101L);
        request.setBasicSalary(BigDecimal.valueOf(5000));
        request.setAllowances(BigDecimal.valueOf(1000));

        PayrollResponse response = PayrollResponse.builder()
                .id(1L)
                .employeeId(101L)
                .employeeName("John Doe")
                .basicSalary(BigDecimal.valueOf(5000))
                .allowances(BigDecimal.valueOf(1000))
                .netSalary(BigDecimal.valueOf(6000))
                .processedAt(LocalDateTime.now())
                .paymentStatus(Payroll.PaymentStatus.FAILED)
                .build();

        when(payrollService.createPayroll(any(PayrollRequest.class))).thenReturn(response);

        mockMvc.perform(post("/api/payrolls")
                        .contentType("application/json")
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.employeeId").value(101))
                .andExpect(jsonPath("$.netSalary").value(6000));
    }

    @Test
    void testUpdatePayroll() throws Exception {
        PayrollRequest request = new PayrollRequest();
        request.setBasicSalary(BigDecimal.valueOf(5500));

        PayrollResponse response = PayrollResponse.builder()
                .id(1L)
                .employeeId(101L)
                .employeeName("John Doe")
                .basicSalary(BigDecimal.valueOf(5500))
                .allowances(BigDecimal.valueOf(1000))
                .netSalary(BigDecimal.valueOf(6500))
                .processedAt(LocalDateTime.now())
                .paymentStatus(Payroll.PaymentStatus.PENDING)
                .build();

        when(payrollService.updatePayroll(1L, request)).thenReturn(response);

        mockMvc.perform(patch("/api/payrolls/{id}", 1L)
                        .contentType("application/json")
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.basicSalary").value(5500))
                .andExpect(jsonPath("$.netSalary").value(6500));
    }

    @Test
    void testDeletePayroll() throws Exception {
        mockMvc.perform(delete("/api/payrolls/{id}", 1L))
                .andExpect(status().isNoContent());
    }
}
