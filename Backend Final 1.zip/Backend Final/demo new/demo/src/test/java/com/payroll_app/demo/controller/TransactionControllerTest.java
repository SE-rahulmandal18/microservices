//package com.payroll_app.demo.controller;
//
//import com.payroll_app.demo.dto.CreateTransactionRequest;
//import com.payroll_app.demo.dto.UpdateTransactionStatusRequest;
//import com.payroll_app.demo.model.Transaction;
//import com.payroll_app.demo.service.TransactionService;
//import org.junit.jupiter.api.Test;
//import org.mockito.Mock;
//import org.mockito.Mockito;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
//import org.springframework.boot.test.mock.mockito.MockBean;
//import org.springframework.test.web.servlet.MockMvc;
//
//import java.util.List;
//
//import static org.mockito.Mockito.when;
//import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
//import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
//
//@WebMvcTest(TransactionController.class)
//class TransactionControllerTest {
//
//    @Autowired
//    private MockMvc mockMvc;
//
//    @MockBean
//    private TransactionService transactionService;
//
//    @Test
//    void testGetAllTransactions() throws Exception {
//        when(transactionService.getAllTransactions()).thenReturn(
//                List.of(new Transaction(1L, "Transaction 1"), new Transaction(2L, "Transaction 2"))
//        );
//
//        mockMvc.perform(get("/api/transactions"))
//                .andExpect(status().isOk())
//                .andExpect(jsonPath("$[0].id").value(1L))
//                .andExpect(jsonPath("$[0].name").value("Transaction 1"));
//    }
//
//    @Test
//    void testGetTransactionById() throws Exception {
//        Transaction transaction = new Transaction(1L, "Transaction 1");
//        when(transactionService.getTransactionById(1L)).thenReturn(transaction);
//
//        mockMvc.perform(get("/api/transactions/{id}", 1L))
//                .andExpect(status().isOk())
//                .andExpect(jsonPath("$.id").value(1L))
//                .andExpect(jsonPath("$.name").value("Transaction 1"));
//    }
//
//    @Test
//    void testCreateTransaction() throws Exception {
//        CreateTransactionRequest request = new CreateTransactionRequest("New Transaction");
//        Transaction transaction = new Transaction(1L, "New Transaction");
//
//        when(transactionService.createTransaction(request)).thenReturn(transaction);
//
//        mockMvc.perform(post("/api/transactions")
//                        .contentType("application/json")
//                        .content("{\"name\":\"New Transaction\"}"))
//                .andExpect(status().isOk())
//                .andExpect(jsonPath("$.id").value(1L))
//                .andExpect(jsonPath("$.name").value("New Transaction"));
//    }
//
//    @Test
//    void testUpdateTransactionStatus() throws Exception {
//        UpdateTransactionStatusRequest request = new UpdateTransactionStatusRequest("Completed");
//        Transaction transaction = new Transaction(1L, "Transaction 1", "Completed");
//
//        when(transactionService.updateStatus(1L, request)).thenReturn(transaction);
//
//        mockMvc.perform(put("/api/transactions/{id}/status", 1L)
//                        .contentType("application/json")
//                        .content("{\"status\":\"Completed\"}"))
//                .andExpect(status().isOk())
//                .andExpect(jsonPath("$.status").value("Completed"));
//    }
//
//    @Test
//    void testDeleteTransaction() throws Exception {
//        mockMvc.perform(delete("/api/transactions/{id}", 1L))
//                .andExpect(status().isNoContent());
//    }
//
//    @Test
//    void testRetryTransaction() throws Exception {
//        Transaction transaction = new Transaction(1L, "Retry Transaction");
//
//        when(transactionService.retryTransaction(1L)).thenReturn(transaction);
//
//        mockMvc.perform(post("/api/transactions/{id}/retry", 1L))
//                .andExpect(status().isOk())
//                .andExpect(jsonPath("$.id").value(1L))
//                .andExpect(jsonPath("$.name").value("Retry Transaction"));
//    }
//}
