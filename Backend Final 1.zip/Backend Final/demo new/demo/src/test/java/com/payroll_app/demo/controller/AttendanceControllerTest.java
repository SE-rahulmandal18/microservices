package com.payroll_app.demo.controller;

import com.payroll_app.demo.dto.CreateAttendanceRequest;
import com.payroll_app.demo.dto.UpdateAttendanceRequest;
import com.payroll_app.demo.model.Attendance;
import com.payroll_app.demo.service.AttendanceService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.Arrays;
import java.util.List;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

class AttendanceControllerTest {

    @InjectMocks
    private AttendanceController attendanceController;

    @Mock
    private AttendanceService attendanceService;

    private MockMvc mockMvc;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(attendanceController).build();
    }

    @Test
    void testCreateAttendance() throws Exception {
        CreateAttendanceRequest request = new CreateAttendanceRequest();
        Attendance attendance = new Attendance();
        attendance.setId(1L);

        when(attendanceService.createAttendance(any(CreateAttendanceRequest.class))).thenReturn(attendance);

        mockMvc.perform(post("/api/attendance")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"someField\":\"someValue\"}"))  // Replace with actual fields
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1));

        verify(attendanceService, times(1)).createAttendance(any(CreateAttendanceRequest.class));
    }

    @Test
    void testGetAllAttendances() throws Exception {
        Attendance att1 = new Attendance();
        att1.setId(1L);
        Attendance att2 = new Attendance();
        att2.setId(2L);
        List<Attendance> list = Arrays.asList(att1, att2);

        when(attendanceService.getAllAttendances()).thenReturn(list);

        mockMvc.perform(get("/api/attendance"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.size()").value(2));

        verify(attendanceService, times(1)).getAllAttendances();
    }

    @Test
    void testGetAttendanceById() throws Exception {
        Attendance attendance = new Attendance();
        attendance.setId(1L);

        when(attendanceService.getAttendanceById(1L)).thenReturn(attendance);

        mockMvc.perform(get("/api/attendance/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1));

        verify(attendanceService, times(1)).getAttendanceById(1L);
    }

    @Test
    void testUpdateAttendance() throws Exception {
        UpdateAttendanceRequest request = new UpdateAttendanceRequest();
        Attendance updatedAttendance = new Attendance();
        updatedAttendance.setId(1L);

        when(attendanceService.updateAttendance(eq(1L), any(UpdateAttendanceRequest.class))).thenReturn(updatedAttendance);

        mockMvc.perform(put("/api/attendance/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"someField\":\"newValue\"}"))  // Replace with actual fields
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1));

        verify(attendanceService, times(1)).updateAttendance(eq(1L), any(UpdateAttendanceRequest.class));
    }

    @Test
    void testDeleteAttendance() throws Exception {
        doNothing().when(attendanceService).deleteAttendance(1L);

        mockMvc.perform(delete("/api/attendance/1"))
                .andExpect(status().isOk());

        verify(attendanceService, times(1)).deleteAttendance(1L);
    }
}
