package com.payroll_app.demo.controller;

import com.payroll_app.demo.dto.LeaveTypeDistributionDTO;
import com.payroll_app.demo.dto.OvertimeTrendDTO;
import com.payroll_app.demo.dto.PayrollTrendDTO;
import com.payroll_app.demo.model.LeaveRecord;
import com.payroll_app.demo.service.ReportService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(ReportController.class)
class ReportControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ReportService reportService;

    @Test
    void testGetPayrollTrends() throws Exception {
        List<PayrollTrendDTO> trends = Arrays.asList(
                new PayrollTrendDTO(2025, 1, BigDecimal.valueOf(10000)),
                new PayrollTrendDTO(2025, 2, BigDecimal.valueOf(12000))
        );

        when(reportService.getPayrollTrends(2025)).thenReturn(trends);

        mockMvc.perform(get("/api/reports/payroll-trends")
                        .param("year", "2025"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].year").value(2025))
                .andExpect(jsonPath("$[0].month").value(1))
                .andExpect(jsonPath("$[0].amount").value(10000));
    }

    @Test
    void testGetLeaveDistribution() throws Exception {
        List<LeaveTypeDistributionDTO> leaveDistribution = Arrays.asList(
                new LeaveTypeDistributionDTO(LeaveRecord.LeaveType.SICK, 50L),
                new LeaveTypeDistributionDTO(LeaveRecord.LeaveType.ANNUAL, 30L)
        );

        when(reportService.getLeaveDistribution()).thenReturn(leaveDistribution);

        mockMvc.perform(get("/api/reports/leave-distribution"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].leaveType").value("SICK"))
                .andExpect(jsonPath("$[0].count").value(50));
    }


    @Test
    void testGetOvertimeTrends() throws Exception {
        List<OvertimeTrendDTO> overtimeTrends = Arrays.asList(
                new OvertimeTrendDTO(2025, 1, BigDecimal.valueOf(120)),
                new OvertimeTrendDTO(2025, 2, BigDecimal.valueOf(150))
        );

        when(reportService.getOvertimeTrends()).thenReturn(overtimeTrends);

        mockMvc.perform(get("/api/reports/overtime-trends"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].year").value(2025))
                .andExpect(jsonPath("$[0].month").value(1))
                .andExpect(jsonPath("$[0].totalOvertime").value(120));
    }
}
