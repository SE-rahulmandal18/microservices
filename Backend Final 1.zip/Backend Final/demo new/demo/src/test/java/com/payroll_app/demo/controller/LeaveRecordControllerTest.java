package com.payroll_app.demo.controller;

import com.payroll_app.demo.dto.LeaveRecordRequest;
import com.payroll_app.demo.model.LeaveRecord;
import com.payroll_app.demo.service.LeaveRecordService;
import com.payroll_app.demo.model.LeaveRecord.LeaveType;
import com.payroll_app.demo.model.LeaveRecord.LeaveDuration;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.time.LocalDate;
import java.util.Collections;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

class LeaveRecordControllerTest {

    private MockMvc mockMvc;

    @Mock
    private LeaveRecordService leaveRecordService;

    @InjectMocks
    private LeaveRecordController leaveRecordController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(leaveRecordController).build();
    }

    @Test
    void createLeave() throws Exception {
        LeaveRecordRequest request = new LeaveRecordRequest();
        request.setEmployeeId(1L);
        request.setStartDate(LocalDate.of(2025, 5, 1));
        request.setEndDate(LocalDate.of(2025, 5, 2));
        request.setLeaveType(LeaveType.SICK);
        request.setIsPaid(true);
        request.setDurationPerDay(LeaveDuration.FULL);

        LeaveRecord leaveRecord = new LeaveRecord(1L, null, LocalDate.of(2025, 5, 1), LocalDate.of(2025, 5, 2), LeaveType.SICK, LeaveDuration.FULL, true, 0.0);

        when(leaveRecordService.createLeave(request)).thenReturn(leaveRecord);

        mockMvc.perform(post("/api/leaves")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{ \"employeeId\": 1, \"startDate\": \"2025-05-01\", \"endDate\": \"2025-05-02\", \"leaveType\": \"SICK\", \"isPaid\": true, \"durationPerDay\": \"FULL\" }"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1L))
                .andExpect(jsonPath("$.employeeId").value(1))
                .andExpect(jsonPath("$.startDate").value("2025-05-01"))
                .andExpect(jsonPath("$.endDate").value("2025-05-02"));
    }

    @Test
    void getAllLeaves() throws Exception {
        LeaveRecord leaveRecord = new LeaveRecord(1L, null, LocalDate.of(2025, 5, 1), LocalDate.of(2025, 5, 2), LeaveType.SICK, LeaveDuration.FULL, true, 0.0);
        when(leaveRecordService.getAllLeaves()).thenReturn(Collections.singletonList(leaveRecord));

        mockMvc.perform(get("/api/leaves"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1L))
                .andExpect(jsonPath("$[0].employeeId").value(1))
                .andExpect(jsonPath("$[0].startDate").value("2025-05-01"))
                .andExpect(jsonPath("$[0].endDate").value("2025-05-02"));
    }

    @Test
    void getLeaveById() throws Exception {
        LeaveRecord leaveRecord = new LeaveRecord(1L, null, LocalDate.of(2025, 5, 1), LocalDate.of(2025, 5, 2), LeaveType.SICK, LeaveDuration.FULL, true, 0.0);
        when(leaveRecordService.getLeaveById(1L)).thenReturn(leaveRecord);

        mockMvc.perform(get("/api/leaves/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1L))
                .andExpect(jsonPath("$.employeeId").value(1))
                .andExpect(jsonPath("$.startDate").value("2025-05-01"))
                .andExpect(jsonPath("$.endDate").value("2025-05-02"));
    }

    @Test
    void updateLeave() throws Exception {
        LeaveRecordRequest request = new LeaveRecordRequest();
        request.setEmployeeId(1L);
        request.setStartDate(LocalDate.of(2025, 5, 3));
        request.setEndDate(LocalDate.of(2025, 5, 4));
        request.setLeaveType(LeaveType.ANNUAL);
        request.setIsPaid(false);
        request.setDurationPerDay(LeaveDuration.HALF);

        LeaveRecord updatedLeave = new LeaveRecord(1L, null, LocalDate.of(2025, 5, 3), LocalDate.of(2025, 5, 4), LeaveType.ANNUAL, LeaveDuration.HALF, false, 0.0);
        when(leaveRecordService.updateLeave(1L, request)).thenReturn(updatedLeave);

        mockMvc.perform(put("/api/leaves/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{ \"employeeId\": 1, \"startDate\": \"2025-05-03\", \"endDate\": \"2025-05-04\", \"leaveType\": \"ANNUAL\", \"isPaid\": false, \"durationPerDay\": \"HALF\" }"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1L))
                .andExpect(jsonPath("$.employeeId").value(1))
                .andExpect(jsonPath("$.startDate").value("2025-05-03"))
                .andExpect(jsonPath("$.endDate").value("2025-05-04"));
    }

    @Test
    void deleteLeave() throws Exception {
        doNothing().when(leaveRecordService).deleteLeave(1L);

        mockMvc.perform(delete("/api/leaves/1"))
                .andExpect(status().isNoContent());

        verify(leaveRecordService, times(1)).deleteLeave(1L);
    }

    @Test
    void getLeavesByEmployee() throws Exception {
        LeaveRecord leaveRecord = new LeaveRecord(1L, null, LocalDate.of(2025, 5, 1), LocalDate.of(2025, 5, 2), LeaveType.SICK, LeaveDuration.FULL, true, 0.0);
        when(leaveRecordService.getLeavesByEmployeeId(1L)).thenReturn(Collections.singletonList(leaveRecord));

        mockMvc.perform(get("/api/leaves/employee/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1L))
                .andExpect(jsonPath("$[0].employeeId").value(1))
                .andExpect(jsonPath("$[0].startDate").value("2025-05-01"))
                .andExpect(jsonPath("$[0].endDate").value("2025-05-02"));
    }
}
