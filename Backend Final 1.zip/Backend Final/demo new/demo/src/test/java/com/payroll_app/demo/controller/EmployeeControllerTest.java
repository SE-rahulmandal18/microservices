package com.payroll_app.demo.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.payroll_app.demo.dto.CreateEmployeeRequest;
import com.payroll_app.demo.dto.UpdateEmployeeRequest;
import com.payroll_app.demo.model.Employee;
import com.payroll_app.demo.model.User;
import com.payroll_app.demo.service.EmployeeService;
import com.payroll_app.demo.service.UserService;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.core.Authentication;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(EmployeeController.class)
class EmployeeControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private EmployeeService employeeService;

    @MockBean
    private UserService userService;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void testCreateEmployee() throws Exception {
        CreateEmployeeRequest request = new CreateEmployeeRequest();
        request.setFirstName("John");
        request.setLastName("Doe");
        request.setEmail("john@example.com");
        request.setPhone("1234567890");
        request.setDepartment("IT");
        request.setDesignation("Developer");
        request.setJoinDate(LocalDate.parse("2025-01-01"));
        request.setEmploymentType(Employee.EmploymentType.FULL_TIME);
        request.setBankAccount("9876543210");

        Employee employee = new Employee();
        employee.setId(1L);
        employee.setFirstName("John");
        employee.setLastName("Doe");

        when(employeeService.createEmployee(any(CreateEmployeeRequest.class))).thenReturn(employee);

        mockMvc.perform(post("/api/employees")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(employee.getId()))
                .andExpect(jsonPath("$.firstName").value(employee.getFirstName()))
                .andExpect(jsonPath("$.lastName").value(employee.getLastName()));
    }

    @Test
    void testGetAllEmployees() throws Exception {
        Employee employee = new Employee();
        employee.setId(1L);
        employee.setFirstName("John");
        employee.setLastName("Doe");

        when(employeeService.getAllEmployees()).thenReturn(List.of(employee));

        mockMvc.perform(get("/api/employees"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.size()").value(1))
                .andExpect(jsonPath("$[0].firstName").value("John"))
                .andExpect(jsonPath("$[0].lastName").value("Doe"));
    }

    @Test
    void testGetEmployeeByIdFound() throws Exception {
        Employee employee = new Employee();
        employee.setId(1L);
        employee.setFirstName("John");
        employee.setLastName("Doe");

        when(employeeService.getEmployeeById(1L)).thenReturn(Optional.of(employee));

        mockMvc.perform(get("/api/employees/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.firstName").value("John"))
                .andExpect(jsonPath("$.lastName").value("Doe"));
    }

    @Test
    void testGetEmployeeByIdNotFound() throws Exception {
        when(employeeService.getEmployeeById(1L)).thenReturn(Optional.empty());

        mockMvc.perform(get("/api/employees/1"))
                .andExpect(status().isNotFound());
    }

    @Test
    void testUpdateEmployee() throws Exception {
        UpdateEmployeeRequest updateRequest = new UpdateEmployeeRequest();
        updateRequest.setFirstName("Updated John");

        Employee updatedEmployee = new Employee();
        updatedEmployee.setId(1L);
        updatedEmployee.setFirstName("Updated John");

        when(employeeService.updateEmployee(Mockito.eq(1L), any(UpdateEmployeeRequest.class)))
                .thenReturn(updatedEmployee);

        mockMvc.perform(patch("/api/employees/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(updateRequest)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.firstName").value("Updated John"));
    }

    @Test
    void testGetMyEmployeeInfo() throws Exception {
        User user = new User();
        user.setId(1L);
        user.setUsername("john");

        Employee employee = new Employee();
        employee.setId(1L);
        employee.setFirstName("John");
        employee.setLastName("Doe");

        when(userService.findByUsername("john")).thenReturn(user);
        when(employeeService.findByUser(user)).thenReturn(employee);

        mockMvc.perform(get("/api/employees/me")
                        .principal(() -> "john")) // simulate authentication principal
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(employee.getId()))
                .andExpect(jsonPath("$.firstName").value(employee.getFirstName()))
                .andExpect(jsonPath("$.lastName").value(employee.getLastName()));
    }

    @Test
    void testGetMyEmployeeInfoUserNotFound() throws Exception {
        when(userService.findByUsername("john")).thenReturn(null);

        mockMvc.perform(get("/api/employees/me")
                        .principal(() -> "john"))
                .andExpect(status().isNotFound());
    }

    @Test
    void testGetMyEmployeeInfoEmployeeNotFound() throws Exception {
        User user = new User();
        user.setUsername("john");

        when(userService.findByUsername("john")).thenReturn(user);
        when(employeeService.findByUser(user)).thenReturn(null);

        mockMvc.perform(get("/api/employees/me")
                        .principal(() -> "john"))
                .andExpect(status().isNotFound());
    }

    @Test
    void testDeleteEmployee() throws Exception {
        mockMvc.perform(delete("/api/employees/1"))
                .andExpect(status().isNoContent());

        Mockito.verify(employeeService).deleteEmployee(1L);
    }
}
