package com.payroll_app.demo.controller;

import com.payroll_app.demo.dto.ProfileDTO;
import com.payroll_app.demo.service.ProfileService;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDate;
import java.time.LocalDateTime;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(ProfileController.class)
class ProfileControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ProfileService profileService;

    @Test
    void testGetProfile() throws Exception {
        ProfileDTO profile = new ProfileDTO();
        profile.setUsername("user1");
        profile.setFirstName("John");
        profile.setLastName("Doe");
        profile.setEmail("john.doe@example.com");
        profile.setPhone("123456789");
        profile.setDepartment("Engineering");
        profile.setDesignation("Developer");
        profile.setJoinDate(LocalDate.of(2020, 1, 1));
        profile.setBankAccount("123456789");
        profile.setEmploymentType("FULL_TIME");
        profile.setStatus("ACTIVE");
        profile.setCreatedAt(LocalDateTime.now());

        // Mock service
        when(profileService.getProfile("user1")).thenReturn(profile);

        mockMvc.perform(get("/api/users/me")
                        .header("Authorization", "Bearer valid-jwt-token"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.username").value("user1"))
                .andExpect(jsonPath("$.firstName").value("John"))
                .andExpect(jsonPath("$.lastName").value("Doe"))
                .andExpect(jsonPath("$.email").value("john.doe@example.com"))
                .andExpect(jsonPath("$.phone").value("123456789"))
                .andExpect(jsonPath("$.department").value("Engineering"))
                .andExpect(jsonPath("$.designation").value("Developer"))
                .andExpect(jsonPath("$.joinDate").value("2020-01-01"))
                .andExpect(jsonPath("$.bankAccount").value("123456789"))
                .andExpect(jsonPath("$.employmentType").value("FULL_TIME"))
                .andExpect(jsonPath("$.status").value("ACTIVE"));
    }

    @Test
    void testUpdateProfile() throws Exception {
        ProfileDTO profileDTO = new ProfileDTO();
        profileDTO.setUsername("user1");
        profileDTO.setFirstName("John");
        profileDTO.setLastName("Doe Updated");
        profileDTO.setEmail("john.doe.updated@example.com");
        profileDTO.setPhone("987654321");
        profileDTO.setDepartment("HR");
        profileDTO.setDesignation("Manager");
        profileDTO.setJoinDate(LocalDate.of(2020, 1, 1));
        profileDTO.setBankAccount("987654321");
        profileDTO.setEmploymentType("PART_TIME");
        profileDTO.setStatus("ACTIVE");
        profileDTO.setCreatedAt(LocalDateTime.now());

        // Mock service
        when(profileService.updateProfile("user1", profileDTO)).thenReturn(true);

        mockMvc.perform(put("/api/users/me")
                        .header("Authorization", "Bearer valid-jwt-token")
                        .contentType("application/json")
                        .content("{ \"username\": \"user1\", \"firstName\": \"John\", \"lastName\": \"Doe Updated\", \"email\": \"john.doe.updated@example.com\", \"phone\": \"987654321\", \"department\": \"HR\", \"designation\": \"Manager\", \"joinDate\": \"2020-01-01\", \"bankAccount\": \"987654321\", \"employmentType\": \"PART_TIME\", \"status\": \"ACTIVE\" }"))
                .andExpect(status().isOk())
                .andExpect(content().string("Profile updated successfully!"));
    }

    @Test
    void testChangePassword() throws Exception {
        // Mock service
        when(profileService.changePassword("user1", "oldPassword", "newPassword")).thenReturn(true);

        mockMvc.perform(put("/api/users/me/password")
                        .header("Authorization", "Bearer valid-jwt-token")
                        .contentType("application/json")
                        .content("{ \"currentPassword\": \"oldPassword\", \"newPassword\": \"newPassword\" }"))
                .andExpect(status().isOk())
                .andExpect(content().string("Password updated successfully!"));
    }
}
