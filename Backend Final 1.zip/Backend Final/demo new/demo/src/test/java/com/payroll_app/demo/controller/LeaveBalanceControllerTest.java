package com.payroll_app.demo.controller;

import com.payroll_app.demo.model.Employee;
import com.payroll_app.demo.model.LeaveBalance;
import com.payroll_app.demo.model.LeaveRecord;
import com.payroll_app.demo.service.LeaveBalanceService;
import com.payroll_app.demo.repository.EmployeeRepository;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(LeaveBalanceController.class)
class LeaveBalanceControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private LeaveBalanceService leaveBalanceService;

    @MockBean
    private EmployeeRepository employeeRepository;

    @Test
    void testGetLeaveBalance() throws Exception {
        Long employeeId = 1L;
        LeaveRecord.LeaveType leaveType = LeaveRecord.LeaveType.SICK; // Example leave type

        // Mock Employee
        Employee employee = new Employee();
        employee.setId(employeeId);
        employee.setFirstName("John");
        employee.setLastName("Doe");

        // Mock LeaveBalance
        LeaveBalance leaveBalance = new LeaveBalance();
        leaveBalance.setTotalAllowed(15.0);
        leaveBalance.setUsed(5.0);
        leaveBalance.setLeaveType(leaveType);
        leaveBalance.setEmployee(employee);
        leaveBalance.setYear(2025);

        // Mock repository and service
        when(employeeRepository.findById(employeeId)).thenReturn(Optional.of(employee));
        when(leaveBalanceService.getLeaveBalance(any(Employee.class), any(LeaveRecord.LeaveType.class))).thenReturn(leaveBalance);

        mockMvc.perform(get("/api/leave-balances/employee/{employeeId}/type/{leaveType}", employeeId, leaveType)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().string("10.0")); // Remaining balance is 15.0 - 5.0 = 10.0
    }

    @Test
    void testGetLeaveBalanceEmployeeNotFound() throws Exception {
        Long employeeId = 1L;
        LeaveRecord.LeaveType leaveType = LeaveRecord.LeaveType.SICK;

        // Mock employee repository returning empty
        when(employeeRepository.findById(employeeId)).thenReturn(Optional.empty());

        mockMvc.perform(get("/api/leave-balances/employee/{employeeId}/type/{leaveType}", employeeId, leaveType))
                .andExpect(status().isInternalServerError()); // Adjust this based on your error handling
    }
}
