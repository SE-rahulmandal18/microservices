package com.payroll_app.demo.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
@NoArgsConstructor
public class OvertimeTrendDTO {
    private int year;
    private int month;
    private BigDecimal totalOvertime;
    public OvertimeTrendDTO(int year, int month, BigDecimal totalOvertime) {
        this.year = year;
        this.month = month;
        this.totalOvertime = totalOvertime;
    }
}
