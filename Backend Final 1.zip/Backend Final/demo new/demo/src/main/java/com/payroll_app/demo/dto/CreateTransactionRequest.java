package com.payroll_app.demo.dto;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class CreateTransactionRequest {
    private Long payrollId;
    private Long employeeId;
    private String bankAccount;
    private BigDecimal amount;
}
