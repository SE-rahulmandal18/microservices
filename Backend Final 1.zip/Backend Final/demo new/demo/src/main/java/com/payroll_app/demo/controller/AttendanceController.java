package com.payroll_app.demo.controller;

import com.payroll_app.demo.dto.CreateAttendanceRequest;
import com.payroll_app.demo.dto.UpdateAttendanceRequest;
import com.payroll_app.demo.model.Attendance;
import com.payroll_app.demo.service.AttendanceService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/attendance")
@RequiredArgsConstructor
public class AttendanceController {

    private final AttendanceService attendanceService;

    @PostMapping
    public Attendance create(@RequestBody CreateAttendanceRequest request) {
        return attendanceService.createAttendance(request);
    }

    @GetMapping
    public List<Attendance> getAll() {
        return attendanceService.getAllAttendances();
    }

    @GetMapping("/{id}")
    public Attendance getById(@PathVariable Long id) {
        return attendanceService.getAttendanceById(id);
    }

    @PutMapping("/{id}")
    public Attendance update(@PathVariable Long id, @RequestBody UpdateAttendanceRequest request) {
        return attendanceService.updateAttendance(id, request);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        attendanceService.deleteAttendance(id);
    }
}
