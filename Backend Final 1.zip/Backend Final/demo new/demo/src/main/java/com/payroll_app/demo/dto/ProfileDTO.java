package com.payroll_app.demo.dto;

import com.payroll_app.demo.validation.ValidPhone;
import jakarta.validation.constraints.Email;
import lombok.Data;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
public class ProfileDTO {
    private Long employeeId;
    private String username;

    @Email
    private String email;
    private String firstName;
    private String lastName;

    @ValidPhone
    private String phone;
    private String department;
    private String designation;
    private LocalDate joinDate;
    private String bankAccount;
    private String employmentType;
    private String status;
    private LocalDateTime createdAt;
}
