package com.payroll_app.demo.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@Setter
@Getter
@NoArgsConstructor
public class PayrollTrendDTO {
    private int year;
    private int month;
    private BigDecimal totalSalary;

    public PayrollTrendDTO(int year, int month, BigDecimal totalSalary) {
        this.year = year;
        this.month = month;
        this.totalSalary = totalSalary;
    }

}


