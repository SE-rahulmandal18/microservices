package com.payroll_app.demo.controller;

import com.payroll_app.demo.dto.AuditLogRequest;
import com.payroll_app.demo.model.AuditLog;
import com.payroll_app.demo.service.AuditLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/audit-logs")
public class AuditLogController {

    @Autowired
    private AuditLogService auditLogService;

    @PostMapping
    public AuditLog createLog(@RequestBody AuditLogRequest request) {
        return auditLogService.createLog(request);
    }

    @GetMapping
    public List<AuditLog> getAllLogs() {
        return auditLogService.getAllLogs();
    }

    @GetMapping("/{id}")
    public AuditLog getLogById(@PathVariable Long id) {
        return auditLogService.getLogById(id);
    }

    @DeleteMapping("/{id}")
    public void deleteLog(@PathVariable Long id) {
        auditLogService.deleteLog(id);
    }
}
