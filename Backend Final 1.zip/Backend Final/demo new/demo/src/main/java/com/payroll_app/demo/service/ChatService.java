package com.payroll_app.demo.service;

import com.payroll_app.demo.model.*;
import com.payroll_app.demo.repository.*;
import org.springframework.stereotype.Service;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class ChatService {

    private final EmployeeRepository employeeRepository;
    private final PayrollRepository payrollRepository;
    private final AttendanceRepository attendanceRepository;
    private final LeaveRecordRepository leaveRecordRepository;
    private final AuditLogRepository auditLogRepository;
    private final TransactionRepository transactionRepository;

    public ChatService(EmployeeRepository employeeRepository,
                       PayrollRepository payrollRepository,
                       AttendanceRepository attendanceRepository,
                       LeaveRecordRepository leaveRecordRepository,
                       AuditLogRepository auditLogRepository,
                       TransactionRepository transactionRepository) {
        this.employeeRepository = employeeRepository;
        this.payrollRepository = payrollRepository;
        this.attendanceRepository = attendanceRepository;
        this.leaveRecordRepository = leaveRecordRepository;
        this.auditLogRepository = auditLogRepository;
        this.transactionRepository = transactionRepository;
    }

    public String getChatResponse(String message) {
        String lowerMessage = message.toLowerCase().trim();

        if (lowerMessage.equals("help hr")) {
            return getHrHelpMessage();
        } else if (lowerMessage.equals("help admin")) {
            return getAdminHelpMessage();
        } else if (lowerMessage.equals("help employee")) {
            return getEmployeeHelpMessage();
        }

        if (lowerMessage.startsWith("get ")) {
            return handleDataQuery(lowerMessage.substring(4));
        }

        return "🤖 I can answer data queries. Try:\n\n" +
                "• 'help hr' 👩‍💼\n" +
                "• 'help admin' 🔒\n" +
                "• 'help employee' 👤";
    }

    private String getHrHelpMessage() {
        return "📌 **HR Help Center** 👩‍💼\n\n" +
                "👥 Employee Data:\n" +
                "├─ 👥 Get employee count\n" +
                "├─ 📋 Get employee list\n" +
                "├─ 🏢 Get employees in [department]\n" +
                "├─ ✅ Get active employees\n" +
                "└─ ❌ Get inactive employees\n\n" +
                "💰 Payroll Data:\n" +
                "├─ 💵 Get payroll total\n" +
                "├─ 📊 Get payroll average\n" +
                "└─ 👤 Get payroll for [employee_id]\n\n" +
                "⏱️ Attendance:\n" +
                "├─ 📅 Get attendance count\n" +
                "└─ 👤 Get attendance for [employee_id]\n\n" +
                "🏖️ Leaves:\n" +
                "├─ ❌ Get unpaid leaves\n" +
                "├─ ✅ Get paid leaves\n" +
                "└─ 📋 Get all leaves";
    }

    private String getAdminHelpMessage() {
        return "🔒 **Admin Dashboard** ⚙️\n\n" +
                "📊 System Data:\n" +
                "├─ 👥 Get user count\n" +
                "├─ 📜 Get audit logs\n" +
                "└─ ⏱️ Get last 5 audit logs\n\n" +
                "💳 Financial:\n" +
                "├─ 🔢 Get total transactions\n" +
                "├─ ❌ Get failed transactions\n" +
                "├─ ⏳ Get pending transactions\n" +
                "├─ ✅ Get successful transactions\n" +
                "└─ ⏱️ Get last 5 transactions";
    }

    private String getEmployeeHelpMessage() {
        return "👤 **Employee Self-Service** 💼\n\n" +
                "📋 My Data:\n" +
                "├─ ℹ️ Get my details [employee_id]\n" +
                "├─ ⏱️ Get my attendance [employee_id]\n" +
                "└─ 🏖️ Get my leaves [employee_id]\n\n" +
                "💰 Payroll:\n" +
                "├─ 💵 Get my payroll [employee_id]\n" +
                "└─ ⏱️ Get my last payment [employee_id]";
    }

    private String handleDataQuery(String query) {
        try {
            // Employee queries
            if (query.startsWith("employee count")) {
                long count = employeeRepository.count();
                return "👥 **Employee Count**\n\n" +
                        "│ Total Employees: " + count + "\n" +
                        "│ ✅ Active: " + employeeRepository.findByStatus(Employee.EmployeeStatus.ACTIVE).size() + "\n" +
                        "│ ❌ Inactive: " + employeeRepository.findByStatus(Employee.EmployeeStatus.INACTIVE).size();
            }
            else if (query.startsWith("employee list")) {
                return "📋 **Employee List**\n\n" + formatEmployeeList(employeeRepository.findAll());
            }
            else if (query.startsWith("employees in ")) {
                String dept = query.substring(13);
                List<Employee> employees = employeeRepository.findByDepartment(dept);
                return "🏢 **Employees in " + dept + " Department**\n\n" +
                        formatEmployeeList(employees) + "\n\n" +
                        "│ Total: " + employees.size();
            }
            else if (query.startsWith("active employees")) {
                return "✅ **Active Employees**\n\n" +
                        formatEmployeeList(employeeRepository.findByStatus(Employee.EmployeeStatus.ACTIVE));
            }
            else if (query.startsWith("inactive employees")) {
                return "❌ **Inactive Employees**\n\n" +
                        formatEmployeeList(employeeRepository.findByStatus(Employee.EmployeeStatus.INACTIVE));
            }

            // Payroll queries
            else if (query.startsWith("payroll total")) {
                double total = calculateTotalPayroll();
                double avg = calculateAverageSalary();
                return "💰 **Payroll Summary**\n\n" +
                        "│ Total Amount: $" + String.format("%.2f", total) + "\n" +
                        "│ Average Salary: $" + String.format("%.2f", avg);
            }
            else if (query.startsWith("payroll average")) {
                return "📊 **Average Salary**\n\n" +
                        "│ $" + String.format("%.2f", calculateAverageSalary());
            }
            else if (query.startsWith("payroll for ") || query.startsWith("my payroll ")) {
                Long id = query.startsWith("payroll for ") ?
                        Long.parseLong(query.substring(12)) :
                        Long.parseLong(query.substring(11));
                return "💵 **Payroll Details**\n\n" +
                        formatPayrollDetails(payrollRepository.findByEmployeeId(id));
            }
            else if (query.startsWith("my last payment ")) {
                Long id = Long.parseLong(query.substring(16));
                List<Payroll> payrolls = payrollRepository.findByEmployeeIdOrderByIdDesc(id);
                if (!payrolls.isEmpty()) {
                    return "⏱️ **Last Payment**\n\n" +
                            formatPayrollDetails(Collections.singletonList(payrolls.get(0)));
                }
                return "❌ No payroll records found for employee " + id;
            }

            // Attendance queries
            else if (query.startsWith("attendance count")) {
                return "📅 **Attendance Records**\n\n" +
                        "│ Total: " + attendanceRepository.count();
            }
            else if (query.startsWith("attendance for ") || query.startsWith("my attendance ")) {
                Long id = query.startsWith("attendance for ") ?
                        Long.parseLong(query.substring(15)) :
                        Long.parseLong(query.substring(14));
                List<Attendance> records = attendanceRepository.findByEmployeeId(id);
                return "⏱️ **Attendance for Employee " + id + "**\n\n" +
                        "│ Total Records: " + records.size() + "\n\n" +
                        formatAttendanceList(records);
            }

            // Leave queries
            else if (query.startsWith("unpaid leaves")) {
                List<LeaveRecord> leaves = leaveRecordRepository.findByIsPaid(false);
                return "❌ **Unpaid Leaves**\n\n" +
                        "│ Total: " + leaves.size() + "\n\n" +
                        formatLeaveList(leaves);
            }
            else if (query.startsWith("paid leaves")) {
                List<LeaveRecord> leaves = leaveRecordRepository.findByIsPaid(true);
                return "✅ **Paid Leaves**\n\n" +
                        "│ Total: " + leaves.size() + "\n\n" +
                        formatLeaveList(leaves);
            }
            else if (query.startsWith("all leaves")) {
                List<LeaveRecord> leaves = leaveRecordRepository.findAll();
                return "📋 **All Leaves**\n\n" +
                        "│ Total: " + leaves.size() + "\n\n" +
                        formatLeaveList(leaves);
            }
            else if (query.startsWith("my leaves ")) {
                Long id = Long.parseLong(query.substring(10));
                List<LeaveRecord> leaves = leaveRecordRepository.findByEmployeeId(id);
                return "🏖️ **My Leaves**\n\n" +
                        "│ Total: " + leaves.size() + "\n\n" +
                        formatLeaveList(leaves);
            }

            // Admin queries
            else if (query.startsWith("user count")) {
                return "👥 **User Count**\n\n" +
                        "│ Total: " + auditLogRepository.count();
            }
            else if (query.startsWith("audit logs")) {
                return "📜 **Audit Logs**\n\n" +
                        "│ Total: " + auditLogRepository.count();
            }
            else if (query.startsWith("last 5 audit logs")) {
                return "⏱️ **Recent Audit Logs**\n\n" +
                        formatAuditLogs(auditLogRepository.findTop5ByOrderByPerformedAtDesc());
            }
            else if (query.startsWith("total transactions")) {
                return "🔢 **Transaction Summary**\n\n" +
                        "│ Total: " + transactionRepository.count();
            }
            else if (query.startsWith("failed transactions")) {
                return "❌ **Failed Transactions**\n\n" +
                        formatTransactions(transactionRepository.findByStatus(Transaction.TransactionStatus.FAILED));
            }
            else if (query.startsWith("pending transactions")) {
                return "⏳ **Pending Transactions**\n\n" +
                        formatTransactions(transactionRepository.findByStatus(Transaction.TransactionStatus.PENDING));
            }
            else if (query.startsWith("successful transactions")) {
                return "✅ **Successful Transactions**\n\n" +
                        formatTransactions(transactionRepository.findByStatus(Transaction.TransactionStatus.SUCCESS));
            }
            else if (query.startsWith("last 5 transactions")) {
                return "⏱️ **Recent Transactions**\n\n" +
                        formatTransactions(transactionRepository.findTop5ByOrderByTransactionDateDesc());
            }

            // Employee details
            else if (query.startsWith("my details ")) {
                Long id = Long.parseLong(query.substring(11));
                return "👤 **Employee Details**\n\n" +
                        formatEmployeeDetails(employeeRepository.findById(id).orElse(null));
            }
            else {
                return "🤔 I didn't understand your query. Try:\n\n" +
                        "• 'help hr' 👩‍💼\n" +
                        "• 'help admin' 🔒\n" +
                        "• 'help employee' 👤";
            }
        } catch (Exception e) {
            return "❌ Error processing your request: " + e.getMessage();
        }
    }

    private String formatEmployeeList(List<Employee> employees) {
        if (employees.isEmpty()) return "│ No employees found";

        return employees.stream()
                .limit(10)
                .map(e -> "│ " + e.getId() + ": " + e.getFirstName() + " " + e.getLastName() +
                        " (" + e.getDepartment() + ", " + e.getStatus() + ")")
                .collect(Collectors.joining("\n")) +
                (employees.size() > 10 ? "\n│ ...and " + (employees.size() - 10) + " more" : "");
    }

    private String formatEmployeeDetails(Employee employee) {
        if (employee == null) return "│ Employee not found";

        return "│ ID: " + employee.getId() + "\n" +
                "│ Name: " + employee.getFirstName() + " " + employee.getLastName() + "\n" +
                "│ Email: " + employee.getEmail() + "\n" +
                "│ Phone: " + employee.getPhone() + "\n" +
                "│ Department: " + employee.getDepartment() + "\n" +
                "│ Designation: " + employee.getDesignation() + "\n" +
                "│ Status: " + employee.getStatus() + "\n" +
                "│ Join Date: " + employee.getJoinDate() + "\n" +
                "│ Bank Account: " + employee.getBankAccount();
    }

    private String formatPayrollDetails(List<Payroll> payrolls) {
        if (payrolls.isEmpty()) return "│ No payroll records found";

        return payrolls.stream()
                .map(p -> "│ Payroll ID: " + p.getId() + "\n" +
                        "│ Employee: " + p.getEmployee().getFirstName() + " " + p.getEmployee().getLastName() + "\n" +
                        "│ Basic Salary: $" + String.format("%.2f", p.getBasicSalary()) + "\n" +
                        "│ Allowances: $" + String.format("%.2f", p.getAllowances()) + "\n" +
                        "│ Bonuses: $" + String.format("%.2f", p.getBonuses()) + "\n" +
                        "│ Deductions: $" + String.format("%.2f", p.getDeductions()) + "\n" +
                        "│ Net Salary: $" + String.format("%.2f", p.getNetSalary()) + "\n" +
                        "│ Status: " + p.getPaymentStatus() + "\n" +
                        "│ Processed: " + (p.getProcessedAt() != null ? p.getProcessedAt().toString() : "Not processed"))
                .collect(Collectors.joining("\n\n"));
    }

    private String formatLeaveList(List<LeaveRecord> leaves) {
        if (leaves.isEmpty()) return "│ No leave records found";

        return leaves.stream()
                .limit(5)
                .map(l -> "│ " + l.getId() + ": " + l.getStartDate() + " to " + l.getEndDate() +
                        " (" + l.getLeaveType() + ", " + (l.isPaid() ? "✅ Paid" : "❌ Unpaid") + ")")
                .collect(Collectors.joining("\n")) +
                (leaves.size() > 5 ? "\n│ ...and " + (leaves.size() - 5) + " more" : "");
    }

    private String formatAttendanceList(List<Attendance> records) {
        if (records.isEmpty()) return "│ No attendance records found";

        return records.stream()
                .limit(5)
                .map(a -> "│ " + a.getWorkDate() + ": " + a.getCheckInTime() + " to " +
                        a.getCheckOutTime() + " (" + String.format("%.2f", a.getTotalHours().doubleValue()) + " hrs)")
                .collect(Collectors.joining("\n")) +
                (records.size() > 5 ? "\n│ ...and " + (records.size() - 5) + " more" : "");
    }

    private String formatTransactions(List<Transaction> transactions) {
        if (transactions.isEmpty()) return "│ No transactions found";

        return transactions.stream()
                .limit(5)
                .map(t -> "│ " + t.getId() + ": " + t.getEmployee().getFirstName() +
                        " - " + getStatusEmoji(t.getStatus()) + " " + t.getStatus() +
                        " ($" + String.format("%.2f", t.getAmount()) + ") on " + t.getTransactionDate())
                .collect(Collectors.joining("\n")) +
                (transactions.size() > 5 ? "\n│ ...and " + (transactions.size() - 5) + " more" : "");
    }

    private String getStatusEmoji(Transaction.TransactionStatus status) {
        return status == Transaction.TransactionStatus.SUCCESS ? "✅" :
                status == Transaction.TransactionStatus.FAILED ? "❌" : "⏳";
    }

    private String formatAuditLogs(List<AuditLog> logs) {
        if (logs.isEmpty()) return "│ No audit logs found";

        return logs.stream()
                .map(l -> "│ " + l.getAction() + ": " + l.getDetails() +
                        " by 👤" + l.getPerformedBy().getUsername() + " at " + l.getPerformedAt())
                .collect(Collectors.joining("\n"));
    }

    private double calculateTotalPayroll() {
        return payrollRepository.findAll().stream()
                .mapToDouble(p -> p.getNetSalary().doubleValue())
                .sum();
    }

    private double calculateAverageSalary() {
        return payrollRepository.findAll().stream()
                .mapToDouble(p -> p.getNetSalary().doubleValue())
                .average()
                .orElse(0);
    }

    public List<String> getCommonQuestions() {
        return List.of(
                "help hr",
                "help admin",
                "help employee",
                "get employee count",
                "get employee list",
                "get active employees",
                "get payroll total",
                "get payroll for 1",
                "get my payroll 1",
                "get my last payment 1",
                "get attendance count",
                "get attendance for 1",
                "get unpaid leaves",
                "get failed transactions",
                "get pending transactions",
                "get successful transactions"
        );
    }
}

