package com.payroll_app.demo.controller;

import com.payroll_app.demo.dto.PayrollRequest;
import com.payroll_app.demo.dto.PayrollResponse;
import com.payroll_app.demo.model.User;
import com.payroll_app.demo.service.PayrollService;
import com.payroll_app.demo.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/payrolls")
@RequiredArgsConstructor
public class PayrollController {

    private final PayrollService payrollService;

    private final UserService userService;

    @GetMapping
    public ResponseEntity<List<PayrollResponse>> getAllPayrolls(Authentication authentication) {
        String userName = authentication.getName(); // Extract from JWT
        Optional<User> optionalUser = userService.getUserByUsername(userName);

        if (optionalUser.isEmpty()) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        User user = optionalUser.get(); 
        String role = user.getRole().name();

        List<PayrollResponse> payrolls;

        if ("ADMIN".equals(role) || "HR".equals(role)) {
            payrolls = payrollService.getAllPayrolls(); // Return all
        } else {
            payrolls = payrollService.getPayrollsByUserId(user.getId()); // Return only this user's payrolls
        }

        return ResponseEntity.ok(payrolls);
    }


    @PostMapping
    public ResponseEntity<PayrollResponse> createPayroll(@RequestBody PayrollRequest request) {
        return ResponseEntity.ok(payrollService.createPayroll(request));
    }

    @PatchMapping("/{id}")
    public ResponseEntity<PayrollResponse> updatePayroll(@PathVariable Long id, @RequestBody PayrollRequest request) {
        return ResponseEntity.ok(payrollService.updatePayroll(id, request));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePayroll(@PathVariable Long id) {
        payrollService.deletePayroll(id);
        return ResponseEntity.noContent().build();
    }
}
