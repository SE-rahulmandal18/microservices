package com.payroll_app.demo.controller;

import com.payroll_app.demo.dto.CreateTransactionRequest;
import com.payroll_app.demo.dto.UpdateTransactionStatusRequest;
import com.payroll_app.demo.model.Transaction;
import com.payroll_app.demo.service.TransactionService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/transactions")
@RequiredArgsConstructor
public class TransactionController {

    private final TransactionService transactionService;

    @GetMapping
    public List<Transaction> getAll() {
        return transactionService.getAllTransactions();
    }

    @GetMapping("/{id}")
    public Transaction getById(@PathVariable Long id) {
        return transactionService.getTransactionById(id);
    }

    @PostMapping
    public Transaction create(@RequestBody CreateTransactionRequest request) {
        return transactionService.createTransaction(request);
    }

    @PutMapping("/{id}/status")
    public Transaction updateStatus(
            @PathVariable Long id,
            @RequestBody UpdateTransactionStatusRequest request
    ) {
        return transactionService.updateStatus(id, request);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        transactionService.deleteTransaction(id);
    }

    @PostMapping("/{id}/retry")
    public Transaction retryTransaction(@PathVariable Long id) {
        return transactionService.retryTransaction(id);
    }

}
