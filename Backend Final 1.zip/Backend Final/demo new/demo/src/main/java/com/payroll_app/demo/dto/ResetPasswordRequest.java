package com.payroll_app.demo.dto;

import com.payroll_app.demo.validation.ValidPassword;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class ResetPasswordRequest {
    @Email(message = "Invalid email format")
    private String email;

    @NotBlank(message = "OTP is required")
    private String otp;

    @ValidPassword
    @NotBlank(message = "New password cannot be blank")
    private String newPassword;
}

