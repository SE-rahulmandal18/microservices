package com.payroll_app.demo.validation;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;

import java.lang.annotation.*;

@Documented
@Constraint(validatedBy = PhoneValidator.class)
@Target({ ElementType.FIELD })
@Retention(RetentionPolicy.RUNTIME)
public @interface ValidPhone {
    String message() default "Invalid phone number. It must be 10 digits and only numbers allowed.";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
