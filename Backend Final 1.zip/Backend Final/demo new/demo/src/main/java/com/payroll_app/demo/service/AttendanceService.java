package com.payroll_app.demo.service;

import com.payroll_app.demo.dto.CreateAttendanceRequest;
import com.payroll_app.demo.dto.UpdateAttendanceRequest;
import com.payroll_app.demo.model.Attendance;
import com.payroll_app.demo.model.Employee;
import com.payroll_app.demo.repository.AttendanceRepository;
import com.payroll_app.demo.repository.EmployeeRepository;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class AttendanceService {

    private final AttendanceRepository attendanceRepository;
    private final EmployeeRepository employeeRepository;

    public Attendance createAttendance(CreateAttendanceRequest request) {
        Employee employee = employeeRepository.findById(request.getEmployeeId())
                .orElseThrow(() -> {
                    log.error("Employee not found with ID: {}", request.getEmployeeId());
                    return new EntityNotFoundException("Employee not found");
                });

        Attendance attendance = new Attendance();
        attendance.setEmployee(employee);
        attendance.setWorkDate(request.getWorkDate());
        attendance.setCheckInTime(request.getCheckInTime());
        attendance.setCheckOutTime(request.getCheckOutTime());

        Attendance saved = attendanceRepository.save(attendance);
        log.info("Created attendance record (ID: {}) for employee ID: {}", saved.getId(), employee.getId());
        return saved;
    }

    public List<Attendance> getAllAttendances() {
        log.info("Fetching all attendance records");
        return attendanceRepository.findAll();
    }

    public Attendance getAttendanceById(Long id) {
        return attendanceRepository.findById(id)
                .orElseThrow(() -> {
                    log.error("Attendance not found with ID: {}", id);
                    return new EntityNotFoundException("Attendance not found");
                });
    }

    public Attendance updateAttendance(Long id, UpdateAttendanceRequest request) {
        Attendance attendance = attendanceRepository.findById(id)
                .orElseThrow(() -> {
                    log.error("Attendance not found for update, ID: {}", id);
                    return new EntityNotFoundException("Attendance not found");
                });

        attendance.setWorkDate(request.getWorkDate());
        attendance.setCheckInTime(request.getCheckInTime());
        attendance.setCheckOutTime(request.getCheckOutTime());

        Attendance updated = attendanceRepository.save(attendance);
        log.info("Updated attendance record (ID: {})", updated.getId());
        return updated;
    }

    public void deleteAttendance(Long id) {
        if (!attendanceRepository.existsById(id)) {
            log.error("Attempted to delete non-existent attendance ID: {}", id);
            throw new EntityNotFoundException("Attendance not found");
        }
        attendanceRepository.deleteById(id);
        log.info("Deleted attendance record with ID: {}", id);
    }

}
