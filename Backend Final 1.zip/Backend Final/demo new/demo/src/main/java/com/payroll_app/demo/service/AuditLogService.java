package com.payroll_app.demo.service;

import com.payroll_app.demo.dto.AuditLogRequest;
import com.payroll_app.demo.model.AuditLog;
import com.payroll_app.demo.model.User;
import com.payroll_app.demo.repository.AuditLogRepository;
import com.payroll_app.demo.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AuditLogService {

    @Autowired
    private AuditLogRepository auditLogRepository;

    @Autowired
    private UserRepository userRepository;

    public AuditLog createLog(AuditLogRequest request) {
        User user = userRepository.findById(request.getPerformedById())
                .orElseThrow(() -> new RuntimeException("User not found"));

        AuditLog log = new AuditLog();
        log.setAction(request.getAction());
        log.setPerformedBy(user);
        log.setDetails(request.getDetails());

        return auditLogRepository.save(log);
    }

    public List<AuditLog> getAllLogs() {
        return auditLogRepository.findAll();
    }

    public AuditLog getLogById(Long id) {
        return auditLogRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Log not found"));
    }

    public void deleteLog(Long id) {
        auditLogRepository.deleteById(id);
    }
}
