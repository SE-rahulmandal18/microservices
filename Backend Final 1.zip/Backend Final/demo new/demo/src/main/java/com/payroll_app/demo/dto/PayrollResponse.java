package com.payroll_app.demo.dto;

import com.payroll_app.demo.model.Payroll;
import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import lombok.Builder;

@Data
@Builder
public class PayrollResponse {
    private Long id;
    private Long employeeId;
    private String employeeName;
    private BigDecimal basicSalary;
    private BigDecimal allowances;
    private BigDecimal overtime;
    private BigDecimal bonuses;
    private BigDecimal deductions;
    private int lopDays;
    private BigDecimal lopDeduction;
    private BigDecimal netSalary;
    private LocalDateTime processedAt;
    private Payroll.PaymentStatus paymentStatus;
}
