package com.payroll_app.demo.service;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class EmailService {

    private final JavaMailSender mailSender;

    private static final Logger logger = LoggerFactory.getLogger(EmailService.class);

    public void sendOtpEmail(String to, String otp) {
        if (to == null || to.isEmpty() || otp == null || otp.isEmpty()) {
            throw new IllegalArgumentException("Email address and OTP cannot be null or empty");
        }

        MimeMessage message = mailSender.createMimeMessage();
        try {
            MimeMessageHelper helper = new MimeMessageHelper(message, true);
            helper.setTo(to);
            helper.setSubject("Your OTP for Password Reset");
            helper.setText("Your OTP is: " + otp + ". It will expire in 10 minutes.", true);

            mailSender.send(message);

            // Log success
            logger.info("OTP email sent successfully to {}", to);
        } catch (MessagingException e) {
            // Log failure
            logger.error("Failed to send OTP email to {}: {}", to, e.getMessage());

            // Throw a generic RuntimeException instead of a custom exception
            throw new RuntimeException("Failed to send email to " + to, e);
        }
    }
}
