package com.payroll_app.demo.validation;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;

import java.lang.annotation.*;

@Documented
@Constraint(validatedBy = PasswordValidator.class)
@Target({ ElementType.FIELD })
@Retention(RetentionPolicy.RUNTIME)
public @interface ValidPassword {
    String message() default "Password must contain at least 1 uppercase, 1 lowercase,1 special character and min 6 char";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
