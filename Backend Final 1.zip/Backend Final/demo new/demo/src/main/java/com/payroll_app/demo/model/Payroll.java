package com.payroll_app.demo.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.Builder;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;

@Entity
@Table(name = "payroll")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Payroll {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "employee_id", nullable = false)
    private Employee employee;

    @Column(nullable = false)
    private BigDecimal basicSalary;

    @Column(nullable = false)
    private BigDecimal allowances = BigDecimal.ZERO;

    @Column(nullable = false)
    private BigDecimal overtime = BigDecimal.ZERO;

    @Column(nullable = false)
    private BigDecimal bonuses = BigDecimal.ZERO;

    @Column(nullable = false)
    private BigDecimal deductions = BigDecimal.ZERO;

    @Column(nullable = false)
    private int lopDays = 0;

    @Column(nullable = false)
    private BigDecimal lopDeduction;

    @Column(nullable = false)
    private BigDecimal netSalary;

    @Enumerated(EnumType.STRING)
    private PaymentStatus paymentStatus = PaymentStatus.PENDING;

    private LocalDateTime processedAt;

    @PrePersist
    @PreUpdate
    public void calculatePayroll() {
        this.lopDeduction = (basicSalary.divide(BigDecimal.valueOf(30), RoundingMode.HALF_UP))
                .multiply(BigDecimal.valueOf(lopDays));
        this.netSalary = basicSalary.add(allowances)
                .add(overtime)
                .add(bonuses)
                .subtract(deductions)
                .subtract(lopDeduction);
        if (this.paymentStatus == PaymentStatus.PROCESSED && this.processedAt == null) {
            this.processedAt = LocalDateTime.now();
        }
    }

    public enum PaymentStatus {
        PENDING, PROCESSED, FAILED
    }
}
