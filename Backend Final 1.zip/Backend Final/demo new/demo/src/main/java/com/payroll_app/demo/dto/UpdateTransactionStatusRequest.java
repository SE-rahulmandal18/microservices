package com.payroll_app.demo.dto;

import com.payroll_app.demo.model.Transaction.TransactionStatus;
import lombok.Data;

@Data
public class UpdateTransactionStatusRequest {
    private TransactionStatus status;
    private String failureReason;
}
