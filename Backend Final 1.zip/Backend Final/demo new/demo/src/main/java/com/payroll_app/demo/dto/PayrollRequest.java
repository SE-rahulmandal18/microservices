package com.payroll_app.demo.dto;

import com.payroll_app.demo.model.Payroll;
import lombok.Data;
import java.math.BigDecimal;

@Data
public class PayrollRequest {
    private Long employeeId;
    private BigDecimal basicSalary;
    private BigDecimal allowances;
    private BigDecimal overtime;
    private BigDecimal bonuses;
    private BigDecimal deductions;
    private Integer lopDays;
    private Payroll.PaymentStatus paymentStatus;
}
