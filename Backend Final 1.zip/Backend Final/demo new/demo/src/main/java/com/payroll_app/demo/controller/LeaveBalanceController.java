package com.payroll_app.demo.controller;

import com.payroll_app.demo.model.Employee;
import com.payroll_app.demo.model.LeaveRecord;
import com.payroll_app.demo.repository.EmployeeRepository;
import com.payroll_app.demo.service.LeaveBalanceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/leave-balances")
public class LeaveBalanceController {

    @Autowired
    private LeaveBalanceService leaveBalanceService;

    @Autowired
    private EmployeeRepository employeeRepository;

    @GetMapping("/employee/{employeeId}/type/{leaveType}")
    public double getLeaveBalance(@PathVariable Long employeeId, @PathVariable LeaveRecord.LeaveType leaveType) {
        Employee employee = employeeRepository.findById(employeeId)
                .orElseThrow(() -> new RuntimeException("Employee not found"));
        return leaveBalanceService.getLeaveBalance(employee, leaveType).getRemaining();
    }

}
