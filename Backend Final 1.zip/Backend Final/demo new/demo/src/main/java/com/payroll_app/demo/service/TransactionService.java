package com.payroll_app.demo.service;

import com.payroll_app.demo.dto.CreateTransactionRequest;
import com.payroll_app.demo.dto.UpdateTransactionStatusRequest;
import com.payroll_app.demo.model.Employee;
import com.payroll_app.demo.model.Payroll;
import com.payroll_app.demo.model.Transaction;
import com.payroll_app.demo.repository.EmployeeRepository;
import com.payroll_app.demo.repository.PayrollRepository;
import com.payroll_app.demo.repository.TransactionRepository;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class TransactionService {

    private final TransactionRepository transactionRepo;
    private final PayrollRepository payrollRepo;
    private final EmployeeRepository employeeRepo;

    public List<Transaction> getAllTransactions() {
        return transactionRepo.findAll();
    }

    public Transaction getTransactionById(Long id) {
        return transactionRepo.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Transaction not found"));
    }

    public Transaction createTransaction(CreateTransactionRequest request) {
        Payroll payroll = payrollRepo.findById(request.getPayrollId())
                .orElseThrow(() -> new EntityNotFoundException("Payroll not found"));

        Employee employee = employeeRepo.findById(request.getEmployeeId())
                .orElseThrow(() -> new EntityNotFoundException("Employee not found"));

        Transaction transaction = new Transaction();
        transaction.setPayroll(payroll);
        transaction.setEmployee(employee);
        transaction.setBankAccount(request.getBankAccount());
        transaction.setAmount(request.getAmount());
        transaction.setStatus(Transaction.TransactionStatus.PENDING);

        return transactionRepo.save(transaction);
    }

    public Transaction updateStatus(Long id, UpdateTransactionStatusRequest request) {
        Transaction transaction = getTransactionById(id);
        transaction.setStatus(request.getStatus());
        transaction.setFailureReason(request.getFailureReason());
        return transactionRepo.save(transaction);
    }

    public void deleteTransaction(Long id) {
        if (!transactionRepo.existsById(id)) {
            throw new EntityNotFoundException("Transaction not found");
        }
        transactionRepo.deleteById(id);
    }

    public Transaction retryTransaction(Long id) {
        Transaction tx = transactionRepo.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Transaction not found"));

        if (tx.getStatus() == Transaction.TransactionStatus.SUCCESS) {
            throw new IllegalStateException("Transaction already successful");
        }

        // Simulate retry logic
        tx.setStatus(Transaction.TransactionStatus.SUCCESS);
        tx.setFailureReason(null); // Clear previous reason if any

        return transactionRepo.save(tx);
    }

}
