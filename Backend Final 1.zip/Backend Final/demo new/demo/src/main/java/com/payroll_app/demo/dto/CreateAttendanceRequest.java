package com.payroll_app.demo.dto;

import lombok.Data;

import java.time.LocalDate;
import java.time.LocalTime;

@Data
public class CreateAttendanceRequest {
    private Long employeeId;
    private LocalDate workDate;
    private LocalTime checkInTime;
    private LocalTime checkOutTime;
}
