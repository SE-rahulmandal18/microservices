package com.payroll_app.demo.controller;

import com.payroll_app.demo.dto.CreateEmployeeRequest;
import com.payroll_app.demo.dto.UpdateEmployeeRequest;
import com.payroll_app.demo.model.Employee;
import com.payroll_app.demo.model.User;
import com.payroll_app.demo.service.EmployeeService;
import com.payroll_app.demo.service.UserService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/employees")
@RequiredArgsConstructor
public class EmployeeController {

    private final EmployeeService employeeService;
    private final UserService userService;

    // Create a new employee
    @PostMapping
    public ResponseEntity<Employee> create(@RequestBody @Valid CreateEmployeeRequest request) {
        Employee employee = employeeService.createEmployee(request);
        return ResponseEntity.ok(employee);
    }

    // Get all employees
    @GetMapping
    public ResponseEntity<List<Employee>> getAll() {
        return ResponseEntity.ok(employeeService.getAllEmployees());
    }

    // Get an employee by their ID
    @GetMapping("/{id}")
    public ResponseEntity<Employee> getById(@PathVariable Long id) {
        return employeeService.getEmployeeById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // Update an employee's information
    @PatchMapping("/{id}")
    public ResponseEntity<Employee> updateEmployee(@PathVariable Long id, @RequestBody UpdateEmployeeRequest updateRequest) {
        Employee updatedEmployee = employeeService.updateEmployee(id, updateRequest);
        return ResponseEntity.ok(updatedEmployee);
    }

    // Get current employee info (the logged-in user)
    @GetMapping("/me")
    public ResponseEntity<Employee> getMyEmployeeInfo(Authentication authentication) {
        String username = authentication.getName(); // Get the logged-in user's username
        User user = userService.findByUsername(username); // Fetch the User by username (Ensure 'findByUsername' is a valid method in your UserService)

        if (user == null) {
            return ResponseEntity.status(404).build();  // Return 404 if the user is not found
        }

        Employee employee = employeeService.findByUser(user); // Fetch employee associated with the user

        if (employee == null) {
            return ResponseEntity.status(404).build();
        }

        return ResponseEntity.ok(employee);
    }

    // Delete an employee by their ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        employeeService.deleteEmployee(id);
        return ResponseEntity.noContent().build();
    }
}

