package com.payroll_app.demo.dto;

import com.payroll_app.demo.model.Employee;
import com.payroll_app.demo.validation.ValidPhone;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

import jakarta.validation.constraints.*;

@Getter
@Setter
public class CreateEmployeeRequest {
    @NotNull
    private Long userId;

    @NotBlank
    private String firstName;

    @NotBlank
    private String lastName;

    @Email
    @NotBlank
    private String email;

    @ValidPhone
    @NotBlank
    private String phone;

    @NotBlank
    private String department;

    @NotBlank
    private String designation;

    @NotNull
    private LocalDate joinDate;

    @NotNull
    private Employee.EmploymentType employmentType;

    @NotBlank
    private String bankAccount;

    @NotNull
    private Employee.EmployeeStatus status;
}
