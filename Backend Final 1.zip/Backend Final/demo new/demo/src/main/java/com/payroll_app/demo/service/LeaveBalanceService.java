package com.payroll_app.demo.service;

import com.payroll_app.demo.model.Employee;
import com.payroll_app.demo.model.LeaveBalance;
import com.payroll_app.demo.model.LeaveRecord;
import com.payroll_app.demo.repository.LeaveBalanceRepository;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.time.Year;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class LeaveBalanceService {

    private final LeaveBalanceRepository leaveBalanceRepository;

    private static final Logger logger = LoggerFactory.getLogger(LeaveBalanceService.class);

    // Update leave balance when leave is applied
    public double useLeaveBalance(Employee employee, LeaveRecord.LeaveType leaveType, double days) {
        int currentYear = Year.now().getValue();
        logger.info("Applying leave for Employee ID: {}, Type: {}, Days: {}", employee.getId(), leaveType, days);

        Optional<LeaveBalance> leaveBalanceOpt = leaveBalanceRepository.findByEmployeeAndLeaveTypeAndYear(employee, leaveType, currentYear);

        LeaveBalance leaveBalance;

        if (leaveBalanceOpt.isPresent()) {
            leaveBalance = leaveBalanceOpt.get();
        } else {
            leaveBalance = new LeaveBalance();
            leaveBalance.setEmployee(employee);
            leaveBalance.setLeaveType(leaveType);
            leaveBalance.setYear(currentYear);

            double allowed = switch (leaveType) {
                case ANNUAL -> 12.0;
                case SICK -> 10.0;
                case CASUAL -> 8.0;
                default -> 0.0;
            };

            leaveBalance.setTotalAllowed(allowed);
            leaveBalance.setUsed(0);
            logger.info("Initialized new leave balance record for Employee ID: {}, Type: {}", employee.getId(), leaveType);
        }

        double remaining = leaveBalance.getRemaining();
        double paidDays = Math.min(days, remaining);
        double lopDays = days - paidDays;

        if (paidDays > 0) {
            leaveBalance.useLeave(paidDays);
            leaveBalanceRepository.save(leaveBalance);
            logger.info("Used {} days from leave balance for Employee ID: {}. Remaining: {}", paidDays, employee.getId(), leaveBalance.getRemaining());
        }

        if (lopDays > 0) {
            logger.info("LOP applicable for Employee ID: {} for {} days", employee.getId(), lopDays);
        }

        return paidDays;
    }

    // Recredit leave balance when leave is canceled or updated
    public void recreditLeaveBalance(Employee employee, LeaveRecord.LeaveType leaveType, double days) {
        int currentYear = Year.now().getValue();
        logger.info("Recrediting {} days of {} leave for Employee ID: {}", days, leaveType, employee.getId());

        Optional<LeaveBalance> leaveBalanceOpt = leaveBalanceRepository.findByEmployeeAndLeaveTypeAndYear(employee, leaveType, currentYear);

        if (leaveBalanceOpt.isPresent()) {
            LeaveBalance leaveBalance = leaveBalanceOpt.get();
            leaveBalance.recreditLeave(days);
            leaveBalanceRepository.save(leaveBalance);
            logger.info("Leave recredited. New used count: {}, remaining: {}", leaveBalance.getUsed(), leaveBalance.getRemaining());
        } else {
            logger.warn("Leave balance record not found for Employee ID: {}, Type: {}, Year: {}", employee.getId(), leaveType, currentYear);
        }
    }

    // Fetch leave balance
    public LeaveBalance getLeaveBalance(Employee employee, LeaveRecord.LeaveType leaveType) {
        int currentYear = Year.now().getValue();
        logger.info("Fetching leave balance for Employee ID: {}, Type: {}, Year: {}", employee.getId(), leaveType, currentYear);

        return leaveBalanceRepository.findByEmployeeAndLeaveTypeAndYear(employee, leaveType, currentYear)
                .orElseThrow(() -> {
                    logger.error("Leave balance not found for Employee ID: {}, Type: {}, Year: {}", employee.getId(), leaveType, currentYear);
                    return new RuntimeException("Leave balance not found");
                });
    }

    public void saveLeaveBalance(LeaveBalance leaveBalance) {
        leaveBalanceRepository.save(leaveBalance);
        logger.info("Leave balance saved for Employee ID: {}, Type: {}, Year: {}",
                leaveBalance.getEmployee().getId(),
                leaveBalance.getLeaveType(),
                leaveBalance.getYear());
    }
}
