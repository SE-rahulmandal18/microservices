package com.payroll_app.demo.service;

import com.payroll_app.demo.dto.PayrollRequest;
import com.payroll_app.demo.dto.PayrollResponse;
import com.payroll_app.demo.model.Employee;
import com.payroll_app.demo.model.LeaveRecord;
import com.payroll_app.demo.model.Payroll;
import com.payroll_app.demo.repository.AttendanceRepository;
import com.payroll_app.demo.repository.EmployeeRepository;
import com.payroll_app.demo.repository.LeaveRecordRepository;
import com.payroll_app.demo.repository.PayrollRepository;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional
public class PayrollService {

 private final PayrollRepository payrollRepo;
 private final EmployeeRepository employeeRepo;
 private final AttendanceRepository attendanceRepo;
 private final LeaveRecordRepository leaveRecordRepo;

 private static final Logger logger = LoggerFactory.getLogger(PayrollService.class);

 public List<PayrollResponse> getAllPayrolls() {
  logger.info("Fetching all payroll records.");
  return payrollRepo.findAll()
          .stream()
          .map(this::mapToResponse)
          .collect(Collectors.toList());
 }

 public List<PayrollResponse> getPayrollsByUserId(Long userId) {
  logger.info("Fetching payrolls for user ID: {}", userId);
  Optional<Employee> employeeOpt = employeeRepo.findByUserId(userId);
  if (employeeOpt.isEmpty()) {
   logger.warn("No employee found for user ID: {}", userId);
   return Collections.emptyList();
  }
  Long employeeId = employeeOpt.get().getId();
  List<Payroll> payrolls = payrollRepo.findByEmployeeId(employeeId);
  return payrolls.stream()
          .map(this::mapToResponse)
          .collect(Collectors.toList());
 }

 public PayrollResponse createPayroll(PayrollRequest request) {
  logger.info("Creating payroll for employee ID: {}", request.getEmployeeId());
  Employee employee = employeeRepo.findById(request.getEmployeeId())
          .orElseThrow(() -> {
           logger.error("Employee not found for ID: {}", request.getEmployeeId());
           return new ResponseStatusException(HttpStatus.NOT_FOUND, "Employee not found");
          });

  Payroll payroll = buildPayrollFromRequest(request, employee);
  Payroll saved = payrollRepo.save(payroll);
  logger.info("Payroll created with ID: {}", saved.getId());

  return mapToResponse(saved);
 }

 public PayrollResponse updatePayroll(Long id, PayrollRequest request) {
  logger.info("Updating payroll ID: {}", id);
  Payroll payroll = payrollRepo.findById(id)
          .orElseThrow(() -> {
           logger.error("Payroll not found for ID: {}", id);
           return new ResponseStatusException(HttpStatus.NOT_FOUND, "Payroll not found");
          });

  if (payroll.getPaymentStatus() == Payroll.PaymentStatus.PROCESSED &&
          request.getPaymentStatus() != Payroll.PaymentStatus.PROCESSED) {
   logger.warn("Invalid status change from PROCESSED to {}", request.getPaymentStatus());
   throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Cannot change status from PROCESSED to another state.");
  }

  updatePayrollFields(payroll, request);
  Payroll updated = payrollRepo.save(payroll);
  logger.info("Payroll updated with ID: {}", updated.getId());

  return mapToResponse(updated);
 }

 public void deletePayroll(Long id) {
  logger.info("Deleting payroll ID: {}", id);
  payrollRepo.deleteById(id);
 }

 private Payroll buildPayrollFromRequest(PayrollRequest request, Employee employee) {
  logger.debug("Building payroll for employee ID: {}", employee.getId());
  Payroll calculated = calculatePayrollDetails(request, employee.getId());

  return Payroll.builder()
          .employee(employee)
          .basicSalary(request.getBasicSalary())
          .allowances(request.getAllowances())
          .bonuses(request.getBonuses())
          .deductions(request.getDeductions())
          .overtime(calculated.getOvertime())
          .lopDays(calculated.getLopDays())
          .lopDeduction(calculated.getLopDeduction())
          .netSalary(calculated.getNetSalary())
          .paymentStatus(Payroll.PaymentStatus.PENDING)
          .build();
 }

 private void updatePayrollFields(Payroll payroll, PayrollRequest request) {
  logger.debug("Updating fields for payroll ID: {}", payroll.getId());
  BigDecimal basicSalary = request.getBasicSalary() != null ? request.getBasicSalary() : payroll.getBasicSalary();
  BigDecimal allowances = request.getAllowances() != null ? request.getAllowances() : payroll.getAllowances();
  BigDecimal bonuses = request.getBonuses() != null ? request.getBonuses() : payroll.getBonuses();
  BigDecimal deductions = request.getDeductions() != null ? request.getDeductions() : payroll.getDeductions();

  Payroll calculated = calculatePayrollDetails(request, payroll.getEmployee().getId());

  payroll.setBasicSalary(basicSalary);
  payroll.setAllowances(allowances);
  payroll.setBonuses(bonuses);
  payroll.setDeductions(deductions);
  payroll.setOvertime(calculated.getOvertime());
  payroll.setLopDays(calculated.getLopDays());
  payroll.setLopDeduction(calculated.getLopDeduction());
  payroll.setNetSalary(calculated.getNetSalary());

  if (request.getPaymentStatus() != null) {
   if (request.getPaymentStatus() == Payroll.PaymentStatus.PROCESSED &&
           payroll.getPaymentStatus() != Payroll.PaymentStatus.PROCESSED) {
    payroll.setProcessedAt(LocalDateTime.now());
    logger.info("Payroll marked as PROCESSED at {}", payroll.getProcessedAt());
   }
   payroll.setPaymentStatus(request.getPaymentStatus());
  }
 }

 private Payroll calculatePayrollDetails(PayrollRequest request, Long employeeId) {
  logger.debug("Calculating payroll details for employee ID: {}", employeeId);
  BigDecimal totalOvertime = attendanceRepo.findByEmployeeId(employeeId).stream()
          .map(a -> a.getOvertimeHours() != null ? a.getOvertimeHours() : BigDecimal.ZERO)
          .reduce(BigDecimal.ZERO, BigDecimal::add);

  int totalLopDays = (int) Math.ceil(leaveRecordRepo.findByEmployeeId(employeeId).stream()
          .filter(lr -> !lr.isPaid())
          .mapToDouble(lr -> {
           long days = java.time.temporal.ChronoUnit.DAYS.between(lr.getStartDate(), lr.getEndDate()) + 1;
           return days * (lr.getDurationPerDay() == LeaveRecord.LeaveDuration.HALF ? 0.5 : 1.0);
          })
          .sum());

  BigDecimal perDaySalary = request.getBasicSalary()
          .divide(BigDecimal.valueOf(30), 2, RoundingMode.HALF_UP);

  BigDecimal lopDeduction = perDaySalary.multiply(BigDecimal.valueOf(totalLopDays));

  BigDecimal netSalary = request.getBasicSalary()
          .add(request.getAllowances() != null ? request.getAllowances() : BigDecimal.ZERO)
          .add(request.getBonuses() != null ? request.getBonuses() : BigDecimal.ZERO)
          .add(totalOvertime) // assuming ₹1 per overtime hour
          .subtract(request.getDeductions() != null ? request.getDeductions() : BigDecimal.ZERO)
          .subtract(lopDeduction);

  logger.debug("Payroll Calculation -> Overtime: {}, LOP Days: {}, LOP Deduction: {}, Net Salary: {}",
          totalOvertime, totalLopDays, lopDeduction, netSalary);

  return Payroll.builder()
          .overtime(totalOvertime)
          .lopDays(totalLopDays)
          .lopDeduction(lopDeduction)
          .netSalary(netSalary)
          .build();
 }

 private PayrollResponse mapToResponse(Payroll payroll) {
  return PayrollResponse.builder()
          .id(payroll.getId())
          .employeeId(payroll.getEmployee().getId())
          .employeeName(payroll.getEmployee().getFirstName() + " " + payroll.getEmployee().getLastName())
          .basicSalary(payroll.getBasicSalary())
          .allowances(payroll.getAllowances())
          .bonuses(payroll.getBonuses())
          .overtime(payroll.getOvertime())
          .deductions(payroll.getDeductions())
          .lopDays(payroll.getLopDays())
          .lopDeduction(payroll.getLopDeduction())
          .netSalary(payroll.getNetSalary())
          .paymentStatus(payroll.getPaymentStatus())
          .processedAt(payroll.getProcessedAt())
          .build();
 }
}
