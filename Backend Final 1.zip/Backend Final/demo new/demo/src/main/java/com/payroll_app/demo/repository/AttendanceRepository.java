package com.payroll_app.demo.repository;

import com.payroll_app.demo.dto.OvertimeTrendDTO;
import com.payroll_app.demo.model.Attendance;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface AttendanceRepository extends JpaRepository<Attendance, Long> {
    List<Attendance> findByEmployeeId(Long employeeId);

    @Query("SELECT new com.payroll_app.demo.dto.OvertimeTrendDTO(" +
            "YEAR(a.workDate), MONTH(a.workDate), SUM(a.overtimeHours)) " +
            "FROM Attendance a " +
            "GROUP BY YEAR(a.workDate), MONTH(a.workDate) " +
            "ORDER BY YEAR(a.workDate), MONTH(a.workDate)")
    List<OvertimeTrendDTO> findMonthlyOvertimeSummaries();

    @Query("SELECT a FROM Attendance a WHERE a.employee.id = :employeeId AND a.workDate BETWEEN :startDate AND :endDate")
    List<Attendance> findByEmployeeIdAndWorkDateBetween(
            @Param("employeeId") Long employeeId,
            @Param("startDate") java.time.LocalDate startDate,
            @Param("endDate") java.time.LocalDate endDate
    );

}